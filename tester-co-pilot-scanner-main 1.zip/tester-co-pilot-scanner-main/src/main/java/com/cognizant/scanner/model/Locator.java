package com.cognizant.scanner.model;

public class Locator {
    private int stepNumber;
    private String pageUrl;
    private String pageTitle;
    private String userText;
    private int iRetVal;
    private String type;
    private String value;
    private String data;
    private String action;
    private String actionMethod;
    private String createdByFunction;
    private String className;
    private String classNameObject;
    private String methodName;
    private String elementObject;
    private Boolean elementInsideIframe;
    private String iframeIdOrName;
    private Boolean elementInsideChildWindow;
    private String childWindowTitle;
    private Wait wait;
    private Verify verify;
    private boolean isReusableComponent = false;
    private String reusableComponentName;

    public int getStepNumber() {
        return stepNumber;
    }

    public void setStepNumber(int stepNumber) {
        this.stepNumber = stepNumber;
    }

    public String getPageUrl() {
        return pageUrl;
    }

    public void setPageUrl(String pageUrl) {
        this.pageUrl = pageUrl;
    }

    public String getPageTitle() {
        return pageTitle;
    }

    public void setPageTitle(String pageTitle) {
        this.pageTitle = pageTitle;
    }

    public String getUserText() {
        return userText;
    }

    public void setUserText(String userText) {
        this.userText = userText;
    }

    public int getiRetVal() {
        return iRetVal;
    }

    public void setiRetVal(int iRetVal) {
        this.iRetVal = iRetVal;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getActionMethod() {
        return actionMethod;
    }

    public void setActionMethod(String actionMethod) {
        this.actionMethod = actionMethod;
    }

    public String getCreatedByFunction() {
        return createdByFunction;
    }

    public void setCreatedByFunction(String createdByFunction) {
        this.createdByFunction = createdByFunction;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassNameObject() {
        return classNameObject;
    }

    public void setClassNameObject(String classNameObject) {
        this.classNameObject = classNameObject;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getElementObject() {
        return elementObject;
    }

    public void setElementObject(String elementObject) {
        this.elementObject = elementObject;
    }

    public Boolean getElementInsideIframe() {
        return elementInsideIframe;
    }

    public void setElementInsideIframe(Boolean elementInsideIframe) {
        this.elementInsideIframe = elementInsideIframe;
    }

    public String getIframeIdOrName() {
        return iframeIdOrName;
    }

    public void setIframeIdOrName(String iframeIdOrName) {
        this.iframeIdOrName = iframeIdOrName;
    }

    public Boolean getElementInsideChildWindow() {
        return elementInsideChildWindow;
    }

    public void setElementInsideChildWindow(Boolean elementInsideChildWindow) {
        this.elementInsideChildWindow = elementInsideChildWindow;
    }

    public String getChildWindowTitle() {
        return childWindowTitle;
    }

    public void setChildWindowTitle(String childWindowTitle) {
        this.childWindowTitle = childWindowTitle;
    }

    public Wait getWait() {
        return wait;
    }

    public void setWait(Wait wait) {
        this.wait = wait;
    }

    public Verify getVerify() {
        return verify;
    }

    public void setVerify(Verify verify) {
        this.verify = verify;
    }

    public boolean isReusableComponent() {
        return isReusableComponent;
    }

    public void setReusableComponent(boolean reusableComponent) {
        isReusableComponent = reusableComponent;
    }

    public String getReusableComponentName() {
        return reusableComponentName;
    }

    public void setReusableComponentName(String reusableComponentName) {
        this.reusableComponentName = reusableComponentName;
    }
}
