package com.cognizant.scanner.common;

public class SFDCConstants {
    private SFDCConstants(){
    }

    /* Common */
    public static final String XPATH_COMMON_VD = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]";
    public static final String XPATH_COMMOM_VD_MULTI = "//div[contains(@class,'active')]//li[contains(@class,'active')]/ancestor::div/div[contains(@class,'active') and contains(@class,'windowViewMode')]";
    public static final String XP_COMMON_IN_ED_AND_VD = "(//div[contains(@class,'footer-visible')])[1]";
    public static final String XP_COMMON_IN_ED = "(//div[contains(@class,'windowViewMode') and contains(@class,'isModal active') and contains(@class,'active')])[1]";
    public static final String XP_COMMON_IN_ED_INLINE = "(//div[contains(@class,'footer-visible')][contains(@class,'slds-card')])[1]";
    public static final String XP_DESKTOP_CONTAINS_STYLE = "(//body[contains(normalize-space(@class),'desktop')])[1]";
    public static final String XP_COMMON_IN_VIEW = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]//div[contains(@class,'Home')]";
    public static final String COMMON_BUTTON_XPATH = "//*[normalize-space(text())='%s']//ancestor::*[contains(@class,'slds-button')][1]";

    /* App Launcher */
    /**APP_LAUNCHER_NAVIGATION_ICON xpath got changed in DOM on 10-July-2023*/
    public static final String APP_LAUNCHER_NAVIGATION_ICON = "//button[contains(@class,'slds-button')][1]//div[contains(@class,'slds-icon-waffle')][1]";
    //    public static final String APP_LAUNCHER_NAVIGATION_ICON = "//button[contains(@class,'icon-waffle')][1]//div[contains(@class,'icon-waffle')][1]";
    public static final String APP_LAUNCHER_VIEW_ALL = "(//button[@type='button'][text()='View All'])[1]";
    public static final String APP_LAUNCHER_APP_NAME_XPATH = "//div[contains(@class,'app-launcher')]//p[normalize-space(text())='%s'][1]";
    public static final String APP_LAUNCHER_ALL_ITEM_XPATH = "(//section[contains(@class,'is-open')]/descendant::ul/descendant::li/descendant::a/descendant::p[normalize-space(text())='%s'])[1]";

    /* Buttons */
    public static final String BUTTON_XPATH0 = "//button[@type='button']/descendant::*[contains(@class,'btn')][text()='%s']";
    public static final String BUTTON_XPATH1 = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::li[contains(@class,'slds-button')]/descendant::a[1]/descendant::div[@title='%s'])[1]";
    public static final String BUTTON_XPATH2 = "//force-form-footer[contains(@class,'-footer') or contains(@class,'inlineFooter')]/descendant::button[contains(@class,'slds-button')]/descendant-or-self::*[normalize-space(text())='%s'][1]";
    public static final String BUTTON_XPATH3 = "//lightning-button//button[@type='button'][normalize-space(text())='%s'][1]";
    public static final String BUTTON_XPATH4 = "(//button[contains(@class,'ModalFooter')]//*[text()='%s'])[1]";
    public static final String BUTTON_XPATH5 = "("+XPATH_COMMON_VD +"//button[contains(@class,'button')][@type='button']/descendant-or-self::*[normalize-space(text())='%s'])[1]";
    public static final String BUTTON_ON_DIALOG_XPATH6 = "(//div[@role='dialog'][contains(@class,'in-open')]//div[contains(@class,'footer')]//*[contains(@class,'button')]/descendant-or-self::*[text()='%s'])[1]";
    public static final String CHECKBOX_XPATH = "//lightning-input/descendant::label[contains(@class,'slds-checkbox__label')]/descendant::span[text()='%s'][1]";
    public static final String RADIOBUTTON_XPATH = "//label[contains(@class,'slds-radio')]/descendant::span[text()='%s'][1]";
    public static final String MENU_BUTTON_XPATH1 = "(//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::li[contains(@class,'slds-button') and (contains(@class,'DropDown') or contains(@class,'dropdown'))])[1]";
    public static final String MENU_BUTTON_XPATH2 = "(//div[contains(@class,'slds-dropdown')][@role='menu']//a[@role='menuitem']/descendant-or-self::*[text()='%s'])[1]";
    public static final String MENU_BUTTON_XPATH3 = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::button[contains(@class,'slds-button') and @name='%s']";

    /* Text Fields - Health Cloud */
    public static final String NORMALIZE_SPACE_DESKTOP = "//body[contains(normalize-space(@class),'desktop')] | //body[not(@class)][1]";
    public static final String TEXTFIELD_IN_INLINE_EDIT = XP_COMMON_IN_ED_INLINE + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
    public static final String TEXTFIELD_IN_EDIT_VIEW = XP_COMMON_IN_ED + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
    public static final String TEXTFIELD_IN_SERVICE_CONSOLE_CREATE = XPATH_COMMON_VD + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/ancestor-or-self::*[(local-name()='label' or local-name()='div') and contains(@class,'label')][1]/following-sibling::*[contains(@class, 'icon') or not(contains(@class, 'icon'))]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
    public static final String TEXTFIELD_IN_VIEW_PAGE = XP_COMMON_IN_VIEW+"/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/following::*[local-name()='input' or local-name()='textarea'][1]";


    /* Select */
    public static final String SELECT_INLINE_EDIT_XPATH1 = XP_COMMON_IN_ED_INLINE + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
    public static final String SELECT_INLINE_EDIT_XPATH2 = XP_COMMON_IN_ED_INLINE + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
    public static final String SELECT_EDIT_VIEW_XPATH1 = XP_COMMON_IN_ED + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
    public static final String SELECT_EDIT_VIEW_XPATH2 = XP_COMMON_IN_ED + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
    public static final String SELECT_EDIT_VIEW_XPATH3 = XP_COMMON_IN_ED + "/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/../descendant::button[contains(@class,'combobox')][1]";
    public static final String SELECT_SERVICE_CONSOLE_XPATH1 = XPATH_COMMON_VD + "//descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][@role='combobox'][1]";
    public static final String SELECT_SERVICE_CONSOLE_XPATH2 = XPATH_COMMON_VD + "//descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/../following-sibling::*[1]/descendant::*[contains(@class,'select')][1]";
    public static final String SELECT_SERVICE_CONSOLE_XPATH3 = XPATH_COMMON_VD + "//descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/../descendant::button[contains(@class,'combobox')][1]";
    public static final String SELECT_VALUE_XPATH1 = "(//div[contains(@class,'combobox') or contains(@class,'dropdown') or contains(@class,'select')][contains(@class,'is-open') or contains(@class,'visible')]//*[@role='option' or @role='menu']//*[normalize-space(text())='%s'])[1]";
    public static final String SELECT_VIEW_XPATH1 = XP_COMMON_IN_VIEW +"/descendant::*[(local-name()='label' or local-name()='div' or local-name()='span') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/../ancestor::*[contains(@class, 'slds-form')]//ancestor::div[contains(@class,'flowruntime-input')]/following-sibling::lightning-select/div/div/select";

    /* Common - Table Pages */
    public static final String TABLE_ROW_BY_DISPLAY_TEXT_XPATH_1 = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'fixed_container')][1]/descendant::tbody[1]/tr/descendant-or-self::*[translate(translate(normalize-space(@title), ' ', ''), '%s', '%s')='%s' or translate(translate(normalize-space(text()), ' ', ''), '%s', '%s')='%s'][1]";
    public static final String TABLE_ROW_MENU_CARROT_XPATH = "//*[translate(translate(normalize-space(@title), ' ', ''), '%s', '%s')='%s'or translate(translate(normalize-space(text()), ' ', ''), '%s', '%s')='%s'][1]/ancestor::tr/descendant-or-self::*[local-name()='td' or local-name()='th'][last()]/descendant::*[contains(@class,'slds-button') and (contains(@role,'button') or contains(@type,'button'))]";
    public static final String TABLE_ROW_MENU_ITEM_XPATH = "//div[contains(@class,'actionMenu') and contains(@class,'uiMenuList--default visible')]/descendant::a[translate(translate(normalize-space(@title), ' ', ''), '%s', '%s')='%s' and normalize-space(@role)='menuitem'][1]";

    /* Related View */
    public static final String RELATED_ITEMS_XPATH = "//h2[contains(@class,'header-title')]/descendant-or-self::*[text()='%s'][1]";
    public static final String RELATED_NEW_BUTTON = "//h2[contains(@class,'header-title')]/descendant-or-self::*[text()='%s'][1]/ancestor::div[contains(@class,'slds-media slds-media--center')][1]/descendant::button[text()='New'][1]";
    public static final String RELATED_LISTVIEW_TABLEITEM="//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'fixed_container')][1]/descendant::tbody[1]/tr/descendant-or-self::*[translate(translate(normalize-space(@title), ' ', ''), '%s', '%s')='%s' or translate(translate(normalize-space(text()), ' ', ''), '%s', '%s')='%s'][1]";

    /* Global Search */
    public static final String GLOBAL_SEARCH_BUTTON = "(//button[@aria-label='Search'][text()='Search...'])[1]";
    public static final String GLOBAL_SEARCH_COMBOBOX = "(//input[@role='combobox'][contains(@data-value,'Search')])[1]";
    public static final String GLOBAL_SEARCH_COMBOBOX_ITEM = "(//div[contains(@class,'combobox') or contains(@class,'dropdown')][contains(@class,'is-open')]//*[@role='option']//*[text()='%s'])[1]";
    public static final String GLOBAL_SEARCH_INPUT = "(//input[@placeholder='Search...'])[1]";
    public static final String GLOBAL_SEARCH_SELECT_ITEM = "(//div[contains(@class,'oneContent') or contains(@class,'windowViewMode-maximized') or contains(@class,'windowViewMode-normal')][contains(@class,'active')]//tr//a//descendant-or-self::*[text()='%s'])[1]";

    public static final String GLOBAL_SEARCH_SELECT_ITEM_2 = "//div[contains(@class,'oneContent') or contains(@class,'windowViewMode-maximized') or contains(@class,'windowViewMode-normal')][contains(@class,'active')]//tr//a//descendant-or-self::*[text()='%s'][1]";

    /* Multi Select(Picklist) */
    public static final String MS_RIGHT_ARROW = "//*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/ancestor::div[@role='group']//*[@data-key='right'][1]";
    public static final String MS_LEFT_ARROW = "//*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/ancestor::div[@role='group']//*[@data-key='left'][1]";
    /* SERVICE/SALES CONSOLE CREATE PAGE */
    public static final String MS_AVAILABLE_LABEL_XPATH = "//*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/ancestor::div[@role='group']//*[normalize-space(text())='Available'][1]";
    public static final String MS_AVAILABLE_ALL_ITEM_XPATH = MS_AVAILABLE_LABEL_XPATH + "/following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
    public static final String MS_AVAILABLE_ITEM_XPATH = "(" + MS_AVAILABLE_ALL_ITEM_XPATH + "[normalize-space(text())='%s'])[1]";
    public static final String MS_CHOSEN_LABEL_XPATH = "//*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/ancestor::div[@role='group']//*[normalize-space(text())='Chosen'][1]";
    public static final String MS_CHOSEN_ALL_ITEM_XPATH = MS_CHOSEN_LABEL_XPATH + "/following-sibling::div[contains(@class,'list') and contains(@class,'options')][1]//ul[@role='listbox']//li//*[@title=normalize-space(text())]";
    public static final String MS_CHOSEN_ITEM_XPATH = "(" + MS_CHOSEN_ALL_ITEM_XPATH + "[normalize-space(text())='%s'])[1]";

    /* Assertion */
    public static final String ERROR_TOOLTIP_HEADER = "//records-record-edit-error-header/descendant::h2";
    public static final String INPUT_FIELD_ERROR_LABEL = "//label[text()='%s']/ancestor::*[contains(@class,'slds-has-error')]/descendant::div[contains(@class,'slds-form-element__help')]";

    /* LogOut */
    public static final String LO_USER_PROFILE = "//button[contains(@class,'userProfile')][1]";
    public static final String LO_LOGOUT = "(//a[text()='Log Out'])[1]";

    /* SetValue */
    //public static final String ORC_DETAIL_VIEW_PAGE = XPATH_COMMON_VD+"[1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='%s'][1]/../following-sibling::div[1]//*[contains(@class,'field')]//*[text()][1]";
    public static final String ORC_DETAIL_VIEW_PAGE = XPATH_COMMON_VD+"[1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='%s'][1]/ancestor::dl[1]//following-sibling::dd//*[contains(@class,'field')]//*[text()][1]";
    public static final String ORC_EDIT_VIEW_PAGE = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='%s'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
    public static final String ORC_SERVICE_CONTROL_CREATE_PAGE = XPATH_COMMON_VD+"//descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='%s'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
    public static final String ORC_INLINE_EDIT_PAGE = XP_COMMON_IN_ED_INLINE + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='%s'][1]/../following-sibling::*[1]/descendant-or-self::span[contains(@class,'field') and contains(@class,'value')]/descendant-or-self::*[text()][1]";
    /* VerifyFieldPresent */
    public static final String VERIFY_FIELD_DETAIL_VIEW_PAGE = XPATH_COMMON_VD+"[1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='%s'][1]";
    public static final String VERIFY_FIELD_EDIT_VIEW_PAGE = "//div[contains(@class,'in-open') and @role='dialog'][1]/descendant::div[contains(@class,'body')][1]/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='%s'][1]";
    public static final String VERIFY_FIELD_NEW_PAGE = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]//descendant::*[(local-name()='label' or  local-name()='div' or local-name()='span') and contains(@class,'label') and text()='%s']";
    public static final String VERIFY_FIELD_SERVICE_CONTROL_CREATE_PAGE = XPATH_COMMON_VD+"//descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='%s'][1]";
    public static final String VERIFY_FIELD_INLINE_EDIT_PAGE = XP_COMMON_IN_ED_INLINE + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/span[text()='%s'][1]";

    /* VerifyFieldValueEquals */
    public static final String VERIFY_VALUE_INLINE_EDIT = XP_COMMON_IN_ED_INLINE + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
    public static final String VERIFY_VALUE_EDIT_VIEW = XP_COMMON_IN_ED + "/descendant::*[(local-name()='label' or local-name()='div') and contains(@class,'label')]/descendant-or-self::*[normalize-space(text())='%s']/following-sibling::*[1]/descendant-or-self::*[local-name()='input' or local-name()='textarea'][1]";
    public static final String VERIFY_TABLE_VALUE = "//div[contains(@class,'active') and contains(@class,'windowViewMode')]/descendant::div[contains(@class,'fixed_container')][1]/descendant::tbody[1]/tr/descendant-or-self::*[contains(@title, '%s')][1]";

    /** Find By Text */
    //Texts in header only fixed dialogs
    public static final String TEXT_IN_DIALOG = "//div[contains(@class,'active') and contains(@role,'dialog')]//*[normalize-space(text())='%s'][1]";
    //Texts in main content
    public static final String PLAIN_TEXT_XPATH = XPATH_COMMOM_VD_MULTI + "//*[normalize-space(text())='%s'][1]";

    public static final String PLAIN_TEXT_CONTAINS_XPATH = XPATH_COMMOM_VD_MULTI + "//*[contains(text(),'%s')][1]";

    public static final String LOGIN_PAGE = "//input[@id='%s']";

    /** Alternative xpath to click "Cases" if UI is changed*/
    public static final String SLDS_TABS_DEFAULT_LINK = "//a[contains(@class,'slds-tabs_default__link')][text()='Care Plans']";
}
