package com.cognizant.scanner.selenium;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.*;
/*import org.openqa.selenium.support.events.AbstractWebDriverEventListener;
import org.openqa.selenium.support.events.EventFiringWebDriver;*/
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.net.URL;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Properties;
import org.openqa.selenium.JavascriptExecutor;

public class SeleniumResult {

    long startTime = 0;
    long endTime = 0;

    public WebDriver driver;
    public WebDriverWait wait;

    private EventFiringDecorator e_driver;
    private WebEventListener eventListener;

    private String clickedControlID = "";

    boolean bBrowserLaunched = false;
    boolean bURLloaded = false;
    String strTempPOObjectID = "";

    private long actionDelay = 2000;
    private String strWebDriver = "webdriver.chrome.driver";

    private String strChromeExe = ".\\chromedriver.exe";

    Map<String, String> mapAlreadyExecutedObjectOnGivenPAge = new HashMap<String, String>();

    List<String> listTestDataUsedTillNow = new ArrayList<String>();

    /** Depricated in selenium 4 */
    //public class WebEventListener extends AbstractWebDriverEventListener {
    public class WebEventListener implements WebDriverListener  {

        public void beforeNavigateTo(String url, WebDriver driver) {
            System.out.println("Before navigating to: '" + url + "'");
        }

        public void afterNavigateTo(String url, WebDriver driver) {
            System.out.println("Navigated to:'" + url + "'");
        }

        public void beforeClickOn(WebElement element, WebDriver driver) {
            clickedControlID = element.getAttribute("id");

        }

        public void afterClickOn(WebElement element, WebDriver driver) {
        }

        public void onException(Throwable error, WebDriver driver) {
            System.out.println("Error occurred: " + error);
        }

        public void beforeChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {
            clickedControlID = element.getAttribute("id");
        }

        public void afterChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {

            System.out.println("afterChangeValueOf on: " + element.toString());
        }

    }

    private boolean InitiatePageObjectActions() {

        try {
            System.setProperty(strWebDriver, strChromeExe);
            driver = new ChromeDriver();

            wait = new WebDriverWait(driver, Duration.ofSeconds(15));

            /** Depricated in selenium 4 */
            //e_driver = new EventFiringWebDriver(driver);
            EventFiringDecorator<WebDriver> decorator = new EventFiringDecorator<>(eventListener); //Pass listener to constructor
            e_driver = (EventFiringDecorator) decorator.decorate(driver);

            eventListener = new WebEventListener();

            /** Depricated in selenium 4 */
            //e_driver.register(eventListener);

            /** Depricated in selenium 4 */
            ((WebDriver)e_driver).manage().window().maximize();

            bBrowserLaunched = true;
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {

        SeleniumResult objtemplate = new SeleniumResult();
        int iRetVal = 9999;
        try {
            objtemplate.checkAndKill();
        } catch (Exception e) {

        }

        try {

            boolean bBrowserLaunched = false;
            boolean bURLloaded = false;
            String baseURLEx = "";
            int iStepCount = 0;

            {

                bBrowserLaunched = objtemplate.InitiatePageObjectActions();

            }
            {

                if (bBrowserLaunched) {
                    iStepCount++;

                    baseURLEx = "https://www.o2.co.uk/shop/tariff/samsung/galaxy-s20-5g?frDeviceTerm=36&planId=d480f01d-ca14-40bc-baa9-dfcf40187b4a%3A30.00%3A56.50&tariffState=calculator&productId=6e6be238-6d7b-43fb-971f-76536e57ae44&contractType=paymonthly";
                    /** Depricated in selenium 4 */
                    ((WebDriver)objtemplate.e_driver).get(baseURLEx);
                    Thread.sleep(objtemplate.actionDelay);

                    bURLloaded = true;
                    iStepCount++;

                } else {
                    JOptionPane.showMessageDialog(null, "Couldnot open given URL : " + baseURLEx, "Browser not loaded", 1);

                }
            }

            if (!bBrowserLaunched && !bURLloaded) {

                JOptionPane.showMessageDialog(null, "Couldnot open given URL : " + baseURLEx, "Browser not loaded", 1);

                System.exit(0);

            }

            iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_submit_$_tne-primary_$__$_Choose later_$_null_$_", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_submit_$_tne-primary_$__$_Choose later_$_null_$_", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_submit_$_tne-primary_$__$_Confirm Spend Cap_$_null_$_", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_submit_$_tne-primary_$__$_Confirm Spend Cap_$_null_$_", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_button_$_btn-link toggle-button_$__$_I don't want extras_$_null_$_", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_button_$_btn-link toggle-button_$__$_I don't want extras_$_null_$_", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_submit_$_tne-secondary_$__$_Go to basket_$_null_$_", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_submit_$_tne-secondary_$__$_Go to basket_$_null_$_", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteInputClickWithoutID("spinputid_$_button_$_checkout-btn_$_securecheckout_$_Checkout_$_", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteInputClickWithoutID("spinputid_$_button_$_checkout-btn_$_securecheckout_$_Checkout_$_", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteHrefClickWithoutID("sphrefid_$_null_$_button primary redesign-button new-customer-btn_$__$_I'm a new customer_$_1061b597f59b45549d8b32a550be7816_$_", false, "", "class=button primary redesign-button new-customer-btn, data-qa-new-customer-btn=, tabindex=0", true);
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteHrefClickWithoutID("sphrefid_$_null_$_button primary redesign-button new-customer-btn_$__$_I'm a new customer_$_1061b597f59b45549d8b32a550be7816_$_", false, "", "class=button primary redesign-button new-customer-btn, data-qa-new-customer-btn=, tabindex=0", true);
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("peter.pan@gmail.com", "email", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteClick("titleSelectBoxItArrow", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteClick("titleSelectBoxItArrow", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteWithDirectLinkFindEx("Click", "", "class=selectboxit-option-anchor", "sphrefid_$_null_$_selectboxit-option-anchor_$__$_Mr_$_c17aea80d03f41c190cc0792474df5be_$_", "Mr", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteWithDirectLinkFindEx("Click", "", "class=selectboxit-option-anchor", "sphrefid_$_null_$_selectboxit-option-anchor_$__$_Mr_$_c17aea80d03f41c190cc0792474df5be_$_", "Mr", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("peter", "first-name", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("pan", "last-name", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("07734744954", "contact-number", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("Password123", "password", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteClick("securityQuestionSelectBoxItArrow", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteClick("securityQuestionSelectBoxItArrow", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteWithDirectLinkFindEx("Click", "", "class=selectboxit-option-anchor", "sphrefid_$_null_$_selectboxit-option-anchor_$__$_Name of your first pet_$_8d520bd588b3440b9beb5173fa79c4ce_$_", "Name of your first pet", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteWithDirectLinkFindEx("Click", "", "class=selectboxit-option-anchor", "sphrefid_$_null_$_selectboxit-option-anchor_$__$_Name of your first pet_$_8d520bd588b3440b9beb5173fa79c4ce_$_", "Name of your first pet", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("chintu", "security-answer", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("11/06/1979", "date-dd-mm-yy", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteClick("outerDiv", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteClick("outerDiv", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteClick("outerDiv", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteClick("outerDiv", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteClick("outerDiv", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteClick("outerDiv", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteClick("btn-continue-next-section", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteClick("btn-continue-next-section", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteClick("deliver-to-store-tab", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteClick("deliver-to-store-tab", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("BS3 4BX", "storePostcode", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteSpanClickWithoutID("spspanid_$_null_$__$_null_$_Find_$_null_$_", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteSpanClickWithoutID("spspanid_$_null_$__$_null_$_Find_$_null_$_", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteSpanClickWithoutID("spspanid_$_null_$__$_null_$_Choose store_$_null_$_", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteSpanClickWithoutID("spspanid_$_null_$__$_null_$_Choose store_$_null_$_", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteClick("btn-continue-next-section", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteClick("btn-continue-next-section", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_submit_$_ button primary main-continue-btn_$__$_Go to Payments_$_null_$_", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    for (int iCnt = 0; iCnt < 5; iCnt++) {
                        iRetVal = objtemplate.ExecuteButtonClickWithoutID("spbuttonid_$_submit_$_ button primary main-continue-btn_$__$_Go to Payments_$_null_$_", false, "");
                        if (iRetVal > 0) {
                            break;
                        }
                    }
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("peter pan", "accountName", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("11224455", "accountNumber", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);
            iRetVal = objtemplate.SendWordKeys("09-09-88", "newSortCode", false, "");
            switch (iRetVal) {
                case 0:
                case -1:
                    break;
            }
            Thread.sleep(2000);

        } catch (Exception ex) {
            ex.printStackTrace();

            System.exit(0);
        }
    }

    private static final String TASKLIST = "tasklist";
    private static final String KILL = "taskkill /F /IM ";

    public boolean isProcessRunning(String serviceName) throws Exception {

        Process p = Runtime.getRuntime().exec(TASKLIST);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                p.getInputStream()));
        String line;
        while ((line = reader.readLine()) != null) {

            if (line.contains(serviceName)) {
                killProcess(serviceName);
            }
        }

        return false;

    }

    public void killProcess(String serviceName) throws Exception {

        Process procKilled = Runtime.getRuntime().exec(KILL + serviceName);
        System.out.println("Service instance killed  : " + serviceName + "(" + procKilled.getInputStream() + ")");

    }

    public void checkAndKill() throws Exception {
        String processName = "chromedriver.exe";

        if (isProcessRunning(processName)) {

            killProcess(processName);
        }

    }

    private String PerformWebElementClick(WebElement element) {
        String visisbleText = "";
        int width = 0;
        int height = 0;
        if (element == null) {

            return "";
        }
        try {
            try {
//                visisbleText = SeleniumPageScanner.getVisisbleTextOfWebElement(element);
                width = element.getSize().getWidth();
                height = element.getSize().getHeight();

                if (width <= 0) {
                    width = 1;
                }
                if (height <= 0) {
                    height = 1;
                }
                //something is wrong with controls
                //return -1;

            } catch (Exception ex) {
                //do nothing
            }

            try {
                Actions act = new Actions(driver);
                act.moveToElement(element).moveByOffset((width / 2) - 2, 0).click().perform();
            } catch (Exception ex) {
                try {
                    ((JavascriptExecutor) driver).executeScript(
                            "arguments[0].click();",
                            element);
                } catch (Exception ex1) {

                    try {
                        element.click();
                    } catch (Exception ex2) {
                        // in worst case
                        //if this element is/has href 
                        //thn getPageElements href property and navigate to that url.
                        String str1 = element.getAttribute("href");
                        if (str1 != null && !str1.isEmpty()) {
                            driver.manage().deleteAllCookies();
                            driver.navigate().to(str1);
                        }
                    }
                }
            }

        } catch (Exception ex) {
            element.click();
        }
        return visisbleText;
    }

    public int SendWordKeys(String wordKeys, String clickAction, boolean bIsIFrameControl, String iFrameId) {
        WebElement objElement = null;

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            By elementLocation = By.id(clickAction);

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();

            if (bIsIFrameControl) {
                driver.switchTo().frame(iFrameId);
            }

            objElement = driver.findElement(elementLocation);
            if (objElement != null) {
                int iWaitCount = 0;
//                while ((!CheckIfGivenbjectIsEditable(clickAction, bIsIFrameControl, iFrameId, objElement, wordKeys))
//                        || (iWaitCount >= WaitCounter)) {
//                    iWaitCount++;
//                    Thread.sleep(1000);
//                }
//                if (iWaitCount >= WaitCounter) {
//                    //need to handle this case when due to some app-validation or any other reason 
//                    //this control is not getting editable.
//                }
            }
            if (objElement.isEnabled()) {

                //first clear edit control - specifically if its text box
                if (objElement.getTagName().equalsIgnoreCase("input")) {
                    objElement.sendKeys("");
                }

                //=============================
                if (objElement.getTagName().equalsIgnoreCase("select")
                        || objElement.getTagName().equalsIgnoreCase("option")
                        || objElement.getTagName().equalsIgnoreCase("radio")) {
                    //select given data using element by element search
                    Select select = new Select(objElement);
                    if (select.isMultiple()) {

                        String userXpath = "";
//                        userXpath = spServerObj.getWebElementXPathForTestStep(executionID, "Please enter valid xpath of page-object for this test step:", 0);
                        WebElement element = driver.findElement(By.xpath(userXpath));
                        element.click();
                        //SendDisplayLogToClient("Multiple Options are found");
                    }

                    List<WebElement> allOptions = select.getOptions();

                    int iCnt = 0;
                    for (iCnt = 0; iCnt < allOptions.size(); iCnt++) {
                        String CurrentOption = allOptions.get(iCnt).getText();

                        if (CurrentOption.contains(wordKeys)) {

                            allOptions.get(iCnt).click();
                            Thread.sleep(1000);
                            break;

                        }
                    }
                    if (iCnt == allOptions.size()) {
                        //means we could not find valid option to select
                        //so its upto God to select it
                        char[] array = wordKeys.toCharArray();
                        for (char ch : array) {
                            objElement.sendKeys(Character.toString(ch));
                        }

                    }
                } //==================
                else {
                    char[] array = wordKeys.toCharArray();
                    for (char ch : array) {
                        objElement.sendKeys(Character.toString(ch));
                    }
                }
                //store control id
                mapAlreadyExecutedObjectOnGivenPAge.put(clickAction, wordKeys);
                //store test-data used
                listTestDataUsedTillNow.add(wordKeys);

                Thread.sleep(actionDelay);

                if (bIsIFrameControl) {
                    driver.switchTo().defaultContent();
                }

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    return 2;
                } else {
                    try {
                        if (objElement.getTagName().equalsIgnoreCase("select") || objElement.getTagName().equalsIgnoreCase("option")) {
                            //we may getPageElements some new controls loaded on screen which were not there prev.
                            return 3;
                        }
                    } catch (Exception e) {
                        //page stale element reference so it means its changed.

                        //check and verify this is to be returned as 3 or 1
                        return 3;
                    }
                    return 1;
                }

            }
            return 0;

        } catch (Exception e) {

            return -1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                driver.switchTo().defaultContent();
            }

        }
    }

    public int ExecuteInputClickWithoutID(String clickAction, boolean bIsIFrameControl, String iFrameId) {

        WebElement objElement = null;

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have input - most probably htmlbutton which pain in axxxxx.
            //so getPageElements its type, class, name, displaytext, 
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] inputAtrrs = pattern.split(clickAction);
            String inputType = "";
            String inputClass = "";
            String inputName = "";
            String inputDisplayText = "";
            String inputOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                inputType = inputAtrrs[1];
                inputClass = inputAtrrs[2];
                inputName = inputAtrrs[3];
                inputDisplayText = inputAtrrs[4];
                inputOnClick = inputAtrrs[5];
            } catch (Exception ex) {

            }

            if (inputClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                inputClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }

            //try to find by 'name'
            List<WebElement> objElements = null;
            try {
                objElements = driver.findElements(By.name(inputName));
            } catch (Exception ex) {
            }
            try {
                if (objElements.isEmpty()) {

                    if (bUseCSSSelector) {
                        //by CSSselector 
                        objElements = driver.findElements(By.cssSelector(inputClass));

                    } else {
                        //by class name
                        objElements = driver.findElements(By.className(inputClass));
                    }
                }
            } catch (Exception ex) {
                //to debug - remove later
                ex.printStackTrace();
            }
            try {
                if (objElements.isEmpty()) {
                    //by xpath name
                    String label = inputDisplayText;
                    objElements = driver.findElements(By.xpath("//input[contains(.,'" + label + "')]"));
                }
            } catch (Exception ex) {
            }

            objElement = null;

            //
            //do the same for inputs
            if (objElements.isEmpty()) {
                List<WebElement> inputs = driver.findElements(By.tagName("input"));
                Properties p = new Properties();
                for (WebElement input : inputs) {

                    //print the links texts and links
                    String inputID = "";
                    if (input.isDisplayed() && (ExpectedConditions.elementToBeClickable(input) != null)) {

                        if (input.getAttribute("id").isEmpty() || input.getAttribute("id").equals("")) {
                            //create input id with type, class and onclick
                            //id will be of format 'spinputid_$_type_$_class_$_name_$_displaytext_$_onclick'
                            inputID = "spinputid" + "_$_";

                            try {
                                inputID += input.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }

                            try {
                                inputID += input.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }

                            try {
                                inputID += input.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }

                            try {
                                inputID += input.getText() + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            try {
                                //because in case of user slelection of objects, we are remvoing brackets
                                inputID += input.getAttribute("onclick").replace("()", "{}") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            //  emap.put(inputID, aa.toString());

                        }

                        if (inputID.equalsIgnoreCase(clickAction)) {
                            objElements.add(input);
                            break;
                        }
                    }

                }
            }

            if (objElements.isEmpty()) {
                return -1;
            }

            if (objElements.size() == 1) {
                objElement = objElements.get(0);
            } else if (objElements.size() > 1) {
                objElement = objElements.get(0); //temp code
                //
                for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                    //ask use which one to select
                    //t odo
                }
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();

            if (bIsIFrameControl) {
                driver.switchTo().frame(iFrameId);
            }

            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            //            if (width <= 0 && height <= 0) {
            //                //something is wrong with controls
            //                return -1;
            //            }
            Actions act = new Actions(driver);

            if (objElement.isEnabled()) {

                //objElement.click();
                String strElementype = objElement.getAttribute("type");
                if (strElementype != null) {
                    try {
                        act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                    } catch (Exception ex) {
                        //this is shame
                        objElement.click();
                    }

                }

                Thread.sleep(actionDelay);

                if (bIsIFrameControl) {
                    driver.switchTo().defaultContent();
                }

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    return 2;
                } else {

                    // CheckIfPopup windows is launched
                    boolean bPopUpWindowAppeared = false;
                    String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                    String subWindowHandler = null;

                    Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                    Iterator<String> iterator = handles.iterator();
                    while (iterator.hasNext()) {
                        subWindowHandler = iterator.next();
                    }

                    if (subWindowHandler != null) {
                        driver.switchTo().window(subWindowHandler); // switch to popup window
                        bPopUpWindowAppeared = true;
                    }

                    // Now you are in the popup window, perform necessary actions here
                    //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                    if (bPopUpWindowAppeared) {
                        return 3;
                    } else {
                        return 1;
                    }
                }

            }
            return 0;

        } catch (Exception e) {

            return -1;

        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                driver.switchTo().defaultContent();
            }

        }

    }

    public int ExecuteWithDirectLinkFindEx(String testAction,
            String testData,
            String strElementAttributes,
            String ObjectId,
            String VisisbleText,
            boolean bIsIFrameControl,
            String iFrameId) {

        try {

            try {

                //take action
                //String testAction = ObjectActions.Action;
                //if (CommonConstants.AppActionVerbs.contains(testAction.toLowerCase())) 
                {

                    clickedControlID = "";

                    //now check if it's mouse click or entering some user data in input field
                    //if (ObjectActions.TestData.isEmpty()) {
                    if (testData.isEmpty() || testData.length() <= 0) {
                        //testdata is empty means it's possible click event
                        //send click event

                        int iRetVal = 9999;
                        if (ObjectId.isEmpty()) {
                            //need to search webelement by visible text
                            //for future use store its Id by retrieving it.
                            iRetVal = ExecuteClickByLink(VisisbleText, true);
                            ObjectId = strTempPOObjectID;
                        } else {

                            if (ObjectId.toLowerCase().startsWith("sphrefid")) {
                                //derive href or rel from this
                                iRetVal = ExecuteHrefClickWithoutID(ObjectId,
                                        bIsIFrameControl,
                                        iFrameId,
                                        strElementAttributes,
                                        true);

                            } else {
                                iRetVal = ExecuteClickByLink(VisisbleText, true);
                            }
                        }

                        return iRetVal;

                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public int ExecuteHrefClickWithoutID(String clickAction, boolean bIsIFrameControl, String iFrameId, String strElementAttributes, boolean bStoreLinkID) {
        String Xpath = "";
        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have button - most probably htmlbutton which pain in axxxxx.
            //so getPageElements its type, class, name, displaytext, 
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] buttonAtrrs = pattern.split(clickAction);
            String linkRef = "";
            String linkClass = "";
            String linkRelevance = "";
            String linkDisplayText = "";

            try {
                linkRef = buttonAtrrs[1];
                linkClass = buttonAtrrs[2];
                linkRelevance = buttonAtrrs[3];
                linkDisplayText = buttonAtrrs[4];
            } catch (Exception ex) {
            }

            List<WebElement> objElements = null;
            objElements = new ArrayList<WebElement>();

            //first use CSS selector in combination
            if (objElements.isEmpty()) {
                try {
                    //this may return multple elements
                    String css = "." + linkClass + "[href='" + linkRef + "']";
                    objElements = driver.findElements(By.cssSelector(css));
                } catch (Exception ex1) {
                    //do nothing
                }
            }
            //then by xpath of href and class
            if (objElements.isEmpty()) {
                try {
                    String buffXpath = "//a[" + "@class='" + linkClass + "' and @href='" + linkRef + "']";
                    objElements = driver.findElements(By.xpath(buffXpath));
                } catch (Exception ex1) {
                    //do nothing
                }
            }

            //then by xpath of href and class and text
            if (objElements.isEmpty()) {
                try {
                    String buffXpath = "//a[" + "@class='" + linkClass + "' and @href='" + linkRef + "' and contains(text()='" + linkDisplayText + "')]";
                    objElements = driver.findElements(By.xpath(buffXpath));
                } catch (Exception ex1) {
                    //do nothing
                }
            }

            //try to find by 'display text' /  inner text i.e. visible text attribute
            if (objElements.isEmpty()) {
                try {
                    objElements = driver.findElements(By.linkText(linkDisplayText));
                    if (objElements.isEmpty()) {
                        objElements = driver.findElements(By.linkText("\"" + linkDisplayText + "\""));
                    }
                    if (objElements.isEmpty()) {

                        objElements = driver.findElements(By.cssSelector("a[contains('" + linkDisplayText + "')"));
                    }
                    if (objElements.isEmpty()) {
                        objElements = driver.findElements(By.xpath("//a[contains(.,'" + linkDisplayText + "')]"));
                    }

                } catch (Exception ex1) {
                    //do nothing
                }
            }

            //there is no direct way to find element by using href.            
            //by xpath of href 
            if (objElements.isEmpty()) {
                try {
                    objElements = driver.findElements(By.xpath("//a[@href='" + linkRef + "']"));
                    if (objElements.isEmpty()) {
                        objElements = driver.findElements(By.xpath("//a[contains(@href='" + linkRef + "')]"));
                    }
                } catch (Exception ex1) {
                    //do nothing
                }
            }

            //by CSS selector
            //html anchor elements dooes not support "name" attrbute hence not considering it
            //for CSS selector search
            if (objElements.isEmpty()) {

                //CSS selector support below locattor
                //Tag and ID
                //Tag and class
                //Tag and attribute
                //Tag, class, and attribute
                //Inner text
                //since there is no ID hence find by others
                try {

                } catch (Exception ex1) {
                }
                if (objElements.isEmpty()) {
                    try {
                        //by href
                        objElements = driver.findElements(By.cssSelector("a[href='" + linkRef + "']"));
                    } catch (Exception ex1) {
                    }
                }
                if (objElements.isEmpty()) {
                    try {
                        //by attribute 'rel'
                        objElements = driver.findElements(By.cssSelector("a[rel='" + linkRelevance + "']"));
                    } catch (Exception ex1) {
                    }
                }
                if (objElements.isEmpty()) {
                    try {
                        //by class
                        //this may return many elements
                        objElements = driver.findElements(By.cssSelector("a." + linkClass));

                    } catch (Exception ex1) {
                    }
                }
            }

            //then by class name
            if (objElements.isEmpty()) {
                try {
                    //this may return multple elements
                    objElements = driver.findElements(By.className(linkClass));
                } catch (Exception ex1) {
                    //do nothing
                }
            }

            if (objElements.isEmpty()) {
                try {
                    //by rel property
                    if (objElements.size() == 0 && linkRelevance.length() > 0) {
                        String url = driver.getCurrentUrl(); // getPageElements the current URL (full)
                        java.net.URL currentUri = new URL(url); // create a Uri instance of it
                        String baseUrl = currentUri.getAuthority(); // just getPageElements the "base" bit of the URL

                        //this is wrong but keep it for time being. as it may be pop up or actual diversion.
                        driver.navigate().to(baseUrl + linkRelevance);
                    }
                } catch (Exception ex1) {
                    //do nothing
                }
            }

            if (objElements.isEmpty()) {
                List<WebElement> allLinks = driver.findElements(By.tagName("a"));
                for (WebElement link : allLinks) {
                    if (link.getAttribute("id").isEmpty() && (!link.getText().isEmpty())) {

                        //this will only work if all attributes are returned in same sequence
                        String strCurrentAllAttribute = strElementAttributes;
                        //FindAllAttributes(link);

                        strCurrentAllAttribute = strCurrentAllAttribute.replaceAll(",", "");
                        strElementAttributes = strElementAttributes.replaceAll(",", "");

                        if (strElementAttributes.equalsIgnoreCase(strCurrentAllAttribute)) {
                            objElements.add(link);
                        }
                    }
                }

            }
            ///////////////////////////////////////

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();

            if (bIsIFrameControl) {
                driver.switchTo().frame(iFrameId);
            }

            Actions act = new Actions(driver);

            if (bStoreLinkID) //store temporary linkID
            {
                strTempPOObjectID = clickAction;
            }

            if (objElements.size() > 0) {
                //found many elements with same properties
                WebElement objElement = null;

                for (WebElement element : objElements) {

                    //now shortlist single element based on linkref and displaytext
                    if (element.getText().equalsIgnoreCase(linkDisplayText)
                            || element.getAttribute("href").equalsIgnoreCase(linkRef)) {
                        objElement = element;
                    }
                    //put any other check to shortlist element

                    if ((objElement != null) && (objElement.isEnabled())) {
                        int width = objElement.getSize().getWidth();
                        int height = objElement.getSize().getHeight();

                        if (width <= 0 && height <= 0) {
                            //something is wrong with controls
                            //return -1;
                            //do nothing
                            //next control
                        } else {

                            try {
                                //Xpath = driverParser.findXPATHIDFromWebElement(objElement);
                                act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                                break;
                            } catch (Exception ex) {
                                //this is shame
                                try {
                                    objElement.click();
                                    break;
                                } catch (Exception ex1) {
                                    //do nothing
                                    //go to next element
                                }
                            }
                        }
                    }
                }
            }

            Thread.sleep(actionDelay);

            if (bIsIFrameControl) {
                driver.switchTo().defaultContent();
            }

            String NextURL = driver.getCurrentUrl();
            String NextTitle = driver.getTitle();

            if (!(currentURL.equalsIgnoreCase(NextURL))
                    || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                //it means page is changed
                return 2;
            } else {

                // CheckIfPopup windows is launched
                boolean bPopUpWindowAppeared = false;
                String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                String subWindowHandler = null;

                Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                Iterator<String> iterator = handles.iterator();
                while (iterator.hasNext()) {
                    subWindowHandler = iterator.next();
                }

                if (subWindowHandler != null) {
                    driver.switchTo().window(subWindowHandler); // switch to popup window
                    bPopUpWindowAppeared = true;
                }

                // Now you are in the popup window, perform necessary actions here
                //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                if (bPopUpWindowAppeared) {
                    return 3;
                } else {
                    return 1;
                }
            }

        } catch (Exception e) {
            return -1;

        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                driver.switchTo().defaultContent();

            }

        }

    }

    public int ExecuteClickByLink(String clickAction, boolean bStoreLinkId) {
        WebElement objElement = null;

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            By elementLocation = By.linkText(clickAction);

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();

            objElement = driver.findElement(elementLocation);

            if (bStoreLinkId) //store temporary linkID
            {
                strTempPOObjectID = objElement.getAttribute("href");
            }

            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            if (width <= 0 && height <= 0) {
                //something is wrong with controls
                return -1;
            }

            Actions act = new Actions(driver);

            if (objElement.isEnabled()) {

                try {
                    act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                } catch (Exception ex) {
                    //triple shame 
                    objElement.click();
                }
                Thread.sleep(actionDelay);

                //do not add clickable controls , as those can be repeated.
                ////////listAlreadyExecutedObjectOnGivenPAge.add(clickAction);
                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    return 2;
                } else {

                    // CheckIfPopup windows is launched
                    boolean bPopUpWindowAppeared = false;
                    String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                    String subWindowHandler = null;

                    Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                    Iterator<String> iterator = handles.iterator();
                    while (iterator.hasNext()) {
                        subWindowHandler = iterator.next();
                    }

                    if (subWindowHandler != null) {
                        driver.switchTo().window(subWindowHandler); // switch to popup window
                        bPopUpWindowAppeared = true;
                    }

                    // Now you are in the popup window, perform necessary actions here
                    //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                    if (bPopUpWindowAppeared) {
                        return 3;
                    } else {
                        return 1;
                    }
                }

            }
            return 0;

        } catch (Exception e) {

            return -1;

        } finally {
//            if (bIsIFrameControl) {
//                driver.switchTo().defaultContent();
//            }

        }

    }

    public int ExecuteSpanClickWithoutID(String clickAction, boolean bIsIFrameControl, String iFrameId) {
        WebElement objElement = null;

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have button - most probably htmlbutton which pain in axxxxx.
            //so getPageElements its type, class, name, displaytext, 
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] buttonAtrrs = pattern.split(clickAction);
            String buttonType = "";
            String buttonClass = "";
            String buttonName = "";
            String buttonDisplayText = "";
            String buttonOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                buttonType = buttonAtrrs[1];
                buttonClass = buttonAtrrs[2];
                buttonName = buttonAtrrs[3];
                buttonDisplayText = buttonAtrrs[4];
                buttonOnClick = buttonAtrrs[5];
            } catch (Exception ex) {

            }

            if (buttonClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                buttonClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }

            //try to find by 'name'
            List<WebElement> objElements = null;
            try {
                objElements = driver.findElements(By.name(buttonName));
            } catch (Exception ex) {
            }

            //try to find by 'display text'
            try {
                if (objElements.isEmpty()) {
                    //by xpath name
                    String label = buttonDisplayText;
                    objElements = driver.findElements(By.xpath("//button[contains(.,'" + label + "')]"));
                }
            } catch (Exception ex) {
            }

            //try to find by 'class'
            try {
                if (objElements.isEmpty()) {

                    if (bUseCSSSelector) {
                        //by CSSselector 
                        objElements = driver.findElements(By.cssSelector(buttonClass));

                    } else {
                        //by class name
                        objElements = driver.findElements(By.className(buttonClass));
                    }
                }
            } catch (Exception ex) {
                //to debug - remove later
                ex.printStackTrace();
            }

            objElement = null;

            if (objElements.size() == 1) {
                objElement = objElements.get(0);
            } else if (objElements.size() > 1) {

                //
                for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                    //search and filter using display text 
                    //need to check if any other better way to filter it
                    if (objElements.get(iCnt).getText().equalsIgnoreCase(buttonDisplayText)) {
                        objElement = objElements.get(iCnt);
                        break;
                    }
                }
            }

            //if still we could not locate this span webelement then follow rudimentory way
            objElements.clear();
            if (objElement == null) {
                List<WebElement> buttons = driver.findElements(By.tagName("span"));
                Properties p = new Properties();
                for (WebElement button : buttons) {

                    //print the links texts and links
                    String buttonID = "";
                    if (button.isDisplayed() && (ExpectedConditions.elementToBeClickable(button) != null)) {

                        if (button.getAttribute("id").isEmpty() || button.getAttribute("id").equals("")) {
                            //create button id with type, class and onclick
                            //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                            buttonID = "spspanid" + "_$_";

                            try {
                                buttonID += button.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getText() + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            try {
                                //because in case of user slelection of objects, we are remvoing brackets
                                buttonID += button.getAttribute("onclick").replace("()", "{}") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            //  emap.put(buttonID, aa.toString());

                        }

                        if (buttonID.equalsIgnoreCase(clickAction)) {
                            objElement = button;
                            break;
                        }
                    }

                }
            }
            //after above if and loop objElement(webelement) has to be found else return error

            if (objElement == null) {
                return -1;
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();

            if (bIsIFrameControl) {
                driver.switchTo().frame(iFrameId);
            }

            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

//            if (width <= 0 && height <= 0) {
//                //something is wrong with controls
//                return -1;
//            }
            Actions act = new Actions(driver);

            if (objElement.isEnabled()) {

                //objElement.click();
                String strElementype = objElement.getAttribute("type");
                if (objElement != null) {
                    try {
                        act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                    } catch (Exception ex) {
                        try {
                            ((JavascriptExecutor) driver).executeScript(
                                    "arguments[0].click();",
                                    objElement);
                        } catch (Exception ex1) {

                            try {
                                objElement.click();
                            } catch (Exception ex2) {
                                // any other worst case ???
                                //try to getPageElements correct locator
                                String Xpath = "//span[contains(@class,'" + buttonClass + "') and contains(@onclick,'" + buttonOnClick + "')]";
                                try {
                                    driver.findElement(By.xpath(Xpath)).click();
                                } catch (Exception ex3) {
                                    return -1;
                                }
                            }

                        }
                    }

                } else {

                    String userXpath;
//                    userXpath = spServerObj.getWebElementXPathForTestStep(executionID, "Please enter valid xpath of page-object for this test step:", 0);
//                    WebElement element = driver.findElement(By.xpath(userXpath));
//                    element.click();

                    // WebElement radio1 = driver.findElement(By.id("p-epithet"));
                    // radio1.click();
                }

                Thread.sleep(actionDelay);

                if (bIsIFrameControl) {
                    driver.switchTo().defaultContent();
                }

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    return 2;
                } else {

                    // CheckIfPopup windows is launched
                    boolean bPopUpWindowAppeared = false;
                    String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                    String subWindowHandler = null;

                    Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                    Iterator<String> iterator = handles.iterator();
                    while (iterator.hasNext()) {
                        subWindowHandler = iterator.next();
                    }

                    if (subWindowHandler != null) {
                        driver.switchTo().window(subWindowHandler); // switch to popup window
                        bPopUpWindowAppeared = true;
                    }

                    // Now you are in the popup window, perform necessary actions here
                    //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                    if (bPopUpWindowAppeared) {
                        return 3;
                    } else {
                        return 1;
                    }
                }

            }
            return 0;

        } catch (Exception e) {

            return -1;

        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                driver.switchTo().defaultContent();
            }

        }

    }

    public int ExecuteClick(String clickAction, boolean bIsIFrameControl, String iFrameId) {

        WebElement objElement = null;
        String visibleText = "";

        try {
            clickAction = clickAction.replace("\\", "");

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();

            if (bIsIFrameControl) {
                driver.switchTo().frame(iFrameId);
            }

            //try to find if there are multiple elements with same ID
            List<WebElement> listOfElements = driver.findElements(By.id(clickAction));
            List<WebElement> listOfFilteredElements = new ArrayList<WebElement>();
            for (WebElement we : listOfElements) {
                //ideally in this case only one should be visibel or applicable
                //hence currently checking for visible property
                if (we.isDisplayed() && we.isEnabled()) {
                    listOfFilteredElements.add(we);
                }
            }
            if (listOfFilteredElements.size() == 1) {
                objElement = listOfFilteredElements.get(0);
            } else if (listOfFilteredElements.size() > 1) {
                //then what  -lets decide later
                //currently return first one only
                objElement = listOfFilteredElements.get(0);
            } else {
                //ask user 
                //something is wrong
            }
//            By elementLocation = By.id(clickAction);

//            objElement = driver.findElement(elementLocation);
            if (objElement.isEnabled()) {

                String strElementype = objElement.getAttribute("type");
                //returns element if condition will be true means it returns element 
                //if element appears on the page and clickable
                try {
                    objElement = wait.until(ExpectedConditions.elementToBeClickable(objElement));
                } catch (Exception ex) {
                    //.reset element
                    By elementLocation = By.id(clickAction);
                    objElement = driver.findElement(elementLocation);
                }

                //sometime we getPageElements controls which are invisisble so remove those in previous control-optimization steps as well.
                //need to review
                if (objElement != null) {
                    visibleText = PerformWebElementClick(objElement);
                } else {
                    //need to review
                    String userXpath = "";
//                    userXpath = spServerObj.getWebElementXPathForTestStep(executionID, "Please enter valid xpath of page-object for this test step:", 0);
                    WebElement element = driver.findElement(By.xpath(userXpath));

                    visibleText = PerformWebElementClick(element);

                }
                Thread.sleep(actionDelay);

                //do not add clickable controls , as those can be repeated.
                if (bIsIFrameControl) {
                    driver.switchTo().defaultContent();
                }

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    return 2;
                } else {

                    // CheckIfPopup windows is launched
                    boolean bPopUpWindowAppeared = false;
                    String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                    String subWindowHandler = null;

                    Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                    Iterator<String> iterator = handles.iterator();
                    while (iterator.hasNext()) {
                        subWindowHandler = iterator.next();
                    }

                    if (subWindowHandler != null) {
                        driver.switchTo().window(subWindowHandler); // switch to popup window
                        bPopUpWindowAppeared = true;
                    }

                    // Now you are in the popup window, perform necessary actions here
                    //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                    if (bPopUpWindowAppeared) {
                        return 3;
                    } else {
                        return 1;
                    }
                }

            }
            return 0;

        } catch (Exception e) {

            try {
                String userXpath;

            } catch (Exception ex2) {
                return -1;
            }
            return 1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                driver.switchTo().defaultContent();
            }

        }

    }

    public int ExecuteButtonClickWithoutID(String clickAction, boolean bIsIFrameControl, String iFrameId) {
        WebElement objElement = null;

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have button - most probably htmlbutton which pain in axxxxx.
            //so getPageElements its type, class, name, displaytext, 
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] buttonAtrrs = pattern.split(clickAction);
            String buttonType = "";
            String buttonClass = "";
            String buttonName = "";
            String buttonDisplayText = "";
            String buttonOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                buttonType = buttonAtrrs[1];
                buttonClass = buttonAtrrs[2];
                buttonName = buttonAtrrs[3];
                buttonDisplayText = buttonAtrrs[4];
                buttonOnClick = buttonAtrrs[5];
            } catch (Exception ex) {

            }

            if (buttonClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                buttonClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }

            //try to find by 'name'
            List<WebElement> objElements = new ArrayList<>();

            //try find by display text
            try {
                //by xpath name
                String label = buttonDisplayText;
                label = label.replace("'", "\\\\'");
                objElements = driver.findElements(By.xpath("//button[contains(.,'" + label + "')]"));

            } catch (Exception ex) {
            }

            if (objElements.isEmpty()) {

                try {
                    objElements = driver.findElements(By.name(buttonName));
                } catch (Exception ex) {
                }
            }

            //try find by display class
            try {
                if (objElements.isEmpty()) {

                    if (bUseCSSSelector) {
                        //by CSSselector 
                        objElements = driver.findElements(By.cssSelector(buttonClass));

                    } else {
                        //by class name
                        objElements = driver.findElements(By.className(buttonClass));
                    }
                }
            } catch (Exception ex) {
                //to debug - remove later
                ex.printStackTrace();
            }

            objElement = null;

            //
//do the same for buttons
            if (objElements.isEmpty()) {
                List<WebElement> buttons = driver.findElements(By.tagName("button"));
                Properties p = new Properties();
                for (WebElement button : buttons) {

                    //print the links texts and links
                    String buttonID = "";
                    if (button.isDisplayed() && (ExpectedConditions.elementToBeClickable(button) != null)) {

                        if (button.getAttribute("id").isEmpty() || button.getAttribute("id").equals("")) {
                            //create button id with type, class and onclick
                            //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                            buttonID = "spbuttonid" + "_$_";

                            try {
                                buttonID += button.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getText() + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            try {
                                //because in case of user slelection of objects, we are remvoing brackets
                                buttonID += button.getAttribute("onclick").replace("()", "{}") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            //  emap.put(buttonID, aa.toString());

                        }

                        if (buttonID.equalsIgnoreCase(clickAction)) {
                            objElements.add(button);
                            break;
                        }
                    }

                }
            }

            if (objElements.isEmpty()) {
                return -1;
            }

            if (objElements.size() == 1) {
                objElement = objElements.get(0);
            } else if (objElements.size() > 1) {
                objElement = objElements.get(0); //temp code
                //
                for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                    //ask use which one to select
                    //t odo
                }
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();

            if (bIsIFrameControl) {
                driver.switchTo().frame(iFrameId);
            }

            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

//            if (width <= 0 && height <= 0) {
//                //something is wrong with controls
//                return -1;
//            }
            Actions act = new Actions(driver);

            if (objElement.isEnabled()) {

                //objElement.click();
                String strElementype = objElement.getAttribute("type");
                if (strElementype != null) {
                    try {
                        act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                    } catch (Exception ex) {
                        //this is shame
                        objElement.click();
                    }

                } else {

                    String userXpath;
//                    userXpath = spServerObj.getWebElementXPathForTestStep(executionID, "Please enter valid xpath of page-object for this test step:", 0);
//                    WebElement element = driver.findElement(By.xpath(userXpath));
//                    element.click();

                    // WebElement radio1 = driver.findElement(By.id("p-epithet"));
                    // radio1.click();
                }

                Thread.sleep(actionDelay);

                if (bIsIFrameControl) {
                    driver.switchTo().defaultContent();
                }

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    return 2;
                } else {

                    // CheckIfPopup windows is launched
                    boolean bPopUpWindowAppeared = false;
                    String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                    String subWindowHandler = null;

                    Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                    Iterator<String> iterator = handles.iterator();
                    while (iterator.hasNext()) {
                        subWindowHandler = iterator.next();
                    }

                    if (subWindowHandler != null) {
                        driver.switchTo().window(subWindowHandler); // switch to popup window
                        bPopUpWindowAppeared = true;
                    }

                    // Now you are in the popup window, perform necessary actions here
                    //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                    if (bPopUpWindowAppeared) {
                        return 3;
                    } else {
                        return 1;
                    }
                }

            }
            return 0;

        } catch (Exception e) {

            return -1;

        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                driver.switchTo().defaultContent();
            }

        }

    }

}
