package com.cognizant.scanner.selenium;

import com.cognizant.scanner.common.Constants;
import com.cognizant.scanner.common.Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.*;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.regex.Pattern;

@Slf4j
@Service
public class CommonGUIFunctions {

    public String UserSelectedControlIdetifier = "";
    public Map<String, UserSelectedObject> mapMultipleObjects = null;

     public String getBracketDisplayText(String VisibleText) {
        String displayText = VisibleText;
//        displayText = StringUtils.normalizeSpace(displayText);
        displayText = Util.normalize(displayText);
        int substringlength = displayText.length();

        try {
            //get only 25 chars of display text
            if (VisibleText.length() >= 25) {
                substringlength = 24;
                displayText = displayText.substring(0, substringlength) + "..";
            }
        } catch (Exception e) {
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
        }
        return " (" + displayText + ")";

    }

    public PageObject getUserSelectedControlIDLevelOne(String executionID,
            Set<PageObject> possibleActionableControls,
            int g_RunMode,
            Map<String, String> TestStepHashToControlID,
            String hashKey,
            String textStepDesc,
            Map<String, PageObject> mapPageObjects) {

        
        //get selected pageObject
        PageObject objPOSelected = new PageObject(null, "");
        System.out.println("Executing getUserSelectedControlIDLevelOne for -" + executionID + getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
        try {
            //we may have found multiple possible objects for given testStep to act on
            //now find most accurate control to click.
            //Note - this variable get sets to different values in different run_mode.
            //be careful
            UserSelectedControlIdetifier = "";
            mapMultipleObjects = new HashMap<String, UserSelectedObject>();
            if (possibleActionableControls.size() > 1) {

                //check we get valid control from storage (mixed mode - )
                if (g_RunMode == 3) {
                    if (TestStepHashToControlID.containsKey(hashKey)) {
                        UserSelectedControlIdetifier = TestStepHashToControlID.get(hashKey);
                    }
                }
                if (UserSelectedControlIdetifier.isEmpty()) {

                    String toFormArray = "";
                    for (PageObject objPO : possibleActionableControls) {

                        String displayText = "";
                        //get only 25 chars of display text
                        displayText = getBracketDisplayText(objPO.VisisbleText);

                        toFormArray += "," + objPO.ObjectId + displayText;

                        byte[] key = "".getBytes();
                        key = (objPO.ObjectId + displayText).getBytes();
                        long iHash = JenkinsHash.hash64(key, 10000);
                        String strhashKey = Long.toString(iHash);
                        UserSelectedObject putObject = new UserSelectedObject(objPO.ObjectId, objPO.bIsIFrameControl, objPO.iFrameId);

                        mapMultipleObjects.put(strhashKey, putObject);

                    }
                    toFormArray = toFormArray.substring(1);
                    String[] elementArray = toFormArray.split(",");
                    List<String> list = new ArrayList<String>();
                    for (String s : elementArray) {
                        list.add(s);
                    }
//                    List list = new List(actionArray);
                    String strMessage = textStepDesc + "\\n" + "Please select valid page-object from the list:";
                    System.out.println("Selecting Element from getUserSelectedControlIDLevelOne " + textStepDesc);
                  //  UserSelectedControlIdetifier = spServerObj.getElement(executionID, strMessage, list);

//                    userSlectedSteps++;
                }

            }

            //remove added Text at the end inside bracket to denote visitble text
            //but this is removing brackets present if any when we create our own ID 
            //with type_class_onclick()_visibletext format in case of NULL ID for html-buttons
            if(!StringUtils.isEmpty(UserSelectedControlIdetifier))
            {
                if(!StringUtils.startsWithIgnoreCase(UserSelectedControlIdetifier, "/")){
                    UserSelectedControlIdetifier = UserSelectedControlIdetifier.replaceAll("\\(.*?\\)", "");
                    UserSelectedControlIdetifier = UserSelectedControlIdetifier.substring(0, UserSelectedControlIdetifier.length() - 1);
                }
            }

            if (possibleActionableControls.size() == 1) {
                return possibleActionableControls.iterator().next();
            } else {
                if (mapPageObjects.containsKey(UserSelectedControlIdetifier)) {
                    return mapPageObjects.get(UserSelectedControlIdetifier);
                } else{
                    // user didn't select option from dropdown rather sent xpath from popup
                    objPOSelected.xPath = UserSelectedControlIdetifier;
                    return objPOSelected;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
        return objPOSelected;

    }

    public UserSelectedObject getUserSelectedControlIDLevelTwo(String executionID,
            String InvalidPageObjectId,
            Map<String, PageObject> mapPageDivs,
            String textStepDesc) {

        //we didn't find any valid page object so get item to be select from mapDIvs lements
        //get selected pageObject
        PageObject objPOSelected = null;
        UserSelectedObject UserControl = null;
        try {
            String toFormArray = "";
            UserSelectedControlIdetifier = "";
            mapMultipleObjects = new HashMap<String, UserSelectedObject>();

            for (Map.Entry<String, PageObject> entryPO : mapPageDivs.entrySet()) {
                String ActualObjectID = entryPO.getKey();
                PageObject PObjectDetails = entryPO.getValue();
                if(ActualObjectID != null && !ActualObjectID.equalsIgnoreCase(""))
                {
                    if (!(InvalidPageObjectId.toLowerCase().equalsIgnoreCase(ActualObjectID.toLowerCase()))) {
                        String displayText = "";
                        //get only 25 chars of display text
                        displayText = getBracketDisplayText(PObjectDetails.VisisbleText);
                        toFormArray += "," + ActualObjectID + displayText;
                        byte[] key = "".getBytes();
                        key = (ActualObjectID + displayText).getBytes();
                        long iHash = JenkinsHash.hash64(key, 10000);
                        String strhashKey = Long.toString(iHash);

                        mapMultipleObjects.put(strhashKey, new UserSelectedObject(PObjectDetails.ObjectId, PObjectDetails.bIsIFrameControl, PObjectDetails.iFrameId));
                    }
                }
            }
            toFormArray = toFormArray.substring(1);
            String[] elementArray = toFormArray.split(",");
            List<String> list = new ArrayList<String>();
            for (String s : elementArray) {
                list.add(s);
            }
            String strMessage = textStepDesc + "\\n" + "Please select valid control from the list";
//            ListDialog dialog = new ListDialog("Please select valid control from the list", list);
//
//            dialog.setOnOk(e -> System.out.println("Chosen item: " + dialog.getSelectedItem()));
//            dialog.show();
//            UserSelectedControlIdetifier = dialog.getSelectedItem().toString();
            System.out.println("Selecting Element from getUserSelectedControlIDLevelTwo " + strMessage);
            //UserSelectedControlIdetifier = spServerObj.getElement(executionID, strMessage, list);
//            userSlectedSteps++;

            if (!UserSelectedControlIdetifier.isEmpty()) {
                byte[] key = "".getBytes();
                key = (UserSelectedControlIdetifier).getBytes();
                long iHash = JenkinsHash.hash64(key, 10000);
                String strhashKey = Long.toString(iHash);
                UserControl = mapMultipleObjects.get(strhashKey);
            }
        } catch (Exception e) {
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
        }
        return UserControl;
    }

}
