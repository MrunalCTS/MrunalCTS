package com.cognizant.scanner.service;

import com.cognizant.scanner.dto.*;
import com.cognizant.scanner.model.*;
import io.github.bonigarcia.wdm.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.springframework.stereotype.*;

import java.util.*;

@Service
public class DriverExecution {

    public ResponseDTO executeTestStep(Step step, Map<String, WebDriver> temporaryDriverMap){

        ResponseDTO responseDTO = new ResponseDTO();

        if(step.getJobID() == null || step.getJobID() == ""){

            UUID uniqueID = UUID.randomUUID();
            String jobId = uniqueID.toString();

            WebDriverManager.chromedriver().setup();

            // Initialize the ChromeDriver
            WebDriver driver = new ChromeDriver();

            temporaryDriverMap.put(jobId, driver);

            step.setJobID(jobId);

        }

        WebDriver driver = temporaryDriverMap.get(step.getJobID());

        if(step.getAction().equals(Step.stepAction.LAUNCH)) {
            driver.get("https://www.amazon.com/");

            // Wait for the page to load (10 seconds)
            try {
                Thread.sleep(10000); // Sleep for 10 seconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        } else if(step.getAction().equals(Step.stepAction.CLICK)){
            // Click on the account list link
            driver.findElement(By.id("nav-link-accountList-nav-line-1")).click();

            // Wait for 2 seconds
            try {
                Thread.sleep(2000); // Sleep for 2 seconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } else if(step.getAction().equals(Step.stepAction.ENTER)){

            driver.findElement(By.id("ap_email")).sendKeys("amazon@gmail.com");

        } else if(step.getAction().equals(Step.stepAction.EXIT)){

            driver.quit();

        }

        responseDTO.setResponse("Executed Successfully");
        responseDTO.setExecutedStep(step);

        return responseDTO;
    }
}
