package com.cognizant.scanner.common;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.CaseUtils;
import org.springframework.core.io.ClassPathResource;

import javax.lang.model.SourceVersion;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.*;
import java.lang.*;

@Slf4j
public class Util {
    private Util() {
    }

    public static List<File> readFilesFromDir(String dirPath, String fileNamePattern) {
        File dir = Paths.get(dirPath).toFile();
        List<File> files = new ArrayList<>();
        if (dir.exists()) {
            File[] filesArray = dir.listFiles((dir1, name) -> name.matches(fileNamePattern));
            files.addAll(Arrays.asList(filesArray));
        }
        return files;
    }

    public static Object deserializeObjectFromString(String objectString)
            throws IOException, Exception {
        Object obj = new Object();
        try {
            byte[] data = Base64.getDecoder().decode(objectString);
            ObjectInputStream ois = new ObjectInputStream(
                    new ByteArrayInputStream(data));
            obj = ois.readObject();
            ois.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return obj;
    }

    public static String fileToBase64(String path){
        File originalFile = new File(path);
        String encodedBase64 = null;
        try (FileInputStream fileInputStreamReader = new FileInputStream(originalFile)) {
            byte[] bytes = new byte[(int)originalFile.length()];
            fileInputStreamReader.read(bytes);
            //encodedBase64 = new String(Base64.encodeBase64(bytes));
            encodedBase64 = new String(Base64.getEncoder().encodeToString(bytes));
            //System.out.println("+++"+encodedBase64);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return encodedBase64;
    }

    public static Properties getPropertyMap(String file) {
        InputStream in = null;
        try {
            Properties props = new Properties();
            //in = new FileInputStream(file);
            //in = Util.class.getClassLoader().getResourceAsStream(file);
            in = new ClassPathResource(file).getInputStream();
            props.load(in);
            return props;
        } catch (Exception e) {
            return null;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
            }
        }
    }

    public static String getCurrentDir() {
        String currentDir = "";
        try {
            File dir = new File(".");
            currentDir = dir.getCanonicalPath();
        } catch (Exception ex) {
            System.out.println("Could not locate current directory"+ ex.getMessage());
        }
        return currentDir;
    }

    public static String normalize(String inputString) {
        try {
            String normalized = inputString;

            normalized = normalized.replaceAll("[\n\r]", " ");
            normalized = normalized.replaceAll("[\n]", " ");
            normalized = normalized.replaceAll("[\t]", " ");
            normalized = normalized.replaceAll("[\r]", " ");

            normalized = normalized.replaceAll("[,]", "");
            normalized = normalized.replaceAll("[-]", " ");
            normalized = normalized.replaceAll("[_]", " ");
            normalized = normalized.replaceAll("[#]", " ");
            normalized = normalized.replaceAll("[&]", "");

            normalized = StringUtils.normalizeSpace(normalized);

            return normalized;
        } catch (Exception ex) {
            return inputString;
        }
    }

    public static String getClassName(String archetype, String pageFullUrl, String pageTitle, String action) {
        try {
            String className = "";
            // To maintain common page for all table pages in SDFC, set common page
            List<String> commonActions = Arrays.asList("ClickTableItem", "ClickTableMenuItem", "AssertEquals",
                    "LogOut", "ClickOnText", "VerifyTextElement", "VerifyTextElementContains");
            if(archetype.equalsIgnoreCase(Constants.ARCHETYPE_SFDC) && commonActions.contains(action)){
                className = "CommonHelperSFDC";
                return className;
            }
            URL fullUrl=new URL(pageFullUrl);
            String pageUrl = fullUrl.getFile();
            // construct classname with pageTitle if pageTitle is not too long
            if(StringUtils.countMatches(pageTitle, " ") < 4){
                pageTitle = pageTitle.replaceAll("[^A-Za-z0-9 ]", "");
                className = CaseUtils.toCamelCase(pageTitle,true,' ');
            }else {
                // construct classname with pageUrl
                if(!pageUrl.equalsIgnoreCase("/")){
                    //remove query params from url
                    pageUrl = pageUrl.split("\\?")[0];
                    // short url, so take full url
                    if(StringUtils.countMatches(pageUrl, "/") <= 2){
                        className = CaseUtils.toCamelCase(pageUrl,true,'/');
                    }else{
                        // long Url, so taking only first and last part of url
                        String[] pageArr = pageUrl.split("\\/");
                        pageUrl = pageArr[1]+" "+pageArr[pageArr.length-1];
                        className = CaseUtils.toCamelCase(pageUrl,true,' ');
                    }
                    /** If pageUrl is just base url with direct query param
                     * e.g. url as below,
                     * https://standuptocancer.org/?form=su2c_donate
                     * */
                    if(className.equalsIgnoreCase("/")) {
                        String urlHost = fullUrl.getHost();
                        if(StringUtils.contains(urlHost,"www.")){
                            className = StringUtils.substringBetween(urlHost, ".");
                        }else{
                            className = StringUtils.substringBefore(urlHost,".");
                        }
                        className = StringUtils.capitalize(className) + "HomeSubPage";
                    }
                }else {
                    // if pageTitle is too long and pageUrl is just base url
                    String urlHost = fullUrl.getHost();
                    if(StringUtils.contains(urlHost,"www.")){
                        className = StringUtils.substringBetween(urlHost, ".");
                    }else{
                        className = StringUtils.substringBefore(urlHost,".");
                    }
                    className = StringUtils.capitalize(className) + "Home";
                }
            }
            className = className.replaceAll("[^A-Za-z0-9 ]", "");
            //className = className.substring(0, Constants.MAX_CLASSNAME_LENGTH);
            return className;
            } catch (MalformedURLException malformedURLException) {
                malformedURLException.printStackTrace();
            }
        return "";
    }

    public static String getMethodNameForGeneric(String action, String userText, String testData) {
        String methodName = "";
        if(action.equalsIgnoreCase("If")|| action.equalsIgnoreCase("AssertTrue") || action.equalsIgnoreCase("AssertFalse")){
            methodName = action+" "+userText+" "+testData;
        }else{
            methodName = action+" "+userText;
        }
        methodName = methodName.replaceAll("[^A-Za-z0-9_ ]", " ");
        methodName = CaseUtils.toCamelCase(methodName, false, ' ');
        return methodName;
    }

    public static String getMethodNameForSFDC(String action, String userText, String testData) {
        String methodName = "";
        if(action.equalsIgnoreCase("If")|| action.equalsIgnoreCase("AssertTrue") || action.equalsIgnoreCase("AssertFalse")){
            methodName = action+" "+userText+" "+testData;
        }else if(action.equalsIgnoreCase("ClickTableItem")){
            methodName = "click Table Item";
        }else if(action.equalsIgnoreCase("ClickTableMenuItem")){
            methodName = "click Table Menu Item";
        }else if(action.equalsIgnoreCase("AssertEquals") && !userText.equalsIgnoreCase("popover")){
            methodName = "assert Equals Form Field";
        }else{
            methodName = action+" "+userText;
        }
        methodName = methodName.replaceAll("[^A-Za-z0-9_ ]", " ");
        methodName = CaseUtils.toCamelCase(methodName, false, ' ');
        return methodName;
    }

    public static String getElementObject(String userText){
        String elementObject = "";
        userText = userText.replaceAll("[^A-Za-z0-9_ ]", " ");
        elementObject = CaseUtils.toCamelCase(userText, false, ' ');
        // To avoid java format issues in script generation below scenarios have been handled
        //handling if elementObject starts with number (eg: 3xl -> threexl)
        if(elementObject.length()>0 && Character.isDigit(elementObject.charAt(0))){
            String[] numArr = new String[] {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
            String firstNumberEquivalent = numArr[Character.getNumericValue(elementObject.charAt(0))];
            elementObject = elementObject.substring(1);
            elementObject = firstNumberEquivalent + elementObject;
        }
        //avoiding elementObject is java keyword (eg: continue)
        if(SourceVersion.isKeyword(elementObject)){
            elementObject = elementObject + RandomStringUtils.random(4, false, true);
        }
        return elementObject;
    }

    public static String getUserText(String userText, String stepAction){
        /**Below if condition is explicitly for SFDC actions handle.
         * Need to observe and may alter the approach later */
        if(stepAction.equalsIgnoreCase("clickTableItem") && userText.contains("=")) {
            userText = userText.split("=")[0];
        } else if(stepAction.equalsIgnoreCase("clickTableMenuItem") && userText.contains("=")) {
            String[] strArr = userText.split("=");
            userText = strArr[0] + " Menu";
        } else if(stepAction.equalsIgnoreCase("ClickOnText")) {
            userText = "Item";
        } else if(stepAction.equalsIgnoreCase("VerifyTextElement")){
            userText = "VerifyElement";
        }
        else if(stepAction.equalsIgnoreCase("VerifyTextElementContains")){
            userText = "VerifyElementContains";
        }
        return userText;
    }

}
