package com.cognizant.scanner.model;

public class Verify {
    private String assertCondition;
    private String actualValue;
    private String expectedValue;

    public String getAssertCondition() {
        return assertCondition;
    }

    public void setAssertCondition(String assertCondition) {
        this.assertCondition = assertCondition;
    }

    public String getActualValue() {
        return actualValue;
    }

    public void setActualValue(String actualValue) {
        this.actualValue = actualValue;
    }

    public String getExpectedValue() {
        return expectedValue;
    }

    public void setExpectedValue(String expectedValue) {
        this.expectedValue = expectedValue;
    }
}
