package com.cognizant.scanner.exception;

public class LocatorNotFoundException extends Exception {

    // Default constructor
    public LocatorNotFoundException() {
        super("Locator not found");
    }

    // Constructor that accepts a custom error message
    public LocatorNotFoundException(String message) {
        super(message);
    }

    // Constructor that accepts a throwable cause
    public LocatorNotFoundException(Throwable cause) {
        super(cause);
    }

    // Constructor that accepts both a custom error message and a throwable cause
    public LocatorNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
