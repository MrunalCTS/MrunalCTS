package com.cognizant.scanner.dto;

import com.cognizant.scanner.model.*;

public class ResponseDTO {

    private String response;

    private Step executedStep;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public Step getExecutedStep() {
        return executedStep;
    }

    public void setExecutedStep(Step executedStep) {
        this.executedStep = executedStep;
    }
}
