package com.cognizant.scanner.model;

public class Types {

    public enum LocatorType {
        id, name, className, cssSelector, linkText, partialLinkText, tagName, xpath
    }

    public enum ActionMethod {
        defaultt, javascriptexecutor, actions
    }
}
