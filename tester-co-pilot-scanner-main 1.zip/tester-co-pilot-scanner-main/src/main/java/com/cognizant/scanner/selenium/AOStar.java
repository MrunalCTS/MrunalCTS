
package com.cognizant.scanner.selenium;

import com.cognizant.scanner.common.Constants;
import com.cognizant.scanner.common.Util;
import com.cognizant.scanner.model.*;
import com.google.common.base.Function;
import com.google.common.base.Strings;
import com.google.common.collect.Ordering;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.extern.slf4j.Slf4j;
import net.didion.jwnl.JWNL;
import net.didion.jwnl.dictionary.Dictionary;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WrapsDriver;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.*;

@Slf4j
@Service
public class AOStar {

    Map<String, Integer> ControlObjectToMatchLevel = new HashMap<String, Integer>();
    Map<String, Integer> ControlObjectToNoMatchLevel = new HashMap<String, Integer>();

    public static Dictionary dictionary;

    //ServerSendData serverlogSender;
    private boolean bPrintAoStarSetObjects = false;

    public AOStar() {
        try {
            try {
                //to do - write code to open this XML file and update below property-tag to absoute path of \\dict
                //<param name="dictionary_path" value=".\\dict"/>
                //JWNL.initialize(new FileInputStream(Constants.wordNetPath));
                JWNL.initialize(new ClassPathResource(Constants.wordNetPath).getInputStream());
                dictionary = Dictionary.getInstance();
                //bPrintAoStarSetObjects = _PrintAoStarSetObjects;
            } catch (FileNotFoundException ex) {
                //System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());
            }
        } catch (Exception ex) {
            //System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());
        }
    }

    public Map<String, Integer> getControlObjectToMatchLevel() {
        return ControlObjectToMatchLevel;
    }

    public void setControlObjectToMatchLevel(Map<String, Integer> ControlObjectToMatchLevel) {
        this.ControlObjectToMatchLevel = ControlObjectToMatchLevel;
    }

    public Map<String, Integer> getControlObjectToNoMatchLevel() {
        return ControlObjectToNoMatchLevel;
    }

    public void setControlObjectToNoMatchLevel(Map<String, Integer> ControlObjectToNoMatchLevel) {
        this.ControlObjectToNoMatchLevel = ControlObjectToNoMatchLevel;
    }

    public Set<PageObject> AOstarLevelZero(
            Map<String, PageObject> mapPageObjectsSearchByLinkText,
            String PossibleObjectIdentifier, WebDriver driver) {
        SendDisplayLogToClient("Executing AOStarLevel-0 - " + PossibleObjectIdentifier + " From Map Size -" + mapPageObjectsSearchByLinkText.size());
        Set<PageObject> possibleActionableControls = new HashSet<PageObject>();
        try {

            //search directly by LinkText or partial link Texts
            for (Map.Entry<String, PageObject> entryPO : mapPageObjectsSearchByLinkText.entrySet()) {

                //String ActualObjectID = entryPO.getKey(); this is UUID so no use
                PageObject PObjectDetails = entryPO.getValue();
                //these all are href and 'a'(anchor) controls so no need to check.
//                SendDisplayLogToClient(PossibleObjectIdentifier + " -> " + PObjectDetails.VisisbleText );
                if (PossibleObjectIdentifier.equalsIgnoreCase(PObjectDetails.VisisbleText)) {

                    //found the anchor or  href control
                    possibleActionableControls.add(PObjectDetails);
                    // It should return all the controls found by Direct or Partial Match

                    //break;
                }

                boolean isPresentIntheAttributes = findValueInAttribiutes(driver, PObjectDetails.objectElement, PossibleObjectIdentifier, false);

                if(isPresentIntheAttributes){
                    possibleActionableControls.add(PObjectDetails);
                }

                if(!isPresentIntheAttributes){
                    boolean isContainsIntheAttributes = findValueInAttribiutes(driver, PObjectDetails.objectElement, PossibleObjectIdentifier, true);

                    if(isContainsIntheAttributes){
                        possibleActionableControls.add(PObjectDetails);
                    }

                }
            }
//            possibleActionableControls.toString();
            return possibleActionableControls;

        } catch (Exception ex) {
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName() +  ex.getMessage());
            return possibleActionableControls;

        } finally {
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
            SendDisplayLogToClient("Number of Element found in AOStarLevel-0 =" + Integer.toString(possibleActionableControls.size()));
            printSetObject(possibleActionableControls);
        }
    }

    public Set<PageObject> AOstarLevelOne(
            Map<String, PageObject> mapPageObjects,
            String PossibleObjectIdentifier,
            String testData) {

        SendDisplayLogToClient("Executing AOStarLevel-1 -" + PossibleObjectIdentifier);
        Set<PageObject> possibleActionableControls = new HashSet<PageObject>();
        PossibleObjectIdentifier = PossibleObjectIdentifier.trim();

        try {
            int matchLevel = 0;
            int noMatchLevel = 0;

            //before going for reg-ex based search , search on direct ID find
            //this code is soomehwere present already but not fiding it so adding here again
            for (Map.Entry<String, PageObject> entryPO : mapPageObjects.entrySet()) {
                String ActualObjectID = entryPO.getKey();
                if (Strings.isNullOrEmpty(ActualObjectID) || ActualObjectID == null || ActualObjectID.isEmpty()) {
                    continue;
                }
                PageObject PObjectDetails = entryPO.getValue();
                if (ActualObjectID.trim().equalsIgnoreCase(PossibleObjectIdentifier)) {
                    possibleActionableControls.add(PObjectDetails);
                    SendDisplayLogToClient("Found Direct match with object ID - " + ActualObjectID);
                    return possibleActionableControls;
                }
            }
            // Now if no direct ID base match then find using RegEx
            ControlObjectToMatchLevel = new HashMap<String, Integer>();
            for (Map.Entry<String, PageObject> entryPO : mapPageObjects.entrySet()) {
                String ActualObjectID = entryPO.getKey();
                if (Strings.isNullOrEmpty(ActualObjectID) || ActualObjectID == null || ActualObjectID.isEmpty()) {
                    continue;
                }
                PageObject PObjectDetails = entryPO.getValue();

                matchLevel = 0; //reset match levels for this object
                noMatchLevel = 0;

                //1. first try to location PageObject based on identifier text.
                //e.g. if teststep says 'click on search' then we are searching for PageObject whose
                // Po.ID is possibly matching with 'search' or similar words.
//                    SendDisplayLogToClient("finding match between :::: " + PossibleObjectIdentifier + " --->>" + ActualObjectID);
                PossibleObjectIdentifier = PossibleObjectIdentifier.replaceAll("[,]", "");
                PossibleObjectIdentifier = PossibleObjectIdentifier.replaceAll("[-]", " ");
                PossibleObjectIdentifier = PossibleObjectIdentifier.replaceAll("[_]", " ");
                PossibleObjectIdentifier = PossibleObjectIdentifier.replaceAll("[#]", " ");
                PossibleObjectIdentifier = PossibleObjectIdentifier.replaceAll("[&]", "");

                PossibleObjectIdentifier = StringUtils.normalizeSpace(PossibleObjectIdentifier);

//                here are 3 alternates:
//                ^_+ : any sequence of spaces at the beginning of the string
//                Match and replace with $1, which captures the empty string
//                _+$ : any sequence of spaces at the end of the string
//                Match and replace with $1, which captures the empty string
//                (_)+ : any sequence of spaces that matches none of the above, meaning it's in the middle
//                Match and replace with $1, which captures a single space
                //PossibleObjectIdentifier = PossibleObjectIdentifier.replaceAll("^ +| +$|( )+", "$1");
                String[] displayTextArray = PossibleObjectIdentifier.split("\\b \\b"); // This can move above

                for (int iCnt = 0; iCnt < displayTextArray.length; iCnt++) {

                    boolean bResult = false;
                    try {
                        bResult = NLPSupport.getSynonyms(displayTextArray[iCnt].toLowerCase(), ActualObjectID.toLowerCase());
                    } catch (Exception e) {
                        //do nothing
                        System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName() + e.getMessage());
                    }
                    if (bResult) {
                        possibleActionableControls.add(PObjectDetails);

                        matchLevel++;
                        ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                        bResult = false;
                    } // try to find using display text
                    else {
                        //first try
                        try {
                            bResult = NLPSupport.getSynonyms(displayTextArray[iCnt].toLowerCase(), PObjectDetails.VisisbleText.toLowerCase());
                        } catch (Exception e) {
                            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName() +  e.getMessage());
                        }
                        if (bResult) {
                            possibleActionableControls.add(PObjectDetails);

                            matchLevel++;
                            ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                            bResult = false;
                        } else {
                            //second try
                            try {
                                bResult = NLPSupport.getSynonyms(displayTextArray[iCnt].toLowerCase(), PObjectDetails.VisisbleText.toLowerCase());
                            } catch (Exception e) {
                                 System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
                            }
                            if (bResult) {
                                possibleActionableControls.add(PObjectDetails);

                                matchLevel++;
                                ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                                bResult = false;
                            } else {
                                //check if we can find using display text and data to be entered
                                //only if this test steps is associated with data
                                //this is specifically for option buttons or check boxes
                                if (!testData.isEmpty()) {

                                    try {
                                        boolean bRetVal1 = NLPSupport.getSynonyms(testData.toLowerCase(), ActualObjectID.toLowerCase());
                                        boolean bRetVal2 = NLPSupport.getSynonyms(testData.replaceAll("\\b \\b", "").toLowerCase(), ActualObjectID.toLowerCase());

                                        bResult = bRetVal1 || bRetVal2;
                                    } catch (Exception e) {
                                         System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
                                    }
                                    if (bResult) {
                                        possibleActionableControls.add(PObjectDetails);

                                        matchLevel++;
                                        ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                                        bResult = false;
                                    } else {
                                        try {
                                            bResult = NLPSupport.getSynonyms(testData.toLowerCase(), PObjectDetails.VisisbleText.toLowerCase());
                                        } catch (Exception e) {
                                            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
                                        }
                                        if (bResult) {
                                            possibleActionableControls.add(PObjectDetails);

                                            matchLevel++;
                                            ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                                            bResult = false;
                                        }
                                    }
                                }
                            }
                        }
                    }

                }

            }
            return possibleActionableControls;
        } catch (Exception ex) {
            //return whatever is present.
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());
            return possibleActionableControls;
        } finally {
            SendDisplayLogToClient("Number of Element found in AOStarLevel-1 =" + Integer.toString(possibleActionableControls.size()));
            printSetObject(possibleActionableControls);
        }
    }

    public Set<PageObject> AOstarLevelTwo(
            Map<String, PageObject> mapPageObjects,
            String PossibleObjectIdentifier) {

        SendDisplayLogToClient("Executing AOStarLevel-2 -" + PossibleObjectIdentifier);

        //level 2 search with AOStar
        //if not found then only  search in wordnet
        int matchLevel = 0;
        int noMatchLevel = 0;

        Set<PageObject> possibleActionableControls = new HashSet<PageObject>();

        try {
            SendDisplayLogToClient("Possible Page Objects :: " + mapPageObjects.size());
            for (Map.Entry<String, PageObject> entryPO : mapPageObjects.entrySet()) {
                String ActualObjectID = entryPO.getKey();
                PageObject PObjectDetails = entryPO.getValue();

                matchLevel = 0; //reset match level for this object
                noMatchLevel = 0;

                //1. first try to location PageObject based on identifier text.
                //e.g. if teststep says 'click on search' then we are searching for PageObject whose
                // Po.ID is possibly matching with 'search' or similar words.
                //SendDisplayLogToClient("finding match between :::: " + PossibleObjectIdentifier + " --->>" + ActualObjectID);
                String[] displayTextArray = PossibleObjectIdentifier.split("\\b \\b");
                //SendDisplayLogToClient("Display Text Array:: " + displayTextArray.length);
                for (int iCnt = 0; iCnt < displayTextArray.length; iCnt++) {
                    boolean bResult = false;
                    try {
                        bResult = NLPSupport.getWordNetMatch(displayTextArray[iCnt], ActualObjectID);

                    } catch (Exception e) {
                         System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
                    }
                    if (bResult) {
                        possibleActionableControls.add(PObjectDetails);
                        matchLevel++;

                        ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                    }

                }
            }

            return possibleActionableControls;
        } catch (Exception ex) {
            //return whatever is present.
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());
            return possibleActionableControls;
        } finally {
            SendDisplayLogToClient("Number of Element found in AOStarLevel-2 =" + possibleActionableControls.size());
            printSetObject(possibleActionableControls);

        }
    }

    public Set<PageObject> AOstarLevelThree(
            Map<String, PageObject> mapPageObjects,
            String PossibleObjectIdentifier,
            String testData,
            Map<String, PageObject> mapInvisiblePageObjects) {

        SendDisplayLogToClient("Executing AOStarLevel-3 for -" + PossibleObjectIdentifier);

        //level 3 search with AOStar
        //if still not found then only  search in invisible control list as clicking on some controls
        //may have displaced new controls which needs to be clicked now like option button clicks etc
        int matchLevel = 0;
        int noMatchLevel = 0;

        Set<PageObject> possibleActionableControls = new HashSet<PageObject>();

        try {
            for (Map.Entry<String, PageObject> entryPO : mapInvisiblePageObjects.entrySet()) {
                String ActualObjectID = entryPO.getKey();
                PageObject PObjectDetails = entryPO.getValue();

                matchLevel = 0; //reset match level for this object
                noMatchLevel = 0;

                //1. first try to location PageObject based on identifier text.
                //e.g. if teststep says 'click on search' then we are searching for PageObject whose
                // Po.ID is possibly matching with 'search' or similar words.
//                        SendDisplayLogToClient("finding match between :::: " + PossibleObjectIdentifier + " --->>" + ActualObjectID);
                String[] displayTextArray = PossibleObjectIdentifier.split("\\b \\b");

                for (int iCnt = 0; iCnt < displayTextArray.length; iCnt++) {
                    boolean bResult = false;
                    try {
                        bResult = NLPSupport.getSynonyms(displayTextArray[iCnt].toLowerCase(), ActualObjectID.toLowerCase());
                    } catch (Exception e) {
                       System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
                    }
                    if (bResult) {
                        possibleActionableControls.add(PObjectDetails);

                        matchLevel++;
                        ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                        bResult = false;
                    } // try to find using display text
                    else {
                        try {
                            bResult = NLPSupport.getSynonyms(displayTextArray[iCnt].toLowerCase(), PObjectDetails.VisisbleText.toLowerCase());
                        } catch (Exception e) {
                            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
                        }
                        if (bResult) {
                            possibleActionableControls.add(PObjectDetails);

                            matchLevel++;
                            ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                            bResult = false;
                        } else {
                            //check if we can find using display text and data to be entered
                            //only if this test steps is associated with data
                            //this is specifically for option buttons or check boxes
                            if (!testData.isEmpty()) {

                                try {
                                    boolean bRetVal1 = NLPSupport.getSynonyms(testData.toLowerCase(), ActualObjectID.toLowerCase());
                                    boolean bRetVal2 = NLPSupport.getSynonyms(testData.replaceAll("\\b \\b", "").toLowerCase(), ActualObjectID.toLowerCase());

                                    bResult = bRetVal1 || bRetVal2;
                                } catch (Exception e) {
                                   System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
                                }
                                if (bResult) {
                                    possibleActionableControls.add(PObjectDetails);

                                    matchLevel++;
                                    ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                                    bResult = false;
                                } else {
                                    try {
                                        bResult = NLPSupport.getSynonyms(testData.toLowerCase(), PObjectDetails.VisisbleText.toLowerCase());
                                    } catch (Exception e) {
                                        System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
                                    }
                                    if (bResult) {
                                        possibleActionableControls.add(PObjectDetails);

                                        matchLevel++;
                                        ControlObjectToMatchLevel.put(ActualObjectID, matchLevel);
                                        bResult = false;
                                    }
                                }
                            }
                        }
                    }

                }
            }
            return possibleActionableControls;
        } catch (Exception ex) {
            //return whatever we have
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());
            return possibleActionableControls;
        } finally {
            SendDisplayLogToClient("Number of Element found in AOStarLevel-3 =" + possibleActionableControls.size());
            printSetObject(possibleActionableControls);

        }
    }

    public void printSetObject(Set<PageObject> pObject) {
        if (!bPrintAoStarSetObjects) {
            return;
        }
        for (PageObject objPO : pObject) {
            SendDisplayLogToClient(objPO.ObjectId + "   :   " + objPO.VisisbleText);
        }

    }

    public Set<PageObject> AOstarLevelFour(
            Set<PageObject> setPageObjects,
            Step step) {

        SendDisplayLogToClient("Executing AOStarLevel-4 ");

        //level 4 search with AOStar
        //if still we have multiple object found then search on level of match of display text
        //with that of test step description
        int matchLevel = 0;
        Set<PageObject> possibleActionableControls = new HashSet<PageObject>();

        String TestStepText = step.getFieldValue();
        TestStepText = TestStepText.toLowerCase();
        String[] TestStepTextArray = TestStepText.toLowerCase().split("\\b \\b");
        int iTestStepTextArrayLength = TestStepTextArray.length;

        Set<String> setTestStepStrings = new HashSet<String>();
        Collections.addAll(setTestStepStrings, TestStepTextArray);

        Map<String, Integer> ControlObjectToMatchCount = new HashMap<String, Integer>();
        Map<String, PageObject> mapTemp = new HashMap<String, PageObject>();

        try {
            for (PageObject objPO : setPageObjects) {

                PageObject PObjectDetails = objPO;

//                SendDisplayLogToClient("Scanning Control-ID :->" + PObjectDetails.ObjectId);
                matchLevel = 0; //reset match level for this object

                String displayString = PObjectDetails.VisisbleText.toLowerCase();
                displayString = displayString.replaceAll("[\n\r]", " ");
                displayString = displayString.replaceAll("[\n]", " ");
                displayString = displayString.replaceAll("[\t]", " ");
                displayString = displayString.replaceAll("[\r]", " ");

                String[] displayStringArray = displayString.toLowerCase().split("\\b \\b");
                int iDisplayStringCnt = displayStringArray.length;

                //search every word from test step and match to that of displaytext of possible controls
                boolean bResult = false;
                //check of both texts have same lengths if yes directly match indexed words
                int matches = 0;
//                if (iTestStepTextArrayLength == iDisplayStringCnt) {
//
//                    for (int iCnt = 0; iCnt < displayStringArray.length; iCnt++) {
//                        if (displayStringArray[iCnt].equalsIgnoreCase(TestStepTextArray[iCnt])) {
//                            matches++;
//                        } else {
//
//                        }
//                    }
//                    if (matches > 0) {
//                        possibleActionableControls.add(PObjectDetails);
//                        ControlObjectToMatchCount.put(PObjectDetails.ObjectId, iTestStepTextArrayLength);
//                        mapTemp.put(PObjectDetails.ObjectId, objPO);
//                    }
//                } else
                {
                    matches = 0;
                    for (int iCnt = 0; iCnt < TestStepTextArray.length; iCnt++) {

                        Matcher matcher = Pattern.compile("\\b" + TestStepTextArray[iCnt] + "\\b", Pattern.CASE_INSENSITIVE).matcher(displayString);
                        while (matcher.find()) {
                            matches++;
                        }

                    }
                    // If matches equal to 0 then - this happens when same words does not match because of space or _
                    // or any other Char.
                    int displayTotalAscii = 0;
                    int tcStepTotalAscii = 0;
                    if (matches == 0) {
                        displayTotalAscii = getASCIIValue(displayString);

                        ///
                        tcStepTotalAscii += getASCIIValue(TestStepText);

                        if (tcStepTotalAscii == displayTotalAscii) {
                            // This is best fit
                            ControlObjectToMatchCount.put(PObjectDetails.ObjectId, 0);
                            mapTemp.put(PObjectDetails.ObjectId, objPO);

                        } else {
                            TestStepText = TestStepText.replaceAll(" ", "");
                            displayString = displayString.replaceAll(" ", "");
                            displayTotalAscii = 0;
                            tcStepTotalAscii = 0;

                            displayTotalAscii = getASCIIValue(displayString);
                            ///
                            tcStepTotalAscii = getASCIIValue(TestStepText);

                            if (displayTotalAscii == tcStepTotalAscii) {
                                ControlObjectToMatchCount.put(PObjectDetails.ObjectId, 0);
                                mapTemp.put(PObjectDetails.ObjectId, objPO);
                            } else {
                                ControlObjectToMatchCount.put(PObjectDetails.ObjectId, (iDisplayStringCnt - matches));
                                mapTemp.put(PObjectDetails.ObjectId, objPO);
                            }

                        }

                    } else {
                        //put value of total cnt - match cnt.
                        //lesser the value msot accurate the match
                        // 0 means exact match
                        ControlObjectToMatchCount.put(PObjectDetails.ObjectId, (iDisplayStringCnt - matches));
                        mapTemp.put(PObjectDetails.ObjectId, objPO);
                    }
                }

            }
            //first try to get if we get controls with exact count and word match
            for (Map.Entry<String, Integer> entryCOMatch : ControlObjectToMatchCount.entrySet()) {
                if (entryCOMatch.getValue() == 0) {
                    possibleActionableControls.add(mapTemp.get(entryCOMatch.getKey()));
                }
            }
            if (possibleActionableControls.size() > 0) {
                return possibleActionableControls;
            }

            //else
            //find lowest and same matchcount
            int iMatchCount = 99999; //setting max count
            for (Map.Entry<String, Integer> entryCOMatch : ControlObjectToMatchCount.entrySet()) {
                if (entryCOMatch.getValue() <= iMatchCount) {
                    iMatchCount = entryCOMatch.getValue();
                }
            }
            //add all those controls with same and lowest match-count
            for (Map.Entry<String, Integer> entryCOMatch : ControlObjectToMatchCount.entrySet()) {
                if (entryCOMatch.getValue() == iMatchCount) {
                    possibleActionableControls.add(mapTemp.get(entryCOMatch.getKey()));
                }
            }

            //dont send back empty set of controls.
            if (possibleActionableControls.size() <= 0) {
                return setPageObjects;
            } else {
                return possibleActionableControls;
            }
        } catch (Exception ex) {
            //return whatever we have
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());
            SendDisplayLogToClient("Exception In AOStarLevel-4" + ex.getMessage());

            if (possibleActionableControls.size() <= 0) {
                return setPageObjects;
            } else {
                return possibleActionableControls;
            }
        } finally {

            SendDisplayLogToClient("Executing AOStarLevel-4 =" + possibleActionableControls.size());
            printSetObject(possibleActionableControls);

        }
    }

    public int getASCIIValue(String strEvaluate) {
        int lAscii = 0;
        try {
            char[] displayArray = new char[strEvaluate.length()];
            strEvaluate.getChars(0, strEvaluate.length(), displayArray, 0);

            for (int count = 0; count < (displayArray.length); count++) {
                int ascii = (int) displayArray[count];
                lAscii += ascii;

            }
        } catch (Exception e) {
            SendDisplayLogToClient("Exception In getASCIIValue" + e.getMessage());
            return 0;
        }
        return lAscii;

    }

    public Set<PageObject> AOstarLevelFive(
            Set<PageObject> setPageObjects,
            Step step) {

        SendDisplayLogToClient("Executing AOStarLevel-5 ");

        //level 5 search with AOStar
        //if still we have multiple object found then search on level of match of display text
        //with that of test step data
        //this is specially for dropdown with customer controls.
        Set<PageObject> possibleActionableControls = new HashSet<PageObject>();

        int matchLevel = 0;
        String TestStepData = step.getTestData();
        if (TestStepData.length() <= 0) {
            return setPageObjects;
        };
        String[] TestStepDataArray = TestStepData.toLowerCase().split("\\b \\b");
        int iTestStepDataArrayLength = TestStepDataArray.length;

        Set<String> setTestStepStrings = new HashSet<String>();
        Collections.addAll(setTestStepStrings, TestStepDataArray);

        Map<String, Integer> ControlObjectToMatchCount = new HashMap<String, Integer>();
        Map<String, PageObject> mapTemp = new HashMap<String, PageObject>();

        try {
            for (PageObject objPO : setPageObjects) {

                PageObject PObjectDetails = objPO;

//                SendDisplayLogToClient("Scanning Control-ID : " + PObjectDetails.ObjectId);
                matchLevel = 0; //reset match level for this object

                String displayString = PObjectDetails.VisisbleText;
                displayString = displayString.replaceAll("[\n\r]", " ");
                displayString = displayString.replaceAll("[\n]", " ");
                displayString = displayString.replaceAll("[\t]", " ");
                displayString = displayString.replaceAll("[\r]", " ");

                String[] displayStringArray = displayString.toLowerCase().split("\\b \\b");
                int iDisplayStringCnt = displayStringArray.length;

                //search every word from test step and match to that of displaytext of possible controls
                boolean bResult = false;
                //check of both texts have same lengths if yes directly match indexed words
                int matches = 0;
//                if (iTestStepTextArrayLength == iDisplayStringCnt) {
//
//                    for (int iCnt = 0; iCnt < displayStringArray.length; iCnt++) {
//                        if (displayStringArray[iCnt].equalsIgnoreCase(TestStepTextArray[iCnt])) {
//                            matches++;
//                        } else {
//
//                        }
//                    }
//                    if (matches > 0) {
//                        possibleActionableControls.add(PObjectDetails);
//                        ControlObjectToMatchCount.put(PObjectDetails.ObjectId, iTestStepTextArrayLength);
//                        mapTemp.put(PObjectDetails.ObjectId, objPO);
//                    }
//                } else
                {
                    matches = 0;
                    for (int iCnt = 0; iCnt < TestStepDataArray.length; iCnt++) {

                        Matcher matcher = Pattern.compile("\\b" + TestStepDataArray[iCnt] + "\\b", Pattern.CASE_INSENSITIVE).matcher(displayString);
                        while (matcher.find()) {
                            matches++;
                        }

                    }

                    {
                        //put value of total cnt - match cnt.
                        //lesser the value msot accurate the match
                        // 0 means exact match
                        ControlObjectToMatchCount.put(PObjectDetails.ObjectId, (iDisplayStringCnt - matches));
                        mapTemp.put(PObjectDetails.ObjectId, objPO);
                    }
                }

            }
            //first try to get if we get controls with exact count and word match
            for (Map.Entry<String, Integer> entryCOMatch : ControlObjectToMatchCount.entrySet()) {
                if (entryCOMatch.getValue() == 0) {
                    possibleActionableControls.add(mapTemp.get(entryCOMatch.getKey()));
                }
            }
            if (possibleActionableControls.size() > 0) {
                return possibleActionableControls;
            }

            //else
            //find lowest and same matchcount
            int iMatchCount = 99999; //setting max count
            for (Map.Entry<String, Integer> entryCOMatch : ControlObjectToMatchCount.entrySet()) {
                if (entryCOMatch.getValue() <= iMatchCount) {
                    iMatchCount = entryCOMatch.getValue();
                }
            }
            //add all those controls with same and lowest match-count
            for (Map.Entry<String, Integer> entryCOMatch : ControlObjectToMatchCount.entrySet()) {
                if (entryCOMatch.getValue() == iMatchCount) {
                    possibleActionableControls.add(mapTemp.get(entryCOMatch.getKey()));
                }
            }

            //dont send back empty set of controls.
            if (possibleActionableControls.size() <= 0) {
                return setPageObjects;
            } else {
                return possibleActionableControls;
            }
        } catch (Exception e) {
            //return whatever we have
            if (possibleActionableControls.size() <= 0) {
                return setPageObjects;
            } else {
                return possibleActionableControls;
            }
        } finally {
            SendDisplayLogToClient("Number of Element found in AOStarLevel-5 =" + Integer.toString(possibleActionableControls.size()));

        }
    }

    public Set<PageObject> AOstarLevelSix(
            Set<PageObject> setPageObjects,
            Step step) {

        SendDisplayLogToClient("Executing AOStarLevel-6....");

        //level 6 search with AOStar
        //if still we have multiple object found then search the sequence of all pageobjects text(visible text)
        //if "sequence" of test-data is same as that of pageobjects id or visible text
        //then filter those.
        //also need to check is any of these objects have parent-child relationship with same ID/display name
        //so that we can remove of such controls. like parent or child
        Set<PageObject> possibleActionableControls = new HashSet<PageObject>();

        String TestStepData = step.getFieldValue();
        if (TestStepData.length() <= 0) {
            return setPageObjects;
        };

        String DisplayControlType = TestStepData.toLowerCase();
        DisplayControlType = DisplayControlType.replaceAll("[\n\r]", " ");
        DisplayControlType = DisplayControlType.replaceAll("[\n]", " ");
        DisplayControlType = DisplayControlType.replaceAll("[\t]", " ");
        DisplayControlType = DisplayControlType.replaceAll("[\r]", " ");
        DisplayControlType = StringUtils.normalizeSpace(DisplayControlType);

        Map<String, PageObject> mapTemp = new HashMap<String, PageObject>();

        try {
            for (PageObject objPO : setPageObjects) {

                PageObject PObjectDetails = objPO;

                String displayString = PObjectDetails.VisisbleText;
                displayString = displayString.replaceAll("[\n\r]", " ");
                displayString = displayString.replaceAll("[\n]", " ");
                displayString = displayString.replaceAll("[\t]", " ");
                displayString = displayString.replaceAll("[\r]", " ");
                displayString = StringUtils.normalizeSpace(displayString);

                if (StringUtils.equalsIgnoreCase(DisplayControlType, displayString)) {
                    mapTemp.put(DisplayControlType, objPO);
                }

            }

            possibleActionableControls.addAll(mapTemp.values());

            //at this stage if we have more than 1 controls
            //filter it based on - if there are some controls which has parent-child relationship.
            for (PageObject objPO : possibleActionableControls) {

                PageObject PObject = objPO;
                WebElement objElement = PObject.objectElement;
                WebDriver retrivedDriver = ((WrapsDriver) objElement).getWrappedDriver();

                WebElement parentElement = (WebElement) ((JavascriptExecutor) retrivedDriver).executeScript(
                        "return arguments[0].parentNode;", objElement);

                Set<PageObject> setBufferPageObjects = new HashSet<PageObject>();
                setBufferPageObjects.addAll(possibleActionableControls);
                for (PageObject objPONext : setBufferPageObjects) {

                    if (objPONext.equals(objPO)) {
                        continue;
                    }

                    String parentElementID = GetElementID(parentElement);

                    String filteredParentElmentID = GetActualElementID(parentElementID);
                    String filteredThisElementID = GetActualElementID(objPONext.ObjectId);

                    boolean bEqual = StringUtils.equalsIgnoreCase(filteredParentElmentID, filteredThisElementID);
                    if (bEqual) {
                        //it means parent of firstloop-element is present in this set<>
                        //so keep either parent or child
                        //here i am keeping child
                        String displayString = objPONext.VisisbleText;
                        displayString = displayString.replaceAll("[\n\r]", " ");
                        displayString = displayString.replaceAll("[\n]", " ");
                        displayString = displayString.replaceAll("[\t]", " ");
                        displayString = displayString.replaceAll("[\r]", " ");
                        displayString = StringUtils.normalizeSpace(displayString);
                        mapTemp.remove(displayString);

                    }

                }

            }

            if (possibleActionableControls.size() > 0) {
                return possibleActionableControls;
            }

            //dont send back empty set of controls.
            if (possibleActionableControls.size() <= 0) {
                return setPageObjects;
            } else {
                return possibleActionableControls;
            }
        } catch (Exception e) {
            //return whatever we have
            if (possibleActionableControls.size() <= 0) {
                return setPageObjects;
            } else {
                return possibleActionableControls;
            }
        } finally {
            SendDisplayLogToClient(Integer.toString(possibleActionableControls.size()));

        }
    }

    public Set<PageObject> AOstarLevelSeven(
            Set<PageObject> setPageObjects,
            Step step) {

        SendDisplayLogToClient("Executing AOStarLevel-7....");

        //level 7 search with AOStar
        //if still we have multiple object found then search based of the object type selection preference order
        //as provided by user in configuration
        int iAnchorPref = 1;
        int iInputPref = 1;
        int iImagePref = 1;
        int iButtonPref = 1;
        int iSpanPref = 1;
        int iDivPref = 1;
        int iIconPref = 1;
        int iLabelPref = 1;
        int iRadioPref = 1;
        int iSelectPref = 1;

        //String filename = Util.getCurrentDir() + File.separator + Constants.ROBOT_PROPERTIES;
        String filename = Constants.AGENT_PATH;
        Properties propMap = new Properties();

        iAnchorPref = Integer.parseInt(propMap.getProperty("anchorpref", "1"));
        iInputPref = Integer.parseInt(propMap.getProperty("inputpref", "1"));
        iImagePref = Integer.parseInt(propMap.getProperty("imagepref", "1"));
        iButtonPref = Integer.parseInt(propMap.getProperty("buttonpref", "1"));
        iSpanPref = Integer.parseInt(propMap.getProperty("spanpref", "1"));
        iDivPref = Integer.parseInt(propMap.getProperty("divpref", "1"));
        iIconPref = Integer.parseInt(propMap.getProperty("iconv", "1"));
        iLabelPref = Integer.parseInt(propMap.getProperty("labelpref", "1"));
        iRadioPref = Integer.parseInt(propMap.getProperty("radiopref", "1"));
        iSelectPref = Integer.parseInt(propMap.getProperty("selectpref", "1"));

        List<Integer> objectPrefs = Arrays.asList(iAnchorPref, iInputPref, iImagePref, iButtonPref, iSpanPref, iDivPref, iIconPref, iLabelPref, iRadioPref, iSelectPref);
        objectPrefs.sort(Ordering.natural());

        Set<PageObject> possibleActionableControls = new HashSet<PageObject>();

        String TestStepData = step.getFieldValue();
        if (TestStepData.length() <= 0) {
            return setPageObjects;
        };

        Map<String, PageObject> mapTemp = new HashMap<String, PageObject>();
        List<PageObjectEx> PageObjectWithPrefs = new ArrayList<PageObjectEx>();

        try {
            for (PageObject objPO : setPageObjects) {

                PageObject PObjectDetails = objPO;
//                ListIterator<Integer> prefIterator = objectPrefs.listIterator();
//                while (prefIterator.hasNext()) {
//                    int objectPref = prefIterator.next();
//                }
                switch (PObjectDetails.ObjectType.toLowerCase()) {
                    case "anchor":
                    case "href":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iAnchorPref));
                        break;
                    case "input":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iInputPref));
                        break;
                    case "image":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iImagePref));
                        break;
                    case "button":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iButtonPref));
                        break;
                    case "span":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iSpanPref));
                        break;
                    case "div":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iDivPref));
                        break;
                    case "icon":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iIconPref));
                        break;
                    case "label":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iLabelPref));
                        break;
                    case "radio":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iRadioPref));
                        break;
                    case "select":
                        PageObjectWithPrefs.add(new PageObjectEx(PObjectDetails, iSelectPref));
                        break;

                }

            }
            Ordering<PageObjectEx> PrefernceOrdering = Ordering.natural().nullsFirst()
                    .onResultOf(new Function<PageObjectEx, Comparable>() {
                        @Override
                        public Comparable apply(PageObjectEx pObject) {
                            return pObject.objectPreference;
                        }
                    });

            PageObjectWithPrefs.sort(PrefernceOrdering);

            //after sorting
            //what if there are many elements of same type
            //to handle that - take type of first element and traverse further till we have same type of element
            //hence return all elements of same type with highest preference
            if (PageObjectWithPrefs.size() > 1) {
                String highPrefObjectType = PageObjectWithPrefs.get(0).pageObject.ObjectType.toLowerCase();
                for (PageObjectEx objPOEx : PageObjectWithPrefs) {
                    if (highPrefObjectType.equalsIgnoreCase(objPOEx.pageObject.ObjectType.toLowerCase())) {
                        possibleActionableControls.add(objPOEx.pageObject);
                    }
                }
            } else if (PageObjectWithPrefs.size() == 1) {
                possibleActionableControls.add(PageObjectWithPrefs.get(0).pageObject);
            }

            if (possibleActionableControls.size() > 0) {
                return possibleActionableControls;
            }

            //dont send back empty set of controls.
            if (possibleActionableControls.size() <= 0) {
                return setPageObjects;
            } else {
                return possibleActionableControls;
            }
        } catch (Exception e) {
            //return whatever we have
            if (possibleActionableControls.size() <= 0) {
                return setPageObjects;
            } else {
                return possibleActionableControls;
            }
        } finally {
            SendDisplayLogToClient(Integer.toString(possibleActionableControls.size()));

        }
    }

    public HashSet<String> readverbStore() {

        BufferedReader reader = null;
        HashSet<String> setVerbs = new HashSet<String>();

        try {
           //InputStream in= new ClassPathResource(Constants.wordNetPath).getInputStream();
           // reader = new BufferedReader( new FileReader(Constants.verbPath));
            //reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            reader = new BufferedReader(new InputStreamReader(new ClassPathResource(Constants.verbPath).getInputStream()));
            String line = "";
            while ((line = reader.readLine()) != null) {
                if (line.length() >= 1) {
                    setVerbs.add(line);
                } else {
                    SendDisplayLogToClient("Ignoring Verb lines " + line);
                }
            }
            reader.close();
            return setVerbs;

        } catch (Exception ex) {

            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());
        } finally {
            try {
                reader.close();

            } catch (IOException ex) {
                System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());

            }
        }
        return setVerbs;
    }

    public HashSet<String> readTechVerbStore() {

        BufferedReader reader = null;
        HashSet<String> setVerbs = new HashSet<String>();

        try {
            //reader = new BufferedReader(new FileReader(Constants.TechVerbPath));
            reader = new BufferedReader(new InputStreamReader(new ClassPathResource(Constants.TechVerbPath).getInputStream()));
            String line = "";
            while ((line = reader.readLine()) != null) {
                if (line.length() >= 1) {
                    setVerbs.add(line);
                } else {
                    SendDisplayLogToClient("Ignoring Tech Verb line -" + line);
                }
            }
            reader.close();
            return setVerbs;

        } catch (Exception ex) {
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());

        } finally {
            try {
                reader.close();

            } catch (IOException ex) {
                System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());
            }
        }
        return setVerbs;
    }

    void SendDisplayLogToClient(String strDisplay) {

        try {
            //System.out.println(strDisplay);
//            serverlogSender.strToDisplay = strDisplay;
            //serverlogSender.inQueueExecutionLog.add(strDisplay);

        } catch (Exception ex) {    
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName()+ ex.getMessage());
        }
    }

    private String GetElementID(WebElement parentElement) {
        String strObjectID = "";
        try {

            if (!(parentElement.getAttribute("id").isEmpty())) {

                //no need to check if its displayed or clickable or else since its already checked during scanning
                return parentElement.getAttribute("id");

            } else if ((!parentElement.getText().isEmpty())) {
                //link ID is empty

                //control ID is Empty but link-text is not empty
                //so inorder to search based on By.linktext() we need to store those controls
                strObjectID = "sphrefid" + "_$_";

                try {
                    strObjectID += parentElement.getAttribute("href") + "_$_";
                } catch (Exception ex) {
                    strObjectID += "null_$_";
                }

                try {
                    strObjectID += parentElement.getAttribute("class") + "_$_";
                } catch (Exception ex) {
                    strObjectID += "null_$_";
                }
                try {
                    strObjectID += parentElement.getAttribute("rel") + "_$_";
                } catch (Exception ex) {
                    strObjectID += "null_$_";
                }

                try {
                    strObjectID += parentElement.getText() + "_$_";
                } catch (Exception ex) {
                    strObjectID += "null_$_";
                }
                // ARP Added UUID to avoid Duplicate object Ids
                try {
                    String uuid = UUID.randomUUID().toString().replace("-", "");
                    strObjectID += uuid + "_$_";
                } catch (Exception ex) {
                    strObjectID += "uuidFail_$_";
                }

            }
            return strObjectID;
        } catch (Exception ex) {
            return strObjectID;
        }
    }

    private String GetActualElementID(String parentElementID) {
        try {

            if (parentElementID.contains("_$_")) {
                //custom ID
                return StringUtils.substringBeforeLast(parentElementID, "_$_");
            } else {
                //actual ID
                //return as it is
                return parentElementID;
            }

        } catch (Exception ex) {
            return parentElementID;
        }

    }

    private class PageObjectEx {

        PageObject pageObject;
        int objectPreference;

        public PageObjectEx(PageObject _PObject, int _objectPref) {
            pageObject = _PObject;
            objectPreference = _objectPref;
        }

    }

    public boolean findValueInAttribiutes(WebDriver driver, WebElement element,String possibleIdentifier, Boolean isContains) {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        @SuppressWarnings("unchecked")
        Map<String, String> attributes = (Map<String, String>) js.executeScript(
                "var items = {}; " +
                        "for (index = 0; index < arguments[0].attributes.length; ++index) { " +
                        "   items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; " +
                        "return items;", element);

        if(isContains){
            for (Map.Entry<String, String> entry : attributes.entrySet()) {
                if (entry.getValue().replaceAll("[^a-zA-Z0-9]", "").toLowerCase().trim().replaceAll("\\s+", "").
                        contains(possibleIdentifier.toLowerCase().trim().replaceAll("\\s+", ""))) {
                    return true;
                }

            }
        }
        for (Map.Entry<String, String> entry : attributes.entrySet()) {
            if (entry.getValue().replaceAll("[^a-zA-Z0-9]", "").toLowerCase().trim().
                    equalsIgnoreCase(possibleIdentifier.toLowerCase().trim())) {
                return true;
            }

        }

        return false;
    }

}
