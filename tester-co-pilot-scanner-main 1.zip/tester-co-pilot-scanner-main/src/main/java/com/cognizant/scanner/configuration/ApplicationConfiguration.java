package com.cognizant.scanner.configuration;

import com.cognizant.scanner.selenium.*;
import org.openqa.selenium.*;
import org.springframework.context.annotation.*;

import java.util.*;

@Configuration
public class ApplicationConfiguration {

    @Bean
    public Map<String, WebDriver> temporaryDriverMap(){
        return new HashMap<String, WebDriver>();
    }

    @Bean
    public Map<String, Object> temporaryResponseMap() { return new HashMap<String, Object>();}

    @Bean
    public Map<String, Integer> domElementsCountMap() { return new HashMap<String, Integer>();}

    @Bean
    public Map<String, Map<String, PageObject>> relevantElementMap() { return new HashMap<String, Map<String, PageObject>>();}

}
