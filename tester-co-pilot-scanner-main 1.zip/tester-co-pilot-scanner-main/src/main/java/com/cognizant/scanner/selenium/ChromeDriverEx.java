package com.cognizant.scanner.selenium;

import com.google.common.collect.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.remote.*;

import java.lang.reflect.*;
import java.util.*;
import org.openqa.selenium.remote.http.HttpMethod;

public class ChromeDriverEx extends ChromeDriver {

    /**
     * Constructor without option
     * @throws Exception
     */
    public ChromeDriverEx() throws Exception {
        this(new ChromeOptions());
    }

    /**
     * Constructor with option
     * @throws Exception
     */
    public ChromeDriverEx(ChromeOptions options) throws Exception {
        this(ChromeDriverService.createDefaultService(), options);
    }

    /**
     * Constructor with service and option
     * @throws Exception
     */
    public ChromeDriverEx(ChromeDriverService service, ChromeOptions options) throws Exception {
        super(service, options);
        CommandInfo cmd = new CommandInfo("/session/:sessionId/chromium/send_command_and_get_result", HttpMethod.POST);
        Method defineCommand = HttpCommandExecutor.class.getDeclaredMethod("defineCommand", String.class, CommandInfo.class);
        defineCommand.setAccessible(true);
        defineCommand.invoke(super.getCommandExecutor(), "sendCommand", cmd);
    }

    /**
     * Method for capturing screen shot
     * @param <X>
     * @param outputType
     * @return
     * @throws Exception
     */
    // "width: Math.max(document.body.getBoundingClientRect().width),"
    @SuppressWarnings("unchecked")
    public <X> X getFullScreenshotChromeDriverAs(OutputType<X> outputType) throws Exception {
        Object metrics = sendEvaluate(
                "({" +
                        "width: Math.max(window.innerWidth,document.body.scrollWidth,document.documentElement.scrollWidth)|0," +
                        "height: Math.max(window.innerHeight,document.body.scrollHeight,document.documentElement.scrollHeight)|0," +
                        "deviceScaleFactor: window.devicePixelRatio || 1," +
                        "mobile: true" +
                        "})");
        Object userAgent = sendEvaluate(
                "({" + "userAgent: navigator.userAgent" + "})");
        sendCommand("Emulation.setDeviceMetricsOverride", metrics);
        sendCommand("Network.setUserAgentOverride", userAgent);
        //sendCommand("Emulation.canEmulate", true);
        Object result = sendCommand("Page.captureScreenshot", ImmutableMap.of("format", "png", "fromSurface", true));
        //sendCommand("Emulation.clearDeviceMetricsOverride", ImmutableMap.of());
        String base64EncodedPng = (String)((Map<String, ?>)result).get("data");
        return outputType.convertFromBase64Png(base64EncodedPng);
    }

    /**
     * Method to send command to chrome driver
     * @param cmd
     * @param params
     * @return
     */
    protected Object sendCommand(String cmd, Object params) {
        return execute("sendCommand", ImmutableMap.of("cmd", cmd, "params", params)).getValue();
    }

    /**
     * method to evaluate the parameter
     * @param script
     * @return
     */
    @SuppressWarnings("unchecked")
    protected Object sendEvaluate(String script) {
        Object response = sendCommand("Runtime.evaluate", ImmutableMap.of("returnByValue", true, "expression", script));
        Object result = ((Map<String, ?>)response).get("result");
        return ((Map<String, ?>)result).get("value");
    }
}

