package com.cognizant.scanner.selenium;

import lombok.*;
import org.openqa.selenium.WebElement;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageObject {

    private int objectMatchLevel;
    public String ObjectId;
    public String ObjectType;
    public String VisisbleText;

    public WebElement objectElement;// to be reviewed for its need
    public boolean bIsIFrameControl;
    public String iFrameId;
    public String imageHref;
    public boolean RawPageObject; //if this object is created only by xpath searched webelement
    public String xPath;
    public boolean bIsChildWindowControl;
    public String childWindowTitle;

    public PageObject(int _objectMatchLevel, String _ObjectId, String _ObjectType, String _VisisbleText,
            WebElement _objectElement, boolean _bIsIFrameControl, String _iFrameId, String _imageHref) {

        objectMatchLevel = _objectMatchLevel;
        ObjectId = _ObjectId;
        ObjectType = _ObjectType;
        VisisbleText = _VisisbleText;
        objectElement = _objectElement;
        bIsIFrameControl = _bIsIFrameControl;
        iFrameId = _iFrameId;
        imageHref = _imageHref;
        RawPageObject = false;
        xPath = "";
    }

    public PageObject(int _objectMatchLevel, String _ObjectId, String _ObjectType, String _VisisbleText,
                      WebElement _objectElement, boolean _bIsIFrameControl, String _iFrameId, String _imageHref,
                      boolean _bIsChildWindowControl, String _childWindowTitle) {

        objectMatchLevel = _objectMatchLevel;
        ObjectId = _ObjectId;
        ObjectType = _ObjectType;
        VisisbleText = _VisisbleText;
        objectElement = _objectElement;
        bIsIFrameControl = _bIsIFrameControl;
        iFrameId = _iFrameId;
        imageHref = _imageHref;
        RawPageObject = false;
        xPath = "";
        bIsChildWindowControl = _bIsChildWindowControl;
        childWindowTitle = _childWindowTitle;
    }

    public PageObject(WebElement _objectElement, String _xPath) {
        if (_objectElement != null) {
            objectElement = _objectElement;
            xPath = _xPath;
            RawPageObject = true;

            //default
            objectMatchLevel = 0;
            ObjectId = _objectElement.getAttribute("id");
            //commenting this because it returns null when user gives span/li xpath instead of anchor xpath
            //ObjectType = _objectElement.getAttribute("type");
            ObjectType = "";
            VisisbleText = _objectElement.getText();
            bIsIFrameControl = false;
            iFrameId = "";
            imageHref = "";
            bIsChildWindowControl = false;
            childWindowTitle = "";
        }
        else{
            //set default as void
            objectElement = null;
            xPath = "";
            RawPageObject = false;

            //default
            objectMatchLevel = 0;
            ObjectId = "";
            ObjectType = "";
            VisisbleText = "";
            bIsIFrameControl = false;
            iFrameId = "";
            imageHref = "";
        }
    }
   
}
