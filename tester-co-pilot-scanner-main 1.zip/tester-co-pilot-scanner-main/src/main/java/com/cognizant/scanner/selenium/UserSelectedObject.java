package com.cognizant.scanner.selenium;

import lombok.*;

@Data
@NoArgsConstructor
public class UserSelectedObject {
 

        public String objectId;
        boolean bIsIFrame;
        String iFrameID;

        public UserSelectedObject(String _objectId, boolean _bIsIFrame, String _iFrameID) {
            objectId = _objectId;
            bIsIFrame = _bIsIFrame;
            iFrameID = _iFrameID;
        }
     
}
