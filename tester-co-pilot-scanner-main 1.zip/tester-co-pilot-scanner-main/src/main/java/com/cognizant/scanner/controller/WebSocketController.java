package com.cognizant.scanner.controller;

import com.cognizant.scanner.dto.*;
import com.cognizant.scanner.service.*;
import org.openqa.selenium.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.messaging.handler.annotation.*;
import org.springframework.messaging.simp.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
public class WebSocketController {

    @Autowired
    private Map<String, WebDriver> temporaryDriverMap;

    @Autowired
    private DriverExecution driverExecution;
    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @Autowired
    private Map<String, Object> temporaryResponseMap;
    @Autowired
    private SeleniumExecution seleniumExecution;

    /*@MessageMapping("/scan/request")
    @SendTo("/scannerResponse/response")
    public String sendMessage(RequestDTO request) {
        // Assuming you want to send the message to a topic

       if(request.getEvent().equals("execute_step")){
            ResponseDTO responseDTO = driverExecution.executeTestStep(request.getStep(), temporaryDriverMap);
            messagingTemplate.convertAndSend("/scannerResponse/response", responseDTO);
            return responseDTO;
        }

        return "Success";
    }*/
    @PostMapping("/scan")
    public ResponseDTO startScan(@RequestBody RequestDTO request){

        Thread thread = null;

        ResponseDTO response = new ResponseDTO();
        response.setResponse("Waiting for response");

        temporaryResponseMap.put(request.getStep().getJobID(), response);

        try {
            thread = new Thread(new Runnable() {

                @Override
                public void run() {
                    try {

                        if(request.getEvent().equals("execute_step")){
                            ResponseDTO responseDTO = seleniumExecution.executeStep(request.getStep());
                            temporaryResponseMap.put(request.getStep().getJobID(), responseDTO);
                        }

                    } catch (Exception e) {

                        e.printStackTrace();

                    }

                }
            });

            thread.start();

        } finally {


        }


        return response;
    }

    @GetMapping("/scan/{jobId}")
    public Object getScanResponse(@PathVariable String jobId){
        return temporaryResponseMap.get(jobId);
    }
}
