package com.cognizant.scanner.service;

import com.cognizant.scanner.common.*;
import com.cognizant.scanner.dto.*;
import com.cognizant.scanner.exception.*;
import com.cognizant.scanner.model.*;
import com.cognizant.scanner.model.Verify;
import com.cognizant.scanner.model.Wait;
import com.cognizant.scanner.selenium.*;
import com.google.common.base.*;
import io.github.bonigarcia.wdm.*;
import org.apache.commons.lang3.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.ui.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.testng.*;

import java.net.*;
import java.time.*;
import java.util.*;
import java.util.regex.*;

@Service
public class SeleniumExecution {

    @Autowired
    private Map<String, WebDriver> temporaryDriverMap;
    @Autowired
    private Map<String, Integer> domElementsCountMap;

    @Autowired
    private Map<String, Map<String, PageObject>> relevantElementMap;
    private XPATHDriverWrapper driverParser;
    private AOStar aoStar;

    private Map<String, PageObject> mapPageObjectsSearchByLinkText = new HashMap<String, PageObject>();

    private boolean bAnchorScan = true;
    private boolean bInputScan = true;
    private boolean bImageScan = true;
    private boolean bButtonScan = true;
    private boolean bSpanScan = true;
    private boolean bDivScan = true;
    private boolean bIconScan = true;
    private boolean bLabelScan = true;
    private boolean bRadioScan = true;
    private boolean bSelectScan = true;

    private Map<String, PageObject>  mapPageDivs = new HashMap<String, PageObject>();

    private Map<String,String>  mapPoIdToXpaths = new HashMap<String, String>();

    private long actionDelay = 2000;

    private Set<String> setDontscanfordataentry = new HashSet<String>();

    private List<String> listTestDataUsedTillNow = new ArrayList<String>();

    private String strTempPOObjectID;

    private String bCheckEditableControlWithTestData = "1";

    private Map<String, String> mapAlreadyExecutedObjectOnGivenPAge = new HashMap<String, String>();

    private boolean bOverridedisplaytext = false;

    private String clickedControlID = "";

    private WebDriverWait wait;

    private int uxStepMapCounter=1;

    private static boolean performWebAction = true;

    private int userSlectedSteps = 0;

    private int WaitCounter = 0;

    private WebDriver initDriver(String jobId){

        mapPageObjectsSearchByLinkText = new HashMap<String, PageObject>();

        aoStar = new AOStar();

        mapPageDivs = new HashMap<String, PageObject>();

        mapPoIdToXpaths = new HashMap<String, String>();

        String strDontscanfordataentry = "href,image,button,span,div,icon,label";

        setDontscanfordataentry.addAll(Arrays.asList(strDontscanfordataentry.split(",")));

        if(temporaryDriverMap.containsKey(jobId)){
            return temporaryDriverMap.get(jobId);
        } else{
            WebDriverManager.chromedriver().setup();

            ChromeOptions options = new ChromeOptions();
            /*options.addArguments("window-size=1920,1080");
            options.addArguments("--headless=new");*/

            // Accept insecure certificates
            options.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);

            // Use arguments to suppress all warnings and security errors
            options.addArguments("--ignore-certificate-errors");
            options.addArguments("--allow-insecure-localhost");
            options.addArguments("--disable-web-security");
            options.addArguments("--disable-client-side-phishing-detection");
            options.addArguments("--disable-notifications");

            // Use an incognito or temp profile to avoid cached HSTS
            options.addArguments("--incognito");

            // Optional: disable 'Chrome is being controlled' message
            options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
            options.setExperimentalOption("useAutomationExtension", false);

            // Initialize the ChromeDriver
            WebDriver driver = new ChromeDriver(options);

            driver.manage().window().maximize();

            temporaryDriverMap.put(jobId, driver);

            return driver;
        }

    }
   public ResponseDTO executeStep(Step step){

       WebDriver driver = initDriver(step.getJobID());

       String pageTitle = driver.getTitle();

        List<WebElement> allElements = driver.findElements(By.cssSelector("*"));

        Map<String, PageObject> relevantMap = new HashMap<String, PageObject>();



        if ((step.getAction().name().toLowerCase().contains("launch")
                || (step.getAction().name().toLowerCase().contains("open")))
        ) {

            ResponseDTO response = startAndFindTheLocator(step, driver, new HashMap<String, PageObject>());

            return response;
        }




        if ((step.getAction().name().toLowerCase().contains("goto")
                || (step.getAction().name().toLowerCase().contains("load"))
                || (step.getAction().name().toLowerCase().contains("navigate")))
        ) {
            ResponseDTO response = startAndFindTheLocator(step, driver, new HashMap<String, PageObject>());
            return response;
        }
		
		if (step.getAction().name().toLowerCase().contains("exit")){
			ResponseDTO response = startAndFindTheLocator(step, driver, new HashMap<String, PageObject>());
            return response;
		}

        if(domElementsCountMap.containsKey(step.getJobID())
                && allElements.size() == domElementsCountMap.get(step.getJobID())){

            relevantMap = relevantElementMap.get(step.getJobID());

        } else{

            relevantMap = FindRelvantControlOnPage(step, false, driver, true, false, false);

            relevantElementMap.put(step.getJobID(), relevantMap);

            domElementsCountMap.put(step.getJobID(), allElements.size());
        }

        Map<String, PageObject> windowObject = new HashMap<>(relevantMap);

        ResponseDTO response = startAndFindTheLocator(step, driver, windowObject);

        String newPageTitle = driver.getTitle();

        System.out.println("Main Window " + response.getResponse());

        if(pageTitle.equalsIgnoreCase(newPageTitle)){
            if(response != null && response.getResponse() != null &&  response.getResponse().equalsIgnoreCase(Constants.LOCATOR_NOT_FOUND)){
                windowObject = FindRelvantControlOnPage(step, false, driver, false, true, false);
                response = startAndFindTheLocator(step, driver, windowObject);
                System.out.println("Iframe Window "+response.getResponse());
                if(response != null && response.getResponse() != null && response.getResponse().equalsIgnoreCase(Constants.LOCATOR_NOT_FOUND)){
                    windowObject = FindRelvantControlOnPage(step, false, driver, false, false, true);
                    response = startAndFindTheLocator(step, driver, windowObject);
                    System.out.println("Child Window "+response.getResponse());
                }

            }
        }


        return response;

    }

    private Locator selectFromLookup(Step step, PageObject pageObject, WebDriver driver) {
        String fieldName = step.getFieldValue();
        String lookupValue = step.getTestData();
        Locator locator = new Locator();
        locator.setPageUrl(driver.getCurrentUrl());
        locator.setPageTitle(driver.getTitle());
        locator.setAction("SelectFromLookup");
        locator.setCreatedByFunction("selectFromLookup");
        //locator.setUserText(fieldName);
        locator.setData(lookupValue);
        String xpath = pageObject.xPath;
        String showAll_xpath = "";
        try{
            locator.setType(Types.LocatorType.xpath.name());
            locator.setValue(xpath);

            selectFromLookUpDBCall(driver.findElement(By.xpath(xpath)), 1, locator, driver);
            locator.setiRetVal(1);
            return locator;
        } catch(Exception ex) {
            ex.printStackTrace();
            locator.setiRetVal(-1);
            return locator;
        }
    }

    private void selectFromLookUpDBCall(WebElement webElement, int counter, Locator locator, WebDriver driver){
        String scrollElementIntoMiddle = "var viewPortHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);"
                + "var elementTop = arguments[0].getBoundingClientRect().top;"
                + "window.scrollBy(0, elementTop-(viewPortHeight/2));";

        ((JavascriptExecutor) driver).executeScript(scrollElementIntoMiddle, webElement);

        try{
            if(counter > 1){
                webElement.sendKeys(Keys.BACK_SPACE);
            }
            webElement.sendKeys(locator.getData());

        } catch (Exception e){
            try{
                webElement.sendKeys(Keys.BACK_SPACE);
                Thread.sleep(1000L);

                Actions leftClickAction = new Actions(driver);
                leftClickAction.click(webElement).build().perform();
                Thread.sleep(1000L);

                webElement.sendKeys(locator.getData());
                Thread.sleep(1000L);
            } catch (Exception ex){
                if(counter > 3){
                    throw new RuntimeException(e.getMessage());
                } else{
                    selectFromLookUpDBCall(webElement, counter + 1, locator, driver);
                }
            }
        }
    }
    private Locator switchToIframe(Step step, WebDriver driver){
        String iFrameData = step.getTestData();
        Locator locator = new Locator();
        locator.setAction("switchToIframe");
        locator.setCreatedByFunction("switchToIframe");
        locator.setPageUrl(driver.getCurrentUrl());
        locator.setPageTitle(driver.getTitle());
        locator.setData(iFrameData);
        try{
            if(iFrameData.equalsIgnoreCase("default")){
                driver.switchTo().defaultContent();
                locator.setValue("default");
                locator.setType("xpath");
            }else if(iFrameData.equalsIgnoreCase("parent")){
                driver.switchTo().parentFrame();
                locator.setValue("parent");
                locator.setType("xpath");
            }
            else{
                List<By> locators = new ArrayList<>();
                locators.add(By.id(iFrameData));
                locators.add(By.name(iFrameData));
                locators.add(By.linkText(iFrameData));
                locators.add(By.partialLinkText(iFrameData));
                if (!iFrameData.contains(" ")) {
                    locators.add(By.className(iFrameData));
                }
                locators.add(By.cssSelector(iFrameData));
                locators.add(By.xpath("//*[text()='" + iFrameData + "']"));
                for (By loc : locators) {
                    List<WebElement> elements;
                    try {
                        elements = driver.findElements(loc);
                    } catch (Exception e) {
                        continue;
                    }
                    if (!elements.isEmpty()) {
                        WebElement iframeElement = elements.get(0);
                        System.out.println("iframe found using: " + loc);
                        try {
                            driver.switchTo().frame(iframeElement);
                            System.out.println("Switched to iframe successfully");
                            locator.setValue(loc.toString());
                            locator.setType(loc.getClass().getSimpleName());
                            break;
                        } catch (Exception e) {
                            System.out.println("Not able to switch to iframe: " + e.getMessage());
                        }
                    }
                }
            }
             return locator;
        }
        catch(Exception ex) {
            ex.printStackTrace();
            locator.setiRetVal(-1);
            return locator;
        }
    }

    private String getCurrentPageURL(WebDriver driver){
        return driver.getCurrentUrl();
    }

    private String getCurrentPageTitle(WebDriver driver){
        return driver.getTitle();
    }

    private String getWindowHandle(WebDriver driver) {
        return driver.getWindowHandle();
    }

    private Set<String> getWindowHandles(WebDriver driver) {
        return driver.getWindowHandles();
    }

    private Map<String, PageObject> FindRelvantControlOnPage(Step step, boolean bFindDivs, WebDriver driver,
                                                             boolean isMainWindow, boolean isIframeWindow,
                                                             boolean isChildWindow) {
        Map<String, PageObject> mapPageObjects = new HashMap<String, PageObject>();
        String mainWindow = "";
        String windowTitle;
        String iFrameID = "";
        try {
            Thread.sleep(3000);

            //main window/default dom - false, false
            //iterate iframes if any - false, true

            //check for any child window
            //iterate child windows
            //child window default dom - true, false
            //iterate child window iframes if any - true, true

            mainWindow = driver.getWindowHandle();
            //switch to default content
            //driver.switchTo().defaultContent(); //commented by 844640
            /**Main window(default dom)
             * windowControl - false
             * iFrameControl - false*/
            if(isMainWindow){
                mapPageObjects = FindRelvantControlOnPageEx(step, bFindDivs, false,
                        mapPageObjects, false, "", false, "", driver);
            }


            /**Main window & it's iFrame DOM
             * windowControl - false
             * iFrameControl - true*/
            if(isIframeWindow){
                mapPageObjects.putAll(getIFrameObjects(step, bFindDivs, mapPageObjects,
                        true, false, "", driver));
            }

            if(isChildWindow){
                int winSize = driver.getWindowHandles().size();
                /**Check for any child window*/
                if(driver.getWindowHandles().size() > 1) {
                    for(String window: driver.getWindowHandles()) {
                        if(!mainWindow.equalsIgnoreCase(window)) {
                            //driver.switchTo().window(window);//commented by 844640
                            windowTitle = driver.getTitle().trim();//for now, title is used as a child window reference id
                            /**Child window(default dom)
                             * windowControl - true
                             * iFrameControl - false*/
                            mapPageObjects.putAll(FindRelvantControlOnPageEx(step, bFindDivs, false,
                                    mapPageObjects, false, iFrameID, true, windowTitle, driver));

                            /**Child window & it's iFrame DOM
                             * windowControl - true
                             * iFrameControl - true*/
                            mapPageObjects.putAll(getIFrameObjects(step, bFindDivs, mapPageObjects,
                                    true, true, windowTitle, driver));

                            //switch back to main window
                            //driver.switchTo().window(mainWindow);//commented by 844640
                        }
                    }
                }
            }

            System.out.println("Total controls identified in the page: " + mapPageObjects.size());
            System.out.println("Total controls identified in the page: " + mapPageObjects.size());
            return mapPageObjects;
        } catch (Exception e) {
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName() + e.getMessage());
            //driver.switchTo().defaultContent();//commented by 844640
            if(!StringUtils.isEmpty(mainWindow)) {
                //driver.switchTo().window(mainWindow);//commented by 844640
            }
            return mapPageObjects;
        }
    }

    private Map<String, PageObject> FindRelvantControlOnPageEx(Step step,
                                                               boolean bFindDivs, boolean bAppend,
                                                               Map<String, PageObject> PageObjects,
                                                               boolean bIsIframeControl, String iFrameID,
                                                               boolean bIsWindowControl, String windowTitle,
                                                               WebDriver driver) {
        /*

         These are the widely used search options.

         By.ClassName
         By.CssSelector
         By.Id
         By.LinkText
         By.Name
         By.PartialLinkText
         By.TagName
         By.XPath

         */
        long startTime = System.nanoTime();
        Map<String, PageObject> mapPageObjects = new HashMap<String, PageObject>();
        try {

            if (bAppend) {
                //means iframes are there- so we need to update this and not re-initiates it
                if (driverParser != null) {
                    driverParser.updateElementsAndXpaths(driver);
                } else {
//                    this situation will never occur but still not addressing NULL case
                    driverParser = new XPATHDriverWrapper();

                    driverParser.intParser(driver);
                }
            } else {
                //(re-)initiates driver parser.
                driverParser = new XPATHDriverWrapper();
                driverParser.intParser(driver);
            }

            if (bAppend) {
                mapPageObjects = PageObjects;
            }

            mapPageObjectsSearchByLinkText.clear();

            System.out.println("Scanning page-objects..");
            //different locator types are ID, Classes, Xpaths, Link texts, CSS Selectors etc

            //first getPageElements all links on page
            Map<String, PageObject> mapPageElements = null;

            List<ISeleniumScanner> Iscanners = new ArrayList<ISeleniumScanner>();
            //SeleniumPageScanner pageScannerParent = new SeleniumPageScanner(serverlogSender, driver);
            SeleniumPageScanner pageScannerParent = new SeleniumPageScanner();
            if (bAnchorScan) {
                Iscanners.add(pageScannerParent::getAllAnchorElements);
            }
            if (bInputScan) {
                Iscanners.add(pageScannerParent::getAllInputElements);
            }
            if (bImageScan) {
                Iscanners.add(pageScannerParent::getAllImageElements);
            }
            if (bButtonScan) {
                Iscanners.add(pageScannerParent::getAllButtonElements);
            }
            if (bSpanScan) {
                Iscanners.add(pageScannerParent::getAllSpanElements);
            }
            if (bDivScan) {
                Iscanners.add(pageScannerParent::getAllDivElements);
            }
            if (bIconScan) {
                Iscanners.add(pageScannerParent::getAllIconElements);
            }
            if (bLabelScan) {
                Iscanners.add(pageScannerParent::getAllLabelElements);
            }
            if (bRadioScan) {
                Iscanners.add(pageScannerParent::getAllRadiosElements);
            }
            if (bSelectScan) {
                Iscanners.add(pageScannerParent::getAllSelectElements);
            }

//            IGetTextReference = pageScannerParent::getVisisbleTextOfWebElement(WebElement e);
            for (int iScanCount = 0; iScanCount < Iscanners.size(); iScanCount++) {

                mapPageElements = Iscanners.get(iScanCount).getPageElements(bIsIframeControl, iFrameID,
                        bIsWindowControl, windowTitle, driver);
                mapPageObjects.putAll(mapPageElements);
                mapPageElements.clear();
            }
            mapPageDivs.putAll(pageScannerParent.getPageDivs());
            mapPageObjectsSearchByLinkText.putAll(pageScannerParent.getSearchedTextLinks());



            System.out.println("FindRelvantControlOnPageEx Execution Complete: " + mapPageObjects.size());

            System.out.println("Inserting Xpaths of scanned objects ..... ");
            //keeping this seperate than scanner.
            /*for (Map.Entry<String, PageObject> entryPO : mapPageObjects.entrySet()) {
                PageObject PObjectDetails = entryPO.getValue();
                WebElement po = PObjectDetails.objectElement;
                String Xpath = driverParser.findXPATHIDFromWebElement(po);
                mapPoIdToXpaths.put(PObjectDetails.ObjectId, Xpath);
            }*/
            System.out.println("Inserting Xpaths of scanned objects Complete = " + mapPoIdToXpaths.size());

            return mapPageObjects;

        } catch (Exception e) {
            System.out.println("Error in page scanning.....");
            e.printStackTrace();
            return new HashMap<String, PageObject>();
        } finally {

            long endTime = System.nanoTime();
            long duration = (endTime - startTime);
            System.out.println("Time required for page scanning(seconds) : " + duration / 1000000 / 1000);
            System.out.println("Actionable webelements found : " + mapPageObjects.size() + " (Divs = " + mapPageDivs.size() + " )");

        }
    }

    private Map<String, PageObject> getIFrameObjects(Step step, boolean bFindDivs,
                                                     Map<String, PageObject> mapPageObjects,
                                                     boolean bIsIframeControl, boolean bIsWindowControl,
                                                     String windowTitle, WebDriver driver) {
        String iFrameID = "";
        try {
            List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
            int iframeSize = iframes.size();
            for (WebElement frame : iframes) {
                if(frame.isDisplayed()) {
                    /**check if iframe has an ID or name*/
                    if(!StringUtils.isEmpty(frame.getAttribute("id"))) {
                        iFrameID = frame.getAttribute("id");
                    } else if(!StringUtils.isEmpty(frame.getAttribute("name"))){
                        iFrameID = frame.getAttribute("name");
                    }
                    //driver.switchTo().frame(frame);
                    /**Main window & iFrame DOM
                     * windowControl - false
                     * iFrameControl - true*/
                    mapPageObjects.putAll(FindRelvantControlOnPageEx(step, bFindDivs, false,
                            mapPageObjects, bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver));
                    //switch back to default content
                    //driver.switchTo().defaultContent();
                }
            }
            return mapPageObjects;
        } catch(Exception ex) {
            ex.printStackTrace();
            //driver.switchTo().defaultContent();
            return mapPageObjects;
        }
    }

    private static PageObject getPageObjectFromIframe(WebDriver driver, String userXpath) {
        PageObject pageObject = null;
        WebElement objWebElement;
        String iFrameID = "";
        try {
            List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
            System.out.println("Searching in iframes: " + iframes.size());
            for (WebElement frame : iframes) {
                if(frame.isDisplayed()) {
                    /**check if iframe has an ID or name*/
                    if(!StringUtils.isEmpty(frame.getAttribute("id"))) {
                        iFrameID = frame.getAttribute("id");
                        //System.out.println(iFrameID);
                        if (iFrameID.equalsIgnoreCase("gsft_main")){

                        }
                        else{
                            //driver.switchTo().frame(frame);
                        }
                    } else if(!StringUtils.isEmpty(frame.getAttribute("name"))){
                        iFrameID = frame.getAttribute("name");
                    }
//                    driver.switchTo().frame(frame);
                    try {
                        objWebElement = driver.findElement(By.xpath(userXpath));
                        pageObject = new PageObject(objWebElement, userXpath);
                        pageObject.bIsIFrameControl = true;
                        pageObject.iFrameId = iFrameID;
                        //driver.switchTo().defaultContent();
                        break;
                    } catch(Exception ex) {
                        //do nothing, switch to default content and continue checking with next iframe
                        //driver.switchTo().defaultContent();
                    }
                }
            }
        } catch(Exception ex) {
            return null;
        }
        return pageObject;
    }

    private void switchToWindow(String window, WebDriver driver) {
        driver.switchTo().window(window);
    }

    private PageObject getWebElementFromXpath(WebDriver driver,
                                                    String userXpath, String mainWindowId) {
        WebElement objWebElement = null;
        PageObject pageObject = null;
        String currentDriverWindowId;
        String windowTitle;
        System.out.println(driver.getWindowHandles());
        try {

            currentDriverWindowId = driver.getWindowHandle();
            if(currentDriverWindowId.equalsIgnoreCase(mainWindowId)) {
                //if mainwindow(windowLocator - false)
                System.out.println("Searching in main window");
                try {
                    //check if webelement is identified
                    objWebElement = driver.findElement(By.xpath(userXpath));
                    //if true(iframe - false)
                    pageObject = new PageObject(objWebElement, userXpath);
                    return pageObject;
                } catch(Exception ex) {
                    //else if false(iframe - true)
                    pageObject = getPageObjectFromIframe(driver, userXpath);
                    if (pageObject == null) {
                        //iterate other windows if any(windowLocator - true)
                        System.out.println("Searching in child windows");
                        for (String window : driver.getWindowHandles()) {
                            if (!mainWindowId.equalsIgnoreCase(window)) {
                                switchToWindow(window, driver);
                                windowTitle = driver.getTitle();
                                try {
                                    //check if webelement is identified
                                    objWebElement = driver
                                            .findElement(By.xpath(userXpath));
                                    //if true(iframe - false)
                                    pageObject = new PageObject(objWebElement, userXpath);
                                    pageObject.bIsChildWindowControl = true;
                                    pageObject.childWindowTitle = windowTitle;
                                    //driver.switchTo().window(mainWindowId);
                                    switchToWindow(window, driver);
                                    break;
                                } catch (Exception ex2) {
                                    //else if false(iframe - true)
                                    pageObject = getPageObjectFromIframe(driver,
                                            userXpath);
                                    if (pageObject != null) {
                                        //pageObject found, break the window handle iteration
                                        pageObject.bIsChildWindowControl = true;
                                        pageObject.childWindowTitle = windowTitle;
                                        break;
                                    }
                                    switchToWindow(mainWindowId, driver);
                                    // else, iterate to next window
                                }
                            }
                        }
                    }
                    return pageObject;
                }
            } else {
                //else if childwindow(windowLocator - true)
                System.out.println("Searching in child window");
                windowTitle = driver.getTitle();
                try {
                    //check if webelement is identified
                    objWebElement = driver.findElement(By.xpath(userXpath));
                    //if true(iframe - false)
                    pageObject = new PageObject(objWebElement, userXpath);
                    pageObject.bIsChildWindowControl = true;
                    pageObject.childWindowTitle = windowTitle;
                    return pageObject;
                } catch(Exception ex) {
                    //else if false(iframe - true)
                    pageObject = getPageObjectFromIframe(driver, userXpath);
                    //check if webelement is identified
                    if (pageObject == null) {
                        //iterate other windows
                        System.out.println("Searching in other windows");
                        for (String window : driver.getWindowHandles()) {
                            //check if it is not same child window
                            if (!currentDriverWindowId.equalsIgnoreCase(window)) {
                                switchToWindow(window, driver);
                                windowTitle = driver.getTitle();
                                try {
                                    //check if webelement is identified
                                    objWebElement = driver
                                            .findElement(By.xpath(userXpath));
                                    //if true(iframe - false)
                                    pageObject = new PageObject(objWebElement, userXpath);
                                    //check if it is main window or any other child window
                                    if (!mainWindowId.equalsIgnoreCase(window)) {
                                        pageObject.bIsChildWindowControl = true;
                                        pageObject.childWindowTitle = windowTitle;
                                    }
                                    break;
                                } catch (Exception ex2) {
                                    //else if false(iframe - true)
                                    pageObject = getPageObjectFromIframe(driver, userXpath);
                                    if (pageObject != null) {
                                        //pageObject found, break the window handle iteration
                                        //check if it is main window or any other child window
                                        if (!mainWindowId.equalsIgnoreCase(window)) {
                                            pageObject.bIsChildWindowControl = true;
                                            pageObject.childWindowTitle = windowTitle;
                                        }
                                        break;
                                    }
                                    switchToWindow(mainWindowId, driver);
                                    // else, iterate to next window
                                }
                            }
                        }
                    } else {
                        pageObject.bIsChildWindowControl = true;
                        pageObject.childWindowTitle = windowTitle;
                    }
                    return pageObject;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return pageObject;
    }

    Locator ExecuteWithKeyboardPressKey(Step step, PageObject pageObject, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("ExecuteWithKeyboardPressKey");
        String keyboardKey = step.getTestData();
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction + "(bIsIFrameControl = " + bIsIFrameControl + " and frameID = " + iFrameId);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("presskey");
        locator.setCreatedByFunction("ExecuteWithKeyboardPressKey");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);
        try {

            clickAction = clickAction.replace("\\", "");

            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] elementAtrrs = pattern.split(clickAction);
            String elementType = "";
            String elementClass = "";
            String elementName = "";
            String elementDisplayText = "";
            String elementOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                elementType = elementAtrrs[1];
                elementClass = elementAtrrs[2];
                elementName = elementAtrrs[3];
                elementDisplayText = elementAtrrs[4];
                elementOnClick = elementAtrrs[5];
            } catch (Exception ex) {

            }

            if (elementClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                elementClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }

            //try to find by 'name'
            List<WebElement> objElements = new ArrayList<WebElement>();
            try {
                objElements = driver.findElements(By.name(elementName));
                locator.setType(Types.LocatorType.name.name());
                locator.setValue(elementName);
            } catch (Exception ex) {
            }
            try {
                if (objElements.isEmpty()) {

                    if (bUseCSSSelector) {
                        //by CSSselector
                        objElements = driver.findElements(By.cssSelector(elementClass));
                        locator.setType(Types.LocatorType.cssSelector.name());
                        locator.setValue(elementClass);
                    } else {
                        //by class name
                        objElements = driver.findElements(By.className(elementClass));
                        locator.setType(Types.LocatorType.className.name());
                        locator.setValue(elementClass);
                    }
                }
            } catch (Exception ex) {
                //to debug - remove later
                //ex.printStackTrace();
            }
            try {
                if (objElements.isEmpty()) {
                    String xpath = "//input";
                    objElements = driver.findElements(By.xpath(xpath));
                    if (!objElements.isEmpty()) {
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue(xpath);
                    }
                }

            } catch (Exception ex) {
            }

            if (objElements.isEmpty()) {
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }

            if (objElements.size() == 1) {
                objElement = objElements.get(0);
            } else if (objElements.size() > 1) {
                objElement = objElements.get(0); //temp code
                //
                for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                    //ask use which one to select
                    //t odo
                }
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            Actions act = new Actions(driver);
            String key=keyboardKey.toUpperCase();
            if(performWebAction){
                if (objElement.isEnabled()) {

                    //objElement.click();
                    String strElementype = objElement.getAttribute("type");
                    if (strElementype != null) {
                        try {

                            if(key.equalsIgnoreCase("BACKSPACE"))
                                key="BACK_SPACE";
                            else if(key.equalsIgnoreCase("PAGEUP"))
                                key="PAGE_UP";
                            else if(key.equalsIgnoreCase("PAGEDOWN"))
                                key="PAGE_DOWN";
                            else if(key.equalsIgnoreCase("ENTER"))
                                key="ENTER";
                            else if(key.equalsIgnoreCase("ESC"))
                                key="ESCAPE";

                            objElement.sendKeys(Keys.valueOf(key));
                            locator.setData(key);
                        } catch (Exception ex) {
                            //this is shame
                            By elementLocation = By.id(clickAction);

                            if (bIsIFrameControl) {
                                //driver.switchTo().defaultContent();
                                //driver.switchTo().frame(iFrameId);
                            }
                            objElement = driver.findElement(elementLocation);
                            objElement.sendKeys(Keys.valueOf(key));
                            locator.setData(key);
                        }

                    } else {

                        //Add a logic to handle the user xpath flow
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                    }

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                        //return 2;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                            //return 3;
                        } else {
                            locator.setiRetVal(1);
                            return locator;
                            //return 1;
                        }
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }
            locator.setiRetVal(0);
            return locator;
            //return 0;

        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        }catch (Exception e) {
            locator.setiRetVal(-1);
            return locator;
            //return -1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }

    }

    private int ExecuteClickAlertBox(String TestData, WebDriver driver) {
        try
        {
            if(TestData.equalsIgnoreCase("Ok"))
            {
                driver.switchTo().alert().accept();
            }
            else  if(TestData.equalsIgnoreCase("Cancel"))
            {
                driver.switchTo().alert().dismiss();
            }
            else
            {
                driver.switchTo().alert().getText();
            }

            return 1;
        }catch(Exception e)
        {
            return 0;
        }
        //To change body of generated methods, choose Tools | Templates.
    }

    private String FindAllAttributes(PageObject objPage, WebDriver driver) {
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName());

        if (objPage == null) {
            return "";
        }

        try {

            WebElement element = objPage.objectElement; // Your element
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            Object aa = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", element);
            String strArrList = aa.toString();
            //System.out.println(strArrList);
            strArrList = strArrList.replaceAll("\\{", "");
            strArrList = strArrList.replaceAll("\\}", "");
            return strArrList;
        } catch (Exception e) {
            System.out.println("Unable to extract ALL Attributes of an Element");
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
            return "";
        }

    }

    private String FindAllAttributes(WebElement element, WebDriver driver) {
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName());

        try {
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            Object aa = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", element);
            String strArrList = aa.toString();
            System.out.println(strArrList);
            strArrList = strArrList.replaceAll("\\{", "");
            strArrList = strArrList.replaceAll("\\}", "");
            return strArrList;
        } catch (Exception e) {
            System.out.println("Unable to extract ALL Attributes of an Element");
            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
            return "";
        }

    }

    private int ExecuteVerifyCheckWithoutPageObjects(String action,String data,boolean pageChangedFlag,boolean popupLaunchedFlag, WebDriver driver) {
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + action );

        WebElement objElement = null;

        try {

            Set isEqualVerbs = new HashSet<String>(Arrays.asList("equals", "equal"));
            Set isPopupChangedVerbs = new HashSet<String>(Arrays.asList("popupLaunched"));
            Set isPageChangedVerbs = new HashSet<String>(Arrays.asList("pageChanged"));

            String[] tokens = action.split(" ");
            if ((action.equalsIgnoreCase("tooltip") || action.equalsIgnoreCase("tool-tip"))) {

                int i=driver.findElement(By.tagName("body")).getText().indexOf("Verify Page");
                if(i!=-1)
                {
                    System.out.println("verification complete.");
                }
                if (driver.findElement(By.xpath("//*[@title='World Health Organization']")) != null) {
                    System.out.println("verification complete.");
                    return 1;
                }

            } else {
                for (int iCnt = 0; iCnt < tokens.length; iCnt++) {

                    if ((action.equalsIgnoreCase("popup") && data.equalsIgnoreCase("launched") && popupLaunchedFlag == true)) {
                        System.out.println("verification complete.");
                        return 1;
                    } else if ((action.equalsIgnoreCase("page") && data.equalsIgnoreCase("changed")) && pageChangedFlag == true) {
                        System.out.println("verification complete.");
                        return 1;
                    } else if (action.contains("URL")) {
                        String currentURL = driver.getCurrentUrl();
                        if (currentURL.equalsIgnoreCase(data)) {
                            System.out.println("verification complete.");
                            return 1;
                        }
                    } else {
                        System.out.println("cound not complete verification. Please check verification step in testcase.");
                        return -1;
                    }
                }
            }
            return 1;
        } catch (Exception e) {

            return -1;

        }

    }

    private Locator ExecuteClickByLink(String clickAction, boolean bStoreLinkId, WebDriver driver) {
        System.out.println("ExecuteClickByLink");
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteClickByLink");

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            By elementLocation = By.linkText(clickAction);

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            objElement = driver.findElement(elementLocation);
            locator.setType(Types.LocatorType.linkText.name());
            locator.setValue(clickAction);

            if (bStoreLinkId) //store temporary linkID
            {
                strTempPOObjectID = objElement.getAttribute("href");
            }

            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            if (width <= 0 && height <= 0) {
                //something is wrong with controls
                //return -1;
                locator.setiRetVal(-1);
                return locator;
            }

            Actions act = new Actions(driver);

            if(performWebAction){
                if (objElement.isEnabled()) {

                    try {
                        objElement.click();
                    } catch (Exception ex) {
                        try{
                           JavascriptExecutor js = (JavascriptExecutor) driver;
                           js.executeScript("arguments[0].click();", objElement);
                        }catch (Exception ex1) {
                            act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                        }
                    }
                    Thread.sleep(actionDelay);

                    //do not add clickable controls , as those can be repeated.
                    ////////listAlreadyExecutedObjectOnGivenPAge.add(clickAction);
                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        //return 2;
                        locator.setiRetVal(2);
                        return locator;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                        } else {
                            //return 1;
                            locator.setiRetVal(1);
                            return locator;
                        }
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }

            //return 0;
            locator.setiRetVal(0);
            return locator;
        } catch (Exception e) {
            //return -1;
            locator.setiRetVal(-1);
            return locator;
        } finally {

        }

    }

    private Locator ExecuteHrefClickWithoutID(PageObject pageObject,Step step,String strElementAttributes, boolean bStoreLinkID, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("ExecuteHrefClickWithoutID");
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread().getStackTrace()[1].getMethodName() + " with : " + clickAction);
        String Xpath = "";
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteHrefClickWithoutID");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);
        try {
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have button - most probably htmlbutton
            //so getPageElements its type, class, name, displaytext,
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] buttonAtrrs = pattern.split(clickAction);
            String linkRef = "";
            String linkClass = "";
            String linkRelevance = "";
            String linkDisplayText = "";

            try {
                linkRef = buttonAtrrs[1];
                linkClass = buttonAtrrs[2];
                linkRelevance = buttonAtrrs[3];
                linkDisplayText = buttonAtrrs[4];
            } catch (Exception ex) {
            }

            List<WebElement> objElements = null;
            objElements = new ArrayList<WebElement>();

            //first use CSS selector in combination
            if (objElements.isEmpty()) {
                try {
                    System.out.println("Searching by CSS selector with class and href");
                    //this may return multple elements
                    String css = "." + linkClass + "[href='" + linkRef + "']";
                    objElements = driver.findElements(By.cssSelector(css));
                    locator.setType(Types.LocatorType.cssSelector.name());
                    locator.setValue(css);
                    System.out.println("Found elements by CSS selector: " + objElements.size()+ objElements.toString());
                } catch (Exception ex1) {
                    //do nothing
                    locator.setType(null);
                    locator.setValue(null);
                }
            }
            //then by xpath of href and class
            if (objElements.isEmpty()) {
                try {
                    System.out.println("Searching by xpath with class and href");
                    String buffXpath = "//a[" + "@class='" + linkClass + "' and @href='" + linkRef + "']";
                    objElements = driver.findElements(By.xpath(buffXpath));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue(buffXpath);
                    System.out.println("Found elements by xpath: " + objElements.size() + objElements.toString());
                } catch (Exception ex1) {
                    //do nothing
                    locator.setType(null);
                    locator.setValue(null);
                }
            }

            //then by xpath of href and class and text
            if (objElements.isEmpty()) {
                try {
                    System.out.println("Searching by xpath with class, href and display text");
                    String buffXpath = "//a[" + "@class='" + linkClass + "' and @href='" + linkRef + "' and contains(text()='" + linkDisplayText + "')]";
                    objElements = driver.findElements(By.xpath(buffXpath));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue(buffXpath);
                    System.out.println("Found elements by xpath: " + objElements.size() + objElements.toString());
                } catch (Exception ex1) {
                    //do nothing
                    locator.setType(null);
                    locator.setValue(null);
                }
            }

            //try to find by 'display text' /  inner text i.e. visible text attribute
            if (objElements.isEmpty()) {
                try {
                    System.out.println("Searching by link text with display text");
                    objElements = driver.findElements(By.linkText(linkDisplayText));
                    locator.setType(Types.LocatorType.linkText.name());
                    locator.setValue(linkDisplayText);
                    if (objElements.isEmpty()) {
                        objElements = driver.findElements(By.linkText("\"" + linkDisplayText + "\""));
                        locator.setType(Types.LocatorType.linkText.name());
                        locator.setValue("\"" + linkDisplayText + "\"");
                    }
                    if (objElements.isEmpty()) {
                        objElements = driver.findElements(By.cssSelector("a[contains('" + linkDisplayText + "')"));
                        locator.setType(Types.LocatorType.cssSelector.name());
                        locator.setValue("a[contains('" + linkDisplayText + "')");
                    }
                    if (objElements.isEmpty()) {
                        objElements = driver.findElements(By.xpath("//a[contains(.,'" + linkDisplayText + "')]"));
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue("//a[contains(.,'" + linkDisplayText + "')]");
                    }
                    System.out.println("Found elements by link text: " + objElements.size() + objElements.toString());

                } catch (Exception ex1) {
                    //do nothing
                    locator.setType(null);
                    locator.setValue(null);
                }
            }

            //there is no direct way to find element by using href.
            //by xpath of href
            if (objElements.isEmpty()) {
                try {
                    System.out.println("Searching by xpath with href");
                    objElements = driver.findElements(By.xpath("//a[@href='" + linkRef + "']"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//a[@href='" + linkRef + "']");
                    if (objElements.isEmpty()) {
                        objElements = driver.findElements(By.xpath("//a[contains(@href='" + linkRef + "')]"));
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue("//a[contains(@href='" + linkRef + "')]");
                    }
                    System.out.println("Found elements by href xpath: " + objElements.size() + objElements.toString());
                } catch (Exception ex1) {
                    //do nothing
                    locator.setType(null);
                    locator.setValue(null);
                }
            }

            //by CSS selector
            //html anchor elements dooes not support "name" attrbute hence not considering it
            //for CSS selector search
            if (objElements.isEmpty()) {
                //CSS selector support below locattor
                //Tag and ID
                //Tag and class
                //Tag and attribute
                //Tag, class, and attribute
                //Inner text
                //since there is no ID hence find by others
                if (objElements.isEmpty()) {
                    try {
                        System.out.println("Searching by CSS selector with href");
                        //by href
                        objElements = driver.findElements(By.cssSelector("a[href='" + linkRef + "']"));
                        locator.setType(Types.LocatorType.cssSelector.name());
                        locator.setValue("a[href='" + linkRef + "']");

                    } catch (Exception ex1) {
                        locator.setType(null);
                        locator.setValue(null);
                    }
                }
                if (objElements.isEmpty()) {
                    try {
                        //by attribute 'rel'
                        objElements = driver.findElements(By.cssSelector("a[rel='" + linkRelevance + "']"));
                        locator.setType(Types.LocatorType.cssSelector.name());
                        locator.setValue("a[rel='" + linkRelevance + "']");
                    } catch (Exception ex1) {
                        locator.setType(null);
                        locator.setValue(null);
                    }
                }
                if (objElements.isEmpty()) {
                    try {
                        //by class
                        //this may return many elements
                        objElements = driver.findElements(By.cssSelector("a." + linkClass));
                        locator.setType(Types.LocatorType.cssSelector.name());
                        locator.setValue("a." + linkClass);
                    } catch (Exception ex1) {
                        locator.setType(null);
                        locator.setValue(null);
                    }
                }
            }

            //then by class name
            if (objElements.isEmpty()) {
                try {
                    //this may return multple elements
                    objElements = driver.findElements(By.className(linkClass));
                    locator.setType(Types.LocatorType.className.name());
                    locator.setValue(linkClass);
                } catch (Exception ex1) {
                    //do nothing
                    locator.setType(null);
                    locator.setValue(null);
                }
            }

            if (objElements.isEmpty()) {
                try {
                    //by rel property
                    if (objElements.size() == 0 && linkRelevance.length() > 0) {
                        String url = driver.getCurrentUrl(); // getPageElements the current URL (full)
                        java.net.URL currentUri = new URL(url); // create a Uri instance of it
                        String baseUrl = currentUri.getAuthority(); // just getPageElements the "base" bit of the URL

                        //this is wrong but keep it for time being. as it may be pop up or actual diversion.
                        driver.navigate().to(baseUrl + linkRelevance);
                    }
                } catch (Exception ex1) {
                    //do nothing
                }
            }

            if (objElements.isEmpty()) {
                List<WebElement> allLinks = driver.findElements(By.tagName("a"));
                for (WebElement link : allLinks) {
                    if (link.getAttribute("id").isEmpty() && (!link.getText().isEmpty())) {

                        //this will only work if all attributes are returned in same sequence
                        String strCurrentAllAttribute = FindAllAttributes(link, driver);

                        strCurrentAllAttribute = strCurrentAllAttribute.replaceAll(",", "");
                        strElementAttributes = strElementAttributes.replaceAll(",", "");

                        if (strElementAttributes.equalsIgnoreCase(strCurrentAllAttribute)) {
                            objElements.add(link);
                        }
                    }
                }

            }
            ///////////////////////////////////////

            if(performWebAction){
                if (bIsIFrameControl) {
                    //driver.switchTo().frame(iFrameId);
                }

                Actions act = new Actions(driver);

                if (bStoreLinkID) //store temporary linkID
                {
                    strTempPOObjectID = clickAction;
                }
                if (objElements.size() > 0) {
                    System.out.println("Found " + objElements.size() + " elements with same properties");
                    //found many elements with same properties
                    WebElement objElement = null;
                    for (WebElement element : objElements) {
                        System.out.println("element.getText()="+element.getText() +", linkDisplayText="+linkDisplayText+", href="+element.getAttribute("href")+", linkRef="+linkRef +", fieldValue="+step.getFieldValue()+", aria-label"+ element.getAttribute("aria-label"));
                        //1st checklist - checking text and href of element with linkDisplayText and linkRef
                        if (element.getText().equalsIgnoreCase(linkDisplayText)
                                || element.getAttribute("href").equalsIgnoreCase(linkRef)) {
                            System.out.println("First shortlisted element by checking text and href");
                            objElement = element;
                        }
                        //put any other check to shortlist element
                        //2nd checklist - added this checklist because there may be multiple elements with same text
                        //added one more checklist to shortlist into a single element - if element have aria-label and its aria-label contains step's field value
                        System.out.println("Checking if element's aria-label contains step's field value");
                        if(element.getAttribute("aria-label") != null && element.getAttribute("aria-label").contains(step.getFieldValue())){
                            System.out.println("Shortlisted element by checking whether element's aria-label contains step's field value");
                            objElement = element;
                        }
                    }
                    if ((objElement != null) && (objElement.isEnabled())) {
                        System.out.println("Found element with text: " + objElement.getText() + " and href: " + objElement.getAttribute("href"));
                        int width = objElement.getSize().getWidth();
                        int height = objElement.getSize().getHeight();

                        if (width <= 0 && height <= 0) {
                            //Add a logic to handle the user xpath flow
                            //throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                            //commented the above exception throw cause sometimes even if width and height is 0 we can still try to navigate to page via href url
                            try{
                                driver.navigate().to(objElement.getAttribute("href"));
                                locator.setActionMethod(Types.ActionMethod.defaultt.name());
                            } catch (Exception e) {
                                throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                            }
                        } else {
                            try {
                                objElement.click();
                                locator.setActionMethod(Types.ActionMethod.defaultt.name());
                            } catch (Exception ex) {
                                try{
                                    JavascriptExecutor js = (JavascriptExecutor) driver;
                                    js.executeScript("arguments[0].click();", objElement);
                                    locator.setActionMethod(Types.ActionMethod.defaultt.name());
                                }catch(Exception ex1){
                                    locator.setiRetVal(-1);
                                    return locator;
                                }
                            }
                        }
                    }
                    else{
                        //Add a logic to handle
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                    }
                }
                Thread.sleep(actionDelay);
            }



            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }

            String NextURL = driver.getCurrentUrl();
            String NextTitle = driver.getTitle();

            if (!(currentURL.equalsIgnoreCase(NextURL))
                    || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                //it means page is changed
                locator.setiRetVal(2);
                return locator;
                //return 2;
            } else {

                // CheckIfPopup windows is launched
                boolean bPopUpWindowAppeared = false;
                String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                String subWindowHandler = null;

                Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                Iterator<String> iterator = handles.iterator();
                while (iterator.hasNext()) {
                    subWindowHandler = iterator.next();
                }

                if (subWindowHandler != null) {
                    driver.switchTo().window(subWindowHandler); // switch to popup window
                    bPopUpWindowAppeared = true;
                }

                // Now you are in the popup window, perform necessary actions here
                //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                if (bPopUpWindowAppeared) {
                    locator.setiRetVal(3);
                    return locator;
                    //return 3;
                } else {
                    locator.setiRetVal(1);
                    return locator;
                    //return 1;
                }
            }

        } catch (LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
//        catch (Exception e) {
//            System.out.println("Execption in ExecuteHrefClickWithoutID: " + e.getMessage());
//            locator.setiRetVal(-1);
//            return locator;
//            //return -1;
//        } finally {
//            //this will getPageElements executed two times but its ok
//            if (bIsIFrameControl) {
//                //driver.switchTo().defaultContent();
//            }
//        }

    }


    private Locator getXpathUsingAttributesForElement (WebElement objElement, Locator locator, WebDriver driver) {
        Map<String, String> availableAttributes = new HashMap<>();
        String tagName = objElement.getTagName();
        String type = "";
        if(!StringUtils.isEmpty(objElement.getAttribute("type"))) {
            type = objElement.getAttribute("type");
            availableAttributes.put("type", type);
        }
        if(!StringUtils.isEmpty(objElement.getAttribute("name"))) {
            availableAttributes.put("name", objElement.getAttribute("name"));
        }
        if(!tagName.equalsIgnoreCase("input") &&
                !StringUtils.isEmpty(objElement.getAttribute("value"))) {
            availableAttributes.put("value", objElement.getAttribute("value"));
        }
        if(tagName.equalsIgnoreCase("input") &&
                !(type.equalsIgnoreCase("text") ||
                        type.equalsIgnoreCase("password")) &&
                !StringUtils.isEmpty(objElement.getAttribute("value"))) {
            availableAttributes.put("value", objElement.getAttribute("value"));
        }
        if(!StringUtils.isEmpty(objElement.getAttribute("class"))) {
            availableAttributes.put("class", objElement.getAttribute("class"));
        }
        if(!StringUtils.isEmpty(objElement.getAttribute("placeholder"))) {
            availableAttributes.put("placeholder", objElement.getAttribute("placeholder"));
        }
        String xpath = "//" + tagName + "[";
        Iterator<Map.Entry<String, String>> iterator = availableAttributes.entrySet().iterator();
        Map.Entry<String, String> entry;
        while (iterator.hasNext()) {
            entry = iterator.next();
            xpath += "@"+entry.getKey()+"='"+entry.getValue()+"'";
            if(isThisXpathHasOnlyOneElement(xpath, driver)) {
                break;
            }
            if(iterator.hasNext()){
                xpath += " and ";
            }
        }
        xpath += "]";
        locator.setType(Types.LocatorType.xpath.name());
        locator.setValue(xpath);
        return locator;
    }

    private Boolean isThisXpathHasOnlyOneElement (String xpathString, WebDriver driver) {
        xpathString += "]";
        List<WebElement> elements = driver.findElements(By.xpath(xpathString));
        return elements.size() == 1;
    }

    private Locator ExecuteSpanClickWithoutID(PageObject pageObject, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("ExecuteSpanClickWithoutID");
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteSpanClickWithoutID");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);
        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have button - most probably htmlbutton which pain in axxxxx.
            //so getPageElements its type, class, name, displaytext,
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] buttonAtrrs = pattern.split(clickAction);
            String buttonType = "";
            String buttonClass = "";
            String buttonName = "";
            String buttonDisplayText = "";
            String buttonOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                buttonType = buttonAtrrs[1];
                buttonClass = buttonAtrrs[2];
                buttonName = buttonAtrrs[3];
                buttonDisplayText = buttonAtrrs[4];
                buttonOnClick = buttonAtrrs[5];
            } catch (Exception ex) {

            }

            if (buttonClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                buttonClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }

            //try to find by 'name'
            List<WebElement> objElements = null;
            try {
                objElements = driver.findElements(By.name(buttonName));
                locator.setType(Types.LocatorType.name.name());
                locator.setValue(buttonName);
            } catch (Exception ex) {
            }

            //try to find by 'display text'
            try {
                if (objElements.isEmpty()) {
                    //by xpath name
                    String label = buttonDisplayText;
                    objElements = driver.findElements(By.xpath("//button[contains(.,'" + label + "')]"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//button[contains(.,'" + label + "')]");
                }
            } catch (Exception ex) {
            }

            //xpath by buttonDisplayText
            try {
                if (objElements.isEmpty()) {
                    objElements = driver.findElements(By.xpath("//span[contains(text(),'" + buttonDisplayText + "')]"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//span[contains(text(),'" + buttonDisplayText + "')]");
                }
            } catch (Exception ex) {
                //do nothing
            }

            //xpath by class + buttonDisplayText
            try {
                if (objElements.isEmpty()) {
                    //span[@class='hidden-xs hidden-sm hidden-md' and contains(text(),'My Account')]
                    objElements = driver.findElements(By.xpath("//span[@class='" + buttonClass + "' and contains(text(),'" + buttonDisplayText + "')]"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//span[@class='" + buttonClass + "' and contains(text(),'" + buttonDisplayText + "')]");
                }
            } catch (Exception ex) {
                //do nothing
            }

            //try to find by 'class'
            try {
                if (objElements.isEmpty()) {
                    if (bUseCSSSelector) {
                        //by CSSselector
                        objElements = driver.findElements(By.cssSelector(buttonClass));
                        locator.setType(Types.LocatorType.cssSelector.name());
                        locator.setValue(buttonClass);
                    } else {
                        //by class name
                        objElements = driver.findElements(By.className(buttonClass));
                        locator.setType(Types.LocatorType.className.name());
                        locator.setValue(buttonClass);
                    }
                }
            } catch (Exception ex) {
                //to debug - remove later
                ex.printStackTrace();
            }

            objElement = null;

            if (objElements.size() == 1) {
                objElement = objElements.get(0);
            } else if (objElements.size() > 1) {

                //
                for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                    //search and filter using display text
                    //need to check if any other better way to filter it
                    if (objElements.get(iCnt).getText().equalsIgnoreCase(buttonDisplayText)) {
                        objElement = objElements.get(iCnt);
                        break;
                    }
                }
            }

            //if still we could not locate this span webelement then follow rudimentory way
            objElements.clear();
            if (objElement == null) {
                List<WebElement> buttons = driver.findElements(By.tagName("span"));
                System.out.println("Filtering valid span-element among : " + buttons.size() + " spans");
                Properties p = new Properties();
                for (WebElement button : buttons) {

                    //print the links texts and links
                    String buttonID = "";
                    if (button.isDisplayed() && (ExpectedConditions.elementToBeClickable(button) != null)) {

                        if (button.getAttribute("id").isEmpty() || button.getAttribute("id").equals("")) {
                            //create button id with type, class and onclick
                            //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                            buttonID = "spspanid" + "_$_";

                            try {
                                buttonID += button.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getText() + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            try {
                                //because in case of user slelection of objects, we are remvoing brackets
                                buttonID += button.getAttribute("onclick").replace("()", "{}") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            //  emap.put(buttonID, aa.toString());

                        }

                        if (buttonID.equalsIgnoreCase(clickAction)) {
                            objElement = button;
                            locator = getXpathUsingAttributesForElement(objElement, locator, driver);
                            break;
                        }
                    }

                }
            }
            //after above if and loop objElement(webelement) has to be found else return error

            if (objElement == null) {
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }
            System.out.println("Final objElement--->"+objElement);

            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            if(performWebAction){
                Actions act = new Actions(driver);
                if (objElement.isEnabled()) {

                    //objElement.click();
                    String strElementype = objElement.getAttribute("type");
                    if (objElement != null) {
                        try {
                            objElement.click();
                            locator.setActionMethod(Types.ActionMethod.defaultt.name());
                        } catch (Exception ex) {
                            try {
                                ((JavascriptExecutor) driver).executeScript(
                                        "arguments[0].click();",
                                        objElement);
                                locator.setActionMethod(Types.ActionMethod.javascriptexecutor.name());
                            } catch (Exception ex1) {
                                try {
                                    act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                                    locator.setActionMethod(Types.ActionMethod.actions.name());
                                } catch (Exception ex2) {
                                    // any other worst case ???
                                    //try to getPageElements correct locator
                                    String Xpath = "//span[contains(@class,'" + buttonClass + "') and contains(@onclick,'" + buttonOnClick + "')]";
                                    try {
                                        driver.findElement(By.xpath(Xpath)).click();
                                        locator.setType(Types.LocatorType.xpath.name());
                                        locator.setValue(Xpath);
                                        locator.setActionMethod(Types.ActionMethod.defaultt.name());
                                    } catch (Exception ex3) {
                                        locator.setiRetVal(-1);
                                        return locator;
                                        //return -1;
                                    }
                                }

                            }
                        }

                    } else {

                        //Add a logic to handle the user xpath flow
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                    }

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                        //return 2;
                    }
                    else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            //return 3;
                        } else {
                            locator.setiRetVal(1);
                            //return 1;
                        }
                        return locator;
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }

            locator.setiRetVal(0);
            return locator;
            //return 0;

        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        }catch (Exception e) {
            e.printStackTrace();
            locator.setiRetVal(-1);
            return locator;
            //return -1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }

    }

    private Locator ExecuteDivClickWithoutID(PageObject pageObject, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("ExecuteDivClickWithoutID");
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteDivClickWithoutID");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have button - most probably htmlbutton which pain in axxxxx.
            //so getPageElements its type, class, name, displaytext,
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] buttonAtrrs = pattern.split(clickAction);
            String buttonType = "";
            String buttonClass = "";
            String buttonName = "";
            String buttonDisplayText = "";
            String buttonOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                buttonType = buttonAtrrs[1];
                buttonClass = buttonAtrrs[2];
                buttonName = buttonAtrrs[3];
                buttonDisplayText = buttonAtrrs[4];
                buttonOnClick = buttonAtrrs[5];
            } catch (Exception ex) {

            }

            if (buttonClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                buttonClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }

            //try to find by 'name'
            List<WebElement> objElements = null;
            try {
                objElements = driver.findElements(By.name(buttonName));
                locator.setType(Types.LocatorType.name.name());
                locator.setValue(buttonName);
            } catch (Exception ex) {
            }

            //try to find by 'display text'
            try {
                if (objElements.isEmpty()) {
                    //by xpath name
                    String label = buttonDisplayText;
                    objElements = driver.findElements(By.xpath("//div[contains(.,'" + label + "')]"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue(label);
                }
            } catch (Exception ex) {
            }

            //try to find by 'class'
            try {
                if (objElements.isEmpty()) {

                    if (bUseCSSSelector) {
                        //by CSSselector
                        objElements = driver.findElements(By.cssSelector(buttonClass));
                        locator.setType(Types.LocatorType.cssSelector.name());
                        locator.setValue(buttonClass);
                    } else {
                        //by class name
                        objElements = driver.findElements(By.className(buttonClass));
                        locator.setType(Types.LocatorType.className.name());
                        locator.setValue(buttonClass);
                    }
                }
            } catch (Exception ex) {
                //to debug - remove later
                ex.printStackTrace();
            }

            //xpath by class + buttonDisplayText
            try {
                if (objElements.isEmpty()) {
                    objElements = driver.findElements(By.xpath("//div[@class='" + buttonClass + "' and contains(text(),'" + buttonDisplayText + "')]"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//div[@class='" + buttonClass + "' and contains(text(),'" + buttonDisplayText + "')]");
                }
            } catch (Exception ex) {
                //do nothing
            }

            objElement = null;

            if (objElements.size() == 1) {
                objElement = objElements.get(0);
            } else if (objElements.size() > 1) {

                //
                for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                    //search and filter using display text
                    //need to check if any other better way to filter it
                    if (objElements.get(iCnt).getText().equalsIgnoreCase(buttonDisplayText)) {
                        objElement = objElements.get(iCnt);
                        break;
                    }
                }
            }

            //if still we could not locate this div webelement then follow rudimentory way
            objElements.clear();
            if (objElement == null) {
                List<WebElement> buttons = driver.findElements(By.tagName("div"));
                System.out.println("Filtering valid div-element among : " + buttons.size() + " divs");
                Properties p = new Properties();
                for (WebElement button : buttons) {

                    //print the links texts and links
                    String buttonID = "";
                    if (button.isDisplayed() && (ExpectedConditions.elementToBeClickable(button) != null)) {

                        if (button.getAttribute("id").isEmpty() || button.getAttribute("id").equals("")) {
                            //create button id with type, class and onclick
                            //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                            buttonID = "spdivid" + "_$_";

                            try {
                                buttonID += button.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getText() + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            try {
                                //because in case of user slelection of objects, we are remvoing brackets
                                buttonID += button.getAttribute("onclick").replace("()", "{}") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            //  emap.put(buttonID, aa.toString());

                        }

                        if (buttonID.equalsIgnoreCase(clickAction)) {
                            objElement = button;
                            locator = getXpathUsingAttributesForElement(objElement, locator, driver);
                            break;
                        }
                    }

                }
            }
            //after above if and loop objElement(webelement) has to be found else return error

            if (objElement == null) {
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            if(performWebAction){
                Actions act = new Actions(driver);
                if (objElement.isEnabled()) {

                    //objElement.click();
                    String strElementype = objElement.getAttribute("type");
                    if (objElement != null) {
                        try {
                            objElement.click();
                            locator.setActionMethod(Types.ActionMethod.defaultt.name());

                        } catch (Exception ex) {
                            try {
                                ((JavascriptExecutor) driver).executeScript(
                                        "arguments[0].click();",
                                        objElement);
                                locator.setActionMethod(Types.ActionMethod.javascriptexecutor.name());
                            } catch (Exception ex1) {
                                try {
                                    act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                                    locator.setActionMethod(Types.ActionMethod.actions.name());
                                } catch (Exception ex2) {
                                    // any other worst case ???
                                    //try to getPageElements correct locator
                                    String Xpath = "//div[contains(@class,'" + buttonClass + "') and contains(@onclick,'" + buttonOnClick + "')]";
                                    try {
                                        driver.findElement(By.xpath(Xpath)).click();
                                        locator.setType(Types.LocatorType.xpath.name());
                                        locator.setValue(Xpath);
                                        locator.setActionMethod(Types.ActionMethod.defaultt.name());
                                    } catch (Exception ex3) {
                                        locator.setiRetVal(-1);
                                        return locator;
                                        //return -1;
                                    }
                                }

                            }
                        }

                    } else {

                        //Add a logic to handle the user xpath flow
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                    }

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                        //return 2;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                            //return 3;
                        } else {
                            locator.setiRetVal(1);
                            return locator;
                            //return 1;
                        }
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }

            locator.setiRetVal(0);
            return locator;
            //return 0;

        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        }catch (Exception e) {
            locator.setiRetVal(-1);
            return locator;
            //return -1;

        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }

    }

    private Locator ExecuteCheckBoxClickWithoutIDEx(PageObject pageObject, String objAllAtt, WebDriver driver) {
        System.out.println("ExecuteCheckBoxClickWithoutIDEx");
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        WebElement objPO = pageObject.objectElement;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteCheckBoxClickWithoutIDEx");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {

            //Map<String, PageObject> lmapPageObjects = new HashMap<String, PageObject>();
            List<WebElement> allWebElementList = new ArrayList<WebElement>();
            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");
            objElement = null;

            //commenting this as we have original object with us.
            //need to review again.
            //we have checkbox - most probably multiselect dropdown with lable and check combo which is really pain in axxxxx.
            //so getPageElements its type, class, name, displaytext,
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] ddAtrrs = pattern.split(clickAction);
            String chkboxType = "";
            String chkboxParentId = "";
            String chkboxParentVisibleText = "";
            try {
                chkboxType = ddAtrrs[0];
                chkboxParentId = ddAtrrs[1];
                chkboxParentVisibleText = ddAtrrs[2];

            } catch (Exception ex) {

            }

            // This function is used for FResh Run and Stored run in case of Fresh Run WebElement object
            // will be send. In case of stored run All attribute will be send.
            if (objPO == null) {

                List<WebElement> inputs = driver.findElements(By.tagName("input"));

                for (WebElement input : inputs) {

                    if (input.isDisplayed()) {

                        //input element can be anything
                        //text
                        //checkbox
                        //radio
                        //what else
                        //so getPageElements class and check
                        String inputType = input.getAttribute("type");
                        String visibletext = input.getText();

                        if (visibletext.isEmpty() || visibletext.length() <= 0) {
                            visibletext = input.getAttribute("value");
                        }
                        if (input.getAttribute("id").isEmpty() || input.getAttribute("id").equals("")) {
                            //create button id with type, class and onclick
                            //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                            String inputID = "spinputid" + "_$_";

                            try {
                                inputID += input.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            try {
                                inputID += input.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            try {
                                inputID += input.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            // Need to check the
//                            lmapPageObjects.put(inputID, new PageObject(0, inputID, "input", input.getText(), input, false, "", ""));
                            if (inputID.equalsIgnoreCase(clickAction)) {
                                allWebElementList.add(input);
                                locator = getXpathUsingAttributesForElement(input, locator, driver);
                                break;
                            }
                        } else {
                            //  mapPageObjects.put(input.getAttribute("id"), new PageObject(0, input.getAttribute("id"), "input", visibletext, input, bIsIframeControl, iFrameID, ""));
                            // Ideally it should not come here as ID is present.
                        }

                    }
                }
                //do the same for label
                List<WebElement> labels = driver.findElements(By.tagName("label"));
                System.out.println("Actionable labels inputs found on web page are: " + labels.size() + " inputs");
                for (WebElement label : labels) {
                    if (label.isDisplayed() && (ExpectedConditions.elementToBeClickable(label) != null)) {
                        String labelElement = "";
                        try {
                            labelElement = label.getAttribute("for");
                            System.out.println("Label Attribute FOR-" + labelElement);

                            if (Strings.isNullOrEmpty(labelElement) || labelElement.isEmpty()) {
                                //search if this label includes other control like input of type checkbox or else
                                String labelType = label.getAttribute("class");
                                //need to add other class types as well
                                if (!labelType.isEmpty()) {
                                    //it means some input type may be included as part of this lable
                                    //like checkbox or radio etc
                                    //so it means this lable wont have any id or href
                                    //that another embeeded control needs to be clicked.

                                    //so getPageElements all child elements of this label
                                    List<WebElement> childs = label.findElements(By.xpath(".//*"));
                                    for (int iCnt = 0; iCnt < childs.size(); iCnt++) {
                                        WebElement childElement = childs.get(iCnt);
                                        String childTag = childElement.getTagName();

                                        if (childTag.equalsIgnoreCase("input")) {
                                            if (childElement.isDisplayed()) {
                                                //input element can be anything
                                                //text
                                                //checkbox
                                                //radio
                                                //what else
                                                //so getPageElements class and check
                                                String inputType = childElement.getAttribute("type");

                                                String visibletext = childElement.getText();
                                                if (visibletext.isEmpty() || visibletext.length() <= 0) {
                                                    //here getPageElements value of parent element i.e. label
                                                    visibletext = label.getText();
                                                }
                                                //lmapPageObjects.put(childElement.getAttribute("id"), new PageObject(0, childElement.getAttribute("id"), "input", visibletext, childElement, false, "", ""));
                                                allWebElementList.add(childElement);
                                            }
                                        }
                                    }
                                }
                            } else {
                                //so getPageElements all child elements of this label
                                List<WebElement> childs = label.findElements(By.xpath(".//*"));
                                System.out.println("Actionable childs inputs found on web page are: " + childs.size() + " childs");
                                if (childs.size() > 0) {
                                    for (int iCnt = 0; iCnt < childs.size(); iCnt++) {
                                        WebElement childElement = childs.get(iCnt);
                                        String childTag = childElement.getTagName();
                                        System.out.println("Child input found on web page are TagName:" + childElement.getTagName() + " ->Text= " + childElement.getText() + " ID= " + childElement.getAttribute("id") + " Type= " + childElement.getAttribute("type"));
                                        {
                                            if (childTag.equalsIgnoreCase("input") || childTag.equalsIgnoreCase("span")) { // ARP Added
                                                if (childElement.isDisplayed()) {
                                                    //input element can be anything
                                                    //text
                                                    //checkbox
                                                    //radio
                                                    //what else
                                                    //so getPageElements class and check
                                                    String inputType = childElement.getAttribute("type");
                                                    System.out.println("Childs inputs found on InputType: " + inputType);
                                                    String visibletext = childElement.getText();
                                                    if (visibletext.isEmpty() || visibletext.length() <= 0) {
                                                        visibletext = label.getText();
                                                    }
                                                    if (!childElement.getAttribute("id").isEmpty()) {
                                                        // Ideally it should not come here ..... :(
                                                        //lmapPageObjects.put(childElement.getAttribute("id"), new PageObject(0, childElement.getAttribute("id"), "input", visibletext, childElement, bIsIframeControl, iFrameID, ""));
                                                    } else {
                                                        //get parent of tihs label which should be having ID
                                                        WebElement parentElementWithID = label.findElement(By.xpath("./.."));

                                                        String customID = "spchkbxid" + "_$_" + parentElementWithID.getAttribute("id") + "_$_" + visibletext;

                                                        //if this element does not have ID then god only can click on this checkbox/redio etc
//                                                        lmapPageObjects.put(customID, new PageObject(0, customID, "input", visibletext, childElement, false, "", ""));
                                                        allWebElementList.add(childElement);
                                                    }

                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        } catch (Exception e) {
                            labelElement = "";
                            try {
                                String labelType = label.getAttribute("type");
                                //need to add other class types as well
                                if (labelType.equalsIgnoreCase("checkbox")) {
                                    labelElement = label.getAttribute("id");
                                }
                            } catch (Exception ex2) {

                            }
                        }
                        //lmapPageObjects.put(labelElement, new PageObject(0, labelElement, "label", label.getText(), label, false, "", labelElement));
                        allWebElementList.add(label);
                    }

                }

                List<WebElement> objElements = null;
                objElements = new ArrayList<WebElement>();
                //for (Map.Entry<String, Test2.PageObject> entryPO : lmapPageObjects.entrySet()) {
                for (WebElement elementSelected : allWebElementList) {
                    //String TestStepSeqID = entryPO.getKey();
                    //PageObject ObjectActions = entryPO.getValue();

                    System.out.println("*******    ObjectAction on :'" + elementSelected.getText());
                    if (chkboxParentVisibleText.equals(elementSelected.getText())) {

                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        Object objAllAttribute = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", elementSelected);
                        String strAllAttribute = objAllAttribute.toString();
                        strAllAttribute = strAllAttribute.replaceAll("\\{", "");
                        strAllAttribute = strAllAttribute.replaceAll("\\}", "");

                        List<String> allAttList = new ArrayList<String>();

                        String[] arrOfStr = strAllAttribute.split(",");
                        for (String a : arrOfStr) {
                            allAttList.add(a);
                        }

                        List<String> targetEleAttList = new ArrayList<String>();

                        String[] arrTargetEleAtt = objAllAtt.split(",");
                        for (String b : arrTargetEleAtt) {
                            targetEleAttList.add(b);
                        }

                        // Need to convert in list and then compare . Not Direct compare.
                        //SendDisplayLogToClient("----ObjectAction VisiableTxt -" + chkboxParentVisibleText + " All Attribute Str-" + strAllAttribute + " Parameter" + objAllAtt);
                        if (targetEleAttList.equals(allAttList)) {
                            //SendDisplayLogToClient("----Found Object -----");
                            objElements.add(elementSelected);
                        }
                    }
                }

                if (objElements.size() == 1) {
                    objElement = objElements.get(0);
                } else {
                    //need to removelater

                    if (objElements.size() > 1) {
                        objElement = objElements.get(0);
                    }
                    for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                        //ask use which one to select
                        //t odo
                    }
                }

            } else {
                objElement = objPO;  // We are assigning the WebElement in case of Fresh Run
                try {
                    locator.setValue(objElement.getAttribute("id"));
                    locator.setType(Types.LocatorType.id.name());
                } catch (Exception ex1) {
                    try {
                        String value = objElement.getAttribute("value");
                        locator.setValue("//input[@type='checkbox' and @value='" + value + "']");
                        locator.setType(Types.LocatorType.xpath.name());
                    } catch(Exception ex2) {
                        try {
                            locator.setValue(objElement.getAttribute("name"));
                            locator.setType(Types.LocatorType.name.name());
                        } catch(Exception ex) {
                            // add try/catch in case there are any more combinations added
                        }
                    }
                }
            }

            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            if (width <= 0 && height <= 0) {
                //something is wrong with controls
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }

            Actions act = new Actions(driver);
            if(performWebAction){
                if (objElement.isEnabled()) {

                    String strElementype = objElement.getAttribute("type");

                    try {
                        objElement.click();
                        locator.setActionMethod(Types.ActionMethod.defaultt.name());
                    } catch (Exception ex) {
                        try {
                            ((JavascriptExecutor) driver).executeScript( "arguments[0].click();", objElement);
                            locator.setActionMethod(Types.ActionMethod.javascriptexecutor.name());
                        }catch(Exception ex1){
                            act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                            locator.setActionMethod(Types.ActionMethod.actions.name());
                        }
                    }

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                        //return 2;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                            //return 3;
                        } else {
                            locator.setiRetVal(1);
                            return locator;
                            //return 1;
                        }
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }
            locator.setiRetVal(0);
            return locator;
            //return 0;

        } catch (Exception e) {
            locator.setiRetVal(-1);
            return locator;
            //return -1;

        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }

        }

    }

    private Locator ExecuteButtonClickWithoutID(PageObject pageObject, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("ExecuteButtonClickWithoutID"+pageObject.ObjectId);
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteButtonClickWithoutID");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            if (clickAction.toLowerCase().contains("payment")) {
                int i = 0;
                i++;
            }
            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have button - most probably htmlbutton which pain in axxxxx.
            //so getPageElements its type, class, name, displaytext,
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] buttonAtrrs = pattern.split(clickAction);
            String buttonType = "";
            String buttonClass = "";
            String buttonName = "";
            String buttonDisplayText = "";
            String buttonOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                buttonType = buttonAtrrs[1];
                buttonClass = buttonAtrrs[2];
                buttonName = buttonAtrrs[3];
                buttonDisplayText = buttonAtrrs[4];
                buttonOnClick = buttonAtrrs[5];
            } catch (Exception ex) {

            }

//            if (buttonClass.contains(" ")) {
//                //replace all spaces in classname with . and then use cssselector
//                buttonClass.replaceAll(" ", ".");
//                bUseCSSSelector = true;
//            }

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }
            //try to find by 'name'
            List<WebElement> objElements = new ArrayList<>();
            //try find by display text
            try {
                //by xpath name
                String label = buttonDisplayText;
                label = label.replace("'", "\\\\'");
                objElements = driver.findElements(By.xpath("//button[contains(.,'" + label + "')]"));
                locator.setType(Types.LocatorType.xpath.name());
                locator.setValue("//button[contains(.,'" + label + "')]");

            } catch (Exception ex) {
            }
            //button[@value='Continue']
            if(objElements.isEmpty()) {
                try {
                    //by value capitalized
                    String temp = buttonDisplayText;
                    String value = StringUtils.capitalize(temp.toLowerCase());
                    objElements = driver.findElements(By.xpath("//button[@value='" + value + "']"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//button[@value='" + value + "']");
                } catch (Exception ex) {
                }
            }
            //ignore @value case sensitive
            if(objElements.isEmpty()) {
                try {
                    String temp = buttonDisplayText;
                    String lowerCase = temp.trim().toLowerCase();
                    String upperCase = temp.trim().toUpperCase();
//                    String lowerCase = StringUtils.capitalize(temp.toLowerCase());
//                    String upperCase = StringUtils.capitalize(temp.toUpperCase());
                    objElements = driver.findElements(By.xpath(
                            "//button[contains(translate(@value, '"+
                                    upperCase + "', '" + lowerCase + "'), '" +
                                    lowerCase + "')]"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//button[contains(translate(@value, '"+
                            upperCase + "', '" + lowerCase + "'), '" +
                            lowerCase + "')]");
                } catch (Exception ex) {
                }
            }

            //ignore text() case sensitive
            if(objElements.isEmpty()) {
                try {
                    String temp = buttonDisplayText;
                    String lowerCase = temp.trim().toLowerCase();
                    String upperCase = temp.trim().toUpperCase();
//                    String lowerCase = StringUtils.capitalize(temp.toLowerCase());
//                    String upperCase = StringUtils.capitalize(temp.toUpperCase());
                    objElements = driver.findElements(By.xpath(
                            "//button[contains(translate(text(), '"+
                                    upperCase + "', '" + lowerCase + "'), '" +
                                    lowerCase + "')]"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//button[contains(translate(text(), '"+
                            upperCase + "', '" + lowerCase + "'), '" +
                            lowerCase + "')]");
                } catch (Exception ex) {
                }
            }

            if (objElements.isEmpty()) {
                // by name
                try {
                    objElements = driver.findElements(By.name(buttonName));
                    locator.setType(Types.LocatorType.name.name());
                    locator.setValue(buttonName);
                } catch (Exception ex) {
                }
            }

            //by class name
            if (objElements.isEmpty()) {
                try {
                    if(driver.findElements(By.className(buttonClass)).size() == 1) {
                        objElements = driver.findElements(By.className(buttonClass));
                        locator.setType(Types.LocatorType.className.name());
                        locator.setValue(buttonClass);
                    }
                } catch (Exception ex) {
                }
            }

            //by CSSselector
            if (objElements.isEmpty()) {
                try {
                    String tempClass = buttonClass;
                    tempClass.replaceAll(" ", ".");
                    objElements = driver.findElements(By.cssSelector(tempClass));
                    locator.setType(Types.LocatorType.cssSelector.name());
                    locator.setValue(tempClass);
                } catch (Exception ex) {
                }
            }

            //try find by display class
            try {
                if (objElements.isEmpty()) {

                    if (bUseCSSSelector) {
                        //by CSSselector
                        objElements = driver.findElements(By.cssSelector(buttonClass));
                        locator.setType(Types.LocatorType.cssSelector.name());
                        locator.setValue(buttonClass);
                    } else {
                        //by class name
                        objElements = driver.findElements(By.className(buttonClass));
                        locator.setType(Types.LocatorType.className.name());
                        locator.setValue(buttonClass);
                    }
                }
            } catch (Exception ex) {
                //to debug - remove later
                ex.printStackTrace();
            }

            objElement = null;

            //
//do the same for buttons
            if (objElements.isEmpty()) {
                List<WebElement> buttons = driver.findElements(By.tagName("button"));
                System.out.println("Scanning valid button-element among : " + buttons.size() + " Buttons");
                Properties p = new Properties();
                for (WebElement button : buttons) {

                    //print the links texts and links
                    String buttonID = "";
                    if (button.isDisplayed() && (ExpectedConditions.elementToBeClickable(button) != null)) {

                        if (button.getAttribute("id").isEmpty() || button.getAttribute("id").equals("")) {
                            //create button id with type, class and onclick
                            //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                            buttonID = "spbuttonid" + "_$_";

                            try {
                                buttonID += button.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }

                            try {
                                buttonID += button.getText() + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            try {
                                //because in case of user slelection of objects, we are remvoing brackets
                                buttonID += button.getAttribute("onclick").replace("()", "{}") + "_$_";
                            } catch (Exception ex) {
                                buttonID += "null_$_";
                            }
                            //  emap.put(buttonID, aa.toString());

                        }

                        if (buttonID.equalsIgnoreCase(clickAction)) {
                            objElements.add(button);
                            locator = getXpathUsingAttributesForElement(button, locator, driver);
                            break;
                        }
                    }

                }
            }

            if (objElements.isEmpty()) {
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }

            if (objElements.size() == 1) {
                objElement = objElements.get(0);
            } else if (objElements.size() > 1) {
                objElement = objElements.get(0); //temp code
                //
                for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                    //ask use which one to select
                    //t odo
                }
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

//            if (bIsIFrameControl) {
//                //driver.switchTo().frame(iFrameId);
//            }

            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            if(performWebAction){
                Actions act = new Actions(driver);
                if (objElement.isEnabled()) {
                    String strElementype = objElement.getAttribute("type");
                    if (strElementype != null) {
                        try {
                            objElement.click();
                            locator.setActionMethod(Types.ActionMethod.defaultt.name());
                        } catch (Exception ex) {
                            try {
                                act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                                locator.setActionMethod(Types.ActionMethod.actions.name());
                            } catch (Exception e) {
                                JavascriptExecutor js = (JavascriptExecutor) driver;
                                js.executeScript("arguments[0].click();", objElement);
                            }
                        }

                    } else {

                        //Add a logic to handle the user xpath flow
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);

                    }

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                        //return 2;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                            //return 3;
                        } else {
                            locator.setiRetVal(1);
                            return locator;
                            //return 1;
                        }
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }

            locator.setiRetVal(0);
            return locator;
            //return 0;
        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        }catch (Exception e) {
            e.printStackTrace();
            locator.setiRetVal(-1);
            return locator;
            //return -1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }

    }

    private Locator ExecuteInputClickWithoutID(PageObject pageObject, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("ExecuteInputClickWithoutID");
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing ExecuteInputClickWithoutID: " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteInputClickWithoutID");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have input - most probably htmlbutton which pain in axxxxx.
            //so getPageElements its type, class, name, displaytext,
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] inputAtrrs = pattern.split(clickAction);
            String inputType = "";
            String inputClass = "";
            String inputName = "";
            String inputDisplayText = "";
            String inputOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                inputType = inputAtrrs[1];
                inputClass = inputAtrrs[2];
                inputName = inputAtrrs[3];
                inputDisplayText = inputAtrrs[4];
                inputOnClick = inputAtrrs[5];
            } catch (Exception ex) {

            }

            if (inputClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                inputClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }

            //try to find by 'name'
            List<WebElement> objElements = null;
            try {
                objElements = driver.findElements(By.name(inputName));
                locator.setType(Types.LocatorType.name.name());
                locator.setValue(inputName);
            } catch (Exception ex) {
            }
            try {
                if (objElements.isEmpty()) {

                    if (bUseCSSSelector) {
                        //by CSSselector
                        objElements = driver.findElements(By.cssSelector(inputClass));
                        locator.setType(Types.LocatorType.cssSelector.name());
                        locator.setValue(inputClass);
                    } else {
                        //by class name
                        objElements = driver.findElements(By.className(inputClass));
                        locator.setType(Types.LocatorType.className.name());
                        locator.setValue(inputClass);
                    }
                }
            } catch (Exception ex) {
                //to debug - remove later
                ex.printStackTrace();
            }
            try {
                if (objElements.isEmpty()) {
                    //by xpath name
                    String label = inputDisplayText;
                    objElements = driver.findElements(By.xpath("//input[contains(.,'" + label + "')]"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//input[contains(.,'" + label + "')]");
                }
            } catch (Exception ex) {
            }

            objElement = null;

            //
//do the same for inputs
            if (objElements.isEmpty()) {
                List<WebElement> inputs = driver.findElements(By.tagName("input"));
                System.out.println("Scanning valid input-element among : " + inputs.size() + " inputs");
                Properties p = new Properties();
                for (WebElement input : inputs) {
                    if (inputDisplayText.isEmpty() || inputDisplayText.length() <= 0) {
                        inputDisplayText = input.getAttribute("value");
                    }
                    if (inputDisplayText.isEmpty() || inputDisplayText.length() <= 0) {
                        inputDisplayText = input.getAttribute("title");
                    }
                    //print the links texts and links
                    String inputID = "";
                    if (input.isDisplayed() && (ExpectedConditions.elementToBeClickable(input) != null)) {
                        if (input.getAttribute("id").isEmpty() || input.getAttribute("id").equals("")) {
                            //create input id with type, class and onclick
                            //id will be of format 'spinputid_$_type_$_class_$_name_$_displaytext_$_onclick'
                            inputID = "spinputid" + "_$_";
                            try {
                                inputID += input.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            try {
                                inputID += input.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            try {
                                inputID += input.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            try {
                                inputID += inputDisplayText + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }

                        }
                        if (inputID.equalsIgnoreCase(clickAction)) {
                            objElements.add(input);
                            locator = getXpathUsingAttributesForElement(input, locator, driver);
                            break;
                        }
                    }

                }
            }

            if (objElements.isEmpty()) {
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }

            if (objElements.size() == 1) {
                objElement = objElements.get(0);
            } else if (objElements.size() > 1) {
                objElement = objElements.get(0); //temp code
                //
                for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                    //ask use which one to select
                    //t odo
                }
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

//            if (width <= 0 && height <= 0) {
//                //something is wrong with controls
//                return -1;
//            }
            Actions act = new Actions(driver);
            if(performWebAction){
                if (objElement.isEnabled()) {

                    //objElement.click();
                    String strElementype = objElement.getAttribute("type");
                    if (strElementype != null) {
                        try {
                            objElement.click();
                            locator.setActionMethod(Types.ActionMethod.defaultt.name());
                        } catch (Exception ex) {
                            try{
                                ((JavascriptExecutor) driver).executeScript("arguments[0].click();",objElement);
                                locator.setActionMethod(Types.ActionMethod.javascriptexecutor.name());
                            }catch(Exception ex1){
                                act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                                locator.setActionMethod(Types.ActionMethod.actions.name());
                            }

                        }

                    } else {

                        //Add a logic to handle the user xpath flow
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                    }

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                        //return 2;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                            //return 3;
                        } else {
                            locator.setiRetVal(1);
                            return locator;
                            //return 1;
                        }
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }
            locator.setiRetVal(0);
            return locator;
            //return 0;

        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        } catch (Exception e) {
            locator.setiRetVal(-1);
            return locator;
            //return -1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }

    }

    private Locator ExecuteImageClick(PageObject pageObject, WebDriver driver) {
        System.out.println("ExecuteImageClick");
        String imageHref = pageObject.imageHref;
        String title = pageObject.objectElement.getAttribute("title");
        String imageSrc = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + imageHref);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteImageClick");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            if (StringUtils.isEmpty(imageHref) && StringUtils.isEmpty(imageSrc)) {
                System.out.println("Invalid/Null control ID.");
                //return -1;
                locator.setiRetVal(-1);
                return locator;
            }

            String imageHrefCurrent = "";
            String imageSrcCurrent = "";

            //find in all images
            List<WebElement> images = driver.findElements(By.tagName("img"));
            for (WebElement image : images) {
                try {
                    if (image.isDisplayed() && (ExpectedConditions.elementToBeClickable(image) != null)) {
                        /**Commented below line for "payment" image click fix for nflshop.com site*/
//                        WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", image);
                        try {
                            imageHrefCurrent = image.getAttribute("href");
                            imageSrcCurrent = image.getAttribute("src");
                        } catch (Exception e) { }
                        /**Image src */
                        if(!StringUtils.isEmpty(imageSrc)
                                && !StringUtils.isEmpty(imageSrcCurrent)
                                && imageSrc.toLowerCase().equalsIgnoreCase(imageSrcCurrent.toLowerCase())) {
                            objElement = image;
                            break;
                        }
                        /**Image href */
                        if(!StringUtils.isEmpty(imageHref)
                                && !StringUtils.isEmpty(imageHrefCurrent)
                                && imageHref.toLowerCase().equalsIgnoreCase(imageHrefCurrent.toLowerCase())) {
                            objElement = image;
                            break;
                        }
                    }
                } catch (Exception ex) {
                    System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
                }
            }

            //find in all anchors
            if (objElement == null) {
                List<WebElement> allLinks = driver.findElements(By.tagName("a"));
                for (WebElement link : allLinks) {
                    {
                        imageHrefCurrent = link.getAttribute("href");
                        if(!StringUtils.isEmpty(imageHrefCurrent)){
                            if (link.isDisplayed() && (ExpectedConditions.elementToBeClickable(link) != null)) {
                                if (imageHref.toLowerCase().equalsIgnoreCase(imageHrefCurrent.toLowerCase())) {
                                    objElement = link;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            if (objElement != null) {
                if(!StringUtils.isEmpty(objElement.getAttribute("alt"))) {
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//img[@alt='"+objElement.getAttribute("alt")+"']");
                } else if(!StringUtils.isEmpty(objElement.getAttribute("title"))) {
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//img[@title='"+objElement.getAttribute("title")+"']");
                } else if(!StringUtils.isEmpty(objElement.getAttribute("src"))) {
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//img[@src='"+objElement.getAttribute("src")+"']");
                }
            }
            if (objElement == null) {
                try {
                    objElement = driver.findElement(By.cssSelector("a[title=\"" + title + "\"]"));
                    locator.setType(Types.LocatorType.cssSelector.name());
                    locator.setValue("a[title=\"" + title + "\"]");
                } catch (Exception ex) {
                    System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
                }
            }

            if (objElement == null) {
                try {
                    objElement = driver.findElement(By.cssSelector("img[src='" + imageSrc + "']"));
                    locator.setType(Types.LocatorType.cssSelector.name());
                    locator.setValue("img[src='" + imageSrc + "']");
                } catch (Exception ex) {
                    System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
                }
                if (objElement == null) {
                    try {
                        objElement = driver.findElement(By.xpath("//img[@src='" + imageSrc + "']"));
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue("//img[@src='" + imageSrc + "']");
                    } catch (Exception ex) {
                        System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
                    }

                }

            }
            if (objElement == null) {
                //need to review
                System.out.println("Invalid/Null control ID.");
                //return -1;
                locator.setiRetVal(-1);
                return locator;
            }

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            if (width <= 0 && height <= 0) {
                //something is wrong with controls
                //return -1;
                locator.setiRetVal(-1);
                return locator;
            }

            Actions act = new Actions(driver);
            if(performWebAction){
                if (objElement.isEnabled()) {

                    try {
                        act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                    } catch (Exception ex) {
                        try {
                            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", objElement);
                            locator.setActionMethod(Types.ActionMethod.javascriptexecutor.name());
                        }catch (Exception ex1){
                         objElement.click();
                        }
                    }

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        //return 2;
                        locator.setiRetVal(2);
                        return locator;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            //return 3;
                            locator.setiRetVal(3);
                            return locator;
                        } else {
                            //return 1;
                            locator.setiRetVal(1);
                            return locator;
                        }
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }
            locator.setiRetVal(0);
            return locator;

        } catch (Exception e) {
            e.printStackTrace();
            //return -1;
            locator.setiRetVal(-1);
            return locator;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }
    }

    private Locator ExecuteWithDirectLinkFind(String testAction, String testData, PageObject objPOSelected, WebDriver driver, Step step) throws LocatorNotFoundException {
        System.out.println("ExecuteWithDirectLinkFind");
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName());
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteWithDirectLinkFind");

        try {

            try {

                //take action
                //String testAction = ObjectActions.Action;
                if (Constants.AppActionVerbs.contains(testAction.toLowerCase())) {

                    String clickedControlID = "";

                    //now check if it's mouse click or entering some user data in input field
                    if (testData.isEmpty() || testData.length() <= 0) {
                        //testdata is empty means it's possible click event
                        //send click event

                        if (objPOSelected.ObjectId.isEmpty()) {
                            //need to search webelement by visible text
                            //for future use store its Id by retrieving it.
                            locator = ExecuteClickByLink(objPOSelected.VisisbleText, true, driver);
                            objPOSelected.ObjectId = strTempPOObjectID;
                        } else {

                            if (objPOSelected.ObjectId.toLowerCase().startsWith("sphrefid")) {
                                //deriExecuteHrefClickWithoutIDve href or rel from this
                                locator = ExecuteHrefClickWithoutID(objPOSelected,step,
                                        FindAllAttributes(objPOSelected, driver), true, driver);
                            } else {
                                locator = ExecuteClickByLink(objPOSelected.VisisbleText, true, driver);
                            }
                        }

                        //return iRetVal;
                        return locator;

                    }else if (testAction.toLowerCase().contains("select")) {
                        //testdata is not empty assuming it is a select dropdown
                        System.out.println(driver.findElement(By.id(objPOSelected.ObjectId)).isDisplayed());
                        Select select = new Select(driver.findElement(By.id(objPOSelected.ObjectId)));
                        select.selectByVisibleText(testData);
                    }
                }

            } catch(LocatorNotFoundException lne){
                throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
            } catch (Exception e) {
                e.printStackTrace();
            }

            //return 0;
            locator.setiRetVal(0);
            return locator;
        } catch (Exception e) {
            //return 0;
            locator.setiRetVal(0);
            return locator;
        }
    }

    private boolean CheckIfGivenbjectIsEditable(String ObjectID, boolean bIsIFrameControl, String iFrameId, WebElement objPO, String testData, WebDriver driver) {


        System.out.println("Executing : " + Thread.currentThread().getStackTrace()[1].getMethodName() + " - ID -" + ObjectID);
        try {

            if (bIsIFrameControl) {
            }

            WebElement fieldName = null;
            try {
                fieldName = driver.findElement(By.id(ObjectID)); //this will fail if given object does not have any ID
                //so handle accordinlgy
            } catch (Exception ex2) {
                //do nothing.
                System.out.println("Executing Ex2 exception :    -" + ex2.getMessage());
                fieldName = objPO;
            }
            if (fieldName == null) {
                fieldName = objPO;
            }
            //check if this is enabled combo-box or option button
            if (fieldName.getTagName().equalsIgnoreCase("select")) {
                if (fieldName.isEnabled()) {
                    //driver.switchTo().defaultContent();
                    return true;
                }
            }
            System.out.println("Searching for element");

            String fieldNameVal = fieldName.getAttribute("value");
            if (fieldNameVal!=null && fieldNameVal.length() > 0) {

                System.out.println("This input field already has data =" + fieldName.getAttribute("id") + " => " + fieldNameVal);
                //this already has some data, may be default or entereed by Smartprobe
                //in case of checkBox or option buttin this value will be 'on' or 'off'
                //and both thses controls are of ype 'input'
                //not sure how to check this.
                //one of the crude way is to store all 'test-data' used till now and check against its value.
                if (fieldNameVal.equalsIgnoreCase("on")
                        || fieldNameVal.equalsIgnoreCase("off")) {

                    //possible checkbox or radiobutton/option button
                    //JUST CHECK if given webelement is enabled and/or clickable
                    if (fieldName.isDisplayed() && (ExpectedConditions.elementToBeClickable(fieldName) != null)) {
                        //driver.switchTo().defaultContent();
                        return true;
                    } //crude way
                    else if (listTestDataUsedTillNow.contains(fieldNameVal)) {
                        return true;
                    } else {

                        return false;
                    }

                } else {
                    return true;
                }
            }

            String wordKeys = "";
            char[] array = "".toCharArray();

            //when test data is passed, directly validate against the same
            if (bCheckEditableControlWithTestData.equals("1") && objPO.getTagName().equalsIgnoreCase("input")|| objPO.getTagName().equalsIgnoreCase("textarea") || objPO.getTagName().equalsIgnoreCase("select")||objPO.getTagName().equalsIgnoreCase("radio") || objPO.getTagName().equalsIgnoreCase("checkbox") || objPO.getTagName().equalsIgnoreCase("label") || objPO.getTagName().equalsIgnoreCase("div")) {
                if (testData != null && !testData.isEmpty()) {
                    System.out.println("Validating with test data for => " + fieldName.getAttribute("id") + " with Data -" + testData);

                    //check if it accepts formatted data only.
                    //i.e. send testdata
                    wordKeys = testData;
                    array = wordKeys.toCharArray();
                    for (char ch : array) {
                        try {
                            fieldName.sendKeys(Character.toString(ch));
                        } catch (Exception localex) {
                            //if element is not interactable
                            System.out.println("inside catch3");

                            System.out.println(localex.getMessage());
                            try {
                                fieldName.click();
                                fieldName.sendKeys(wordKeys);
                            } catch (Exception localex2) {
                                //ignore and try inserting code directly
                                System.out.println("inside catch4");

                                System.out.println("Forceful return true");
                                return false;
                            }
                        }
                    }

                    Thread.sleep(actionDelay);
                    fieldNameVal = fieldName.getAttribute("value");
                    System.out.println("contents of input field = " + fieldNameVal);
                    System.out.println("comparing => " + wordKeys + " with " + fieldNameVal);

                    if (fieldNameVal.equalsIgnoreCase(wordKeys) || fieldNameVal.contentEquals(wordKeys)) {

                        fieldName.clear();
                        if(!fieldName.getAttribute("value").equalsIgnoreCase(""))
                            fieldName.sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
                        Thread.sleep(actionDelay);
                        //driver.switchTo().defaultContent();
                        System.out.println("input is editable -returing true");

                        return true;
                    }

                    fieldNameVal = fieldName.getAttribute("value");
                    if (fieldNameVal.length() > 0) {
                        fieldName.clear();
                    }

                    //driver.switchTo().defaultContent();
                    return false;
                }
            }

            //below code is to handle when test data is not passed to this function
            System.out.println("validating with smartprobe data");

            wordKeys = "";
            array = wordKeys.toCharArray();
            // if(fieldName.getTagName().equalsIgnoreCase("input") || fieldName.getTagName().equalsIgnoreCase("textarea") || fieldName.getTagName().equalsIgnoreCase("select")||fieldName.getTagName().equalsIgnoreCase("radio") || fieldName.getTagName().equalsIgnoreCase("checkbox"))

            for (char ch : array) {
                try {
                    fieldName.sendKeys(Character.toString(ch));
                } catch (Exception localex5) {
                    System.out.println("inside catch5");

                    System.out.println("Forceful return true");
                    return true;
                }
            }
            Thread.sleep(actionDelay);
            fieldNameVal = fieldName.getAttribute("value");

            System.out.println("contents of input field step 2 = " + fieldNameVal);
            System.out.println("comparing step 2 => " + wordKeys + " with " + fieldNameVal);

            //case :1 - This is valid if input is allowed  for characters and numbers
            if (fieldNameVal.equalsIgnoreCase("dt") || fieldNameVal.contentEquals("dt")) {
//                fieldName.sendKeys("");
                fieldName.clear();
                if(!fieldName.getAttribute("value").equalsIgnoreCase(""))
                    fieldName.sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
                Thread.sleep(actionDelay);
                //driver.switchTo().defaultContent();
                System.out.println("input is editable 2 -returing true");

                return true;
            } //case :2 - this is valid if input is allowed for only digits. e.g. credit card number
            else {

                wordKeys = "";
                array = wordKeys.toCharArray();
                for (char ch : array) {
                    try {
                        fieldName.sendKeys(Character.toString(ch));
                    } catch (Exception localex6) {
                        System.out.println("inside catch6");

                        System.out.println("Forceful return true");
                        return true;
                    }
                }
                Thread.sleep(actionDelay);

                fieldNameVal = fieldName.getAttribute("value");
                System.out.println("contents of input field step 3 = " + fieldNameVal);
                System.out.println("comparing step 3 => " + wordKeys + " with " + fieldNameVal);

                if (fieldNameVal.contentEquals("00") || fieldNameVal.startsWith("0")) {

                    fieldName.clear();
                    Thread.sleep(actionDelay);
                    //driver.switchTo().defaultContent();
                    System.out.println("input is editable 3 -returing true");

                    return true;
                }
            }
            return false;
        } catch (Exception ex) {
            //driver.switchTo().defaultContent();
            System.out.println(ex.getMessage());
            return false;
        }

    }

    Locator ExecuteAssertVerify(Step _step, PageObject pageObject, WebDriver driver) {
        System.out.println("ExecuteAssertVerify");
        String action = _step.getAction().name();
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        String data = _step.getTestData();
        String visibleTxt = pageObject.VisisbleText;
        String step = _step.getFieldValue();
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction(action);
        locator.setCreatedByFunction("ExecuteAssertVerify");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);
        Verify verify = new Verify();
//       verify.setAssertCondition("assertEquals");
        verify.setExpectedValue(data);

        try {
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);
            locator.setData(data);
            clickAction = clickAction.replace("\\", "");
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));
            String[] elementAtrrs = pattern.split(clickAction);

            // element doesn't have id attribute hence has sphrefid
            String elementType = "";
            String elementClass = "";
            String elementName = "";
            String elementDisplayText = "";
            String elementOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                if(Arrays.stream(elementAtrrs).count() > 1) {
                    elementType = elementAtrrs[1];
                    elementClass = elementAtrrs[2];
                    elementName = elementAtrrs[3];
                    elementDisplayText = elementAtrrs[4];
                    elementOnClick = elementAtrrs[5];
                }
            } catch (Exception ex) {

            }

            if (elementClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                elementClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }

            List<WebElement> listOfElements = new ArrayList<>();
            if(clickAction !=null && !clickAction.isEmpty()) {
                listOfElements = driver.findElements(By.id(clickAction));
            }
            else{
                listOfElements =driver.findElements(By.linkText(visibleTxt));
            }
            if(!listOfElements.isEmpty()) {
                List<WebElement> listOfFilteredElements = new ArrayList<WebElement>();
                for (WebElement we : listOfElements) {
                    //ideally in this case only one should be visible or applicable
                    //hence currently checking for visible property
                    if (we.isDisplayed() && we.isEnabled()) {
                        listOfFilteredElements.add(we);
                    }
                }
                System.out.println("listOfFilteredElements size = " + listOfFilteredElements.size());
                if (!listOfFilteredElements.isEmpty()) {
                    objElement = listOfFilteredElements.get(0);
                    if(clickAction != null && !clickAction.isEmpty()) {
                        locator.setType(Types.LocatorType.id.name());
                        locator.setValue(clickAction);
                    }
                    else{
                        locator.setType(Types.LocatorType.linkText.name());
                        locator.setValue(visibleTxt);
                    }
                } else {
                    locator.setiRetVal(-1);
                    return locator;
                }
            }
            else {
                locator.setiRetVal(-1);
                return locator;
            }


            if (objElement == null) {
                // Initialize the list of WebElements
                List<WebElement> objElements = new ArrayList<>();

                // Try to find by 'name'
                try {
                    objElements = driver.findElements(By.name(elementName));
                    if (!objElements.isEmpty()) {
                        locator.setType(Types.LocatorType.name.name());
                        locator.setValue(elementName);
                    }
                } catch (Exception ex) {}

                // Try to find by 'CSS selector' or 'class name'
                try {
                    if (objElements.isEmpty()) {
                        if (bUseCSSSelector) {
                            objElements = driver.findElements(By.cssSelector(elementClass));
                            if (!objElements.isEmpty()) {
                                locator.setType(Types.LocatorType.cssSelector.name());
                                locator.setValue(elementClass);
                            }
                        } else {
                            objElements = driver.findElements(By.className(elementClass));
                            if (!objElements.isEmpty()) {
                                locator.setType(Types.LocatorType.className.name());
                                locator.setValue(elementClass);
                            }
                        }
                    }
                } catch (Exception ex) {}

                // Try to find by 'xpath'
                try {
                    if (objElements.isEmpty()) {
                        String xpath = "//input[contains(.,'" + elementDisplayText + "')]";
                        objElements = driver.findElements(By.xpath(xpath));
                        if (!objElements.isEmpty()) {
                            locator.setType(Types.LocatorType.xpath.name());
                            locator.setValue(xpath);
                        }
                    }
                } catch (Exception ex) {

                }

                if (objElements.isEmpty()) {
                    locator.setiRetVal(-1);
                    return locator;
                }

                if (objElements.size() == 1) {
                    objElement = objElements.get(0);
                }
            }

            // assert checking
            Set existanceVerbs = new HashSet<String>(Arrays.asList("exists", "present", "visible","exist"));
            Set equalVerbs = new HashSet<String>(Arrays.asList("equals"));
            String actualValue = objElement.getAttribute("value");
            verify.setActualValue(actualValue);

            if(action.equalsIgnoreCase("assertequals")){
                verify.setAssertCondition("assertEquals");
                Assert.assertEquals(actualValue,data,"The values are not equal");
            }
            else if(action.equalsIgnoreCase("assertnotequals")){
                verify.setAssertCondition("assertNotEquals");
                Assert.assertNotEquals(actualValue,data,"The values are equal");

            }
            else if(action.equalsIgnoreCase("asserttrue")) {
                verify.setAssertCondition("assertTrue");
                if (data.equalsIgnoreCase("isEnabled")) {
                    Assert.assertTrue(objElement.isEnabled());
                }
                else if (data.equalsIgnoreCase("isDisplayed")) {
                    Assert.assertTrue(objElement.isDisplayed());
                }
                else if (data.equalsIgnoreCase("isSelected")) {
                    Assert.assertTrue(objElement.isSelected());
                }
            }
            else if (action.equalsIgnoreCase("assertfalse")){
                verify.setAssertCondition("assertFalse");
                if (data.equalsIgnoreCase("isEnabled")) {
                    Assert.assertFalse(objElement.isEnabled());

                }
                else if (data.equalsIgnoreCase("isDisplayed")) {
                    Assert.assertFalse(objElement.isDisplayed());
                }
                else if (data.equalsIgnoreCase("isSelected")) {
                    Assert.assertFalse(objElement.isSelected());
                }

            }
            locator.setVerify(verify);
            locator.setiRetVal(1);
            return locator;
        }
        catch (AssertionError ex) {
            ex.printStackTrace();
            locator.setiRetVal(0);
            return locator;

        } catch (Exception e){
            e.printStackTrace();
            locator.setiRetVal(-1);

            return locator;
        }
        finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
            //locator.setiRetVal(0);
            //return locator;
        }
    }

    private Locator ExecuteMouseHover(Step step, PageObject pageObject, WebDriver driver) {
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        String visibleTxt = pageObject.VisisbleText;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction + "(bIsIFrameControl = " + bIsIFrameControl + " and frameID = " + iFrameId);

        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("mouseHover");
        locator.setCreatedByFunction("ExecuteMouseHover");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);
        Actions act = new Actions(driver);
        try {
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            clickAction = clickAction.replace("\\", "");

            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] elementAtrrs = pattern.split(clickAction);
            String elementType = "";
            String elementClass = "";
            String elementName = "";
            String elementDisplayText = "";
            String elementOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                elementType = elementAtrrs[1];
                elementClass = elementAtrrs[2];
                elementName = elementAtrrs[3];
                elementDisplayText = elementAtrrs[4];
                elementOnClick = elementAtrrs[5];
            } catch (Exception ex) {

            }

            if (elementClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                elementClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }
            List<WebElement> listOfElements = driver.findElements(By.linkText(visibleTxt));
            if (listOfElements.isEmpty()){
                listOfElements = driver.findElements(By.id(clickAction));
                List<WebElement> listOfFilteredElements = new ArrayList<WebElement>();
                for (WebElement we : listOfElements) {
                    //ideally in this case only one should be visibel or applicable
                    //hence currently checking for visible property
                    if (we.isDisplayed() && we.isEnabled()) {
                        listOfFilteredElements.add(we);
                    }
                }
                if (listOfFilteredElements.size() == 1) {
                    objElement = listOfFilteredElements.get(0);
                    locator.setType(Types.LocatorType.id.name());
                    locator.setValue(clickAction);
                }
            } else{
                objElement=listOfElements.get(0);
                locator.setType(Types.LocatorType.linkText.name());
                locator.setValue(visibleTxt);
            }
            if(objElement==null)
            {
                //try to find by 'name'
                List<WebElement> objElements = null;
                try {
                    if (objElements==null) {
                        objElements = driver.findElements(By.name(elementName));
                        locator.setType(Types.LocatorType.name.name());
                        locator.setValue(elementName);
                    }
                } catch (Exception ex) {
                }
                try {
                    if (objElements.isEmpty()) {

                        if (bUseCSSSelector) {
                            //by CSSselector
                            objElements = driver.findElements(By.cssSelector(elementClass));
                            locator.setType(Types.LocatorType.cssSelector.name());
                            locator.setValue(elementClass);
                        } else {
                            //by class name
                            objElements = driver.findElements(By.className(elementClass));
                            locator.setType(Types.LocatorType.className.name());
                            locator.setValue(elementClass);
                        }
                    }
                } catch (Exception ex) {
                    //to debug - remove later
                    // ex.printStackTrace();
                }
                try {
                    if (objElements.isEmpty()) {
                        //by xpath name
//                   if(elementDisplayText.isEmpty())
//                       objElements = driver.findElements(By.xpath("//input[contains(.,'" + visibleTxt + "')]"));
//                   else
                        objElements = driver.findElements(By.xpath("//input[contains(.,'" + elementDisplayText + "')]"));
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue("//input[contains(.,'" + elementDisplayText + "')]");
                    }
                } catch (Exception ex) {
                }

                if (objElements.isEmpty()) {
                    //return -1;
                    locator.setiRetVal(-1);
                    return locator;
                }

                if (objElements.size() == 1) {
                    objElement = objElements.get(0);
                } else if (objElements.size() > 1) {
                    objElement = objElements.get(0); //temp code
                    //
                    for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                        //ask use which one to select
                        //t odo
                    }
                }
            }

            if(performWebAction){
                act.moveToElement(objElement).perform();
            }

            // CheckIfPopup windows is launched
            boolean bPopUpWindowAppeared = false;
            String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
            String subWindowHandler = null;

            Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
            Iterator<String> iterator = handles.iterator();
            while (iterator.hasNext()) {
                subWindowHandler = iterator.next();
            }

            if (subWindowHandler != null) {
                driver.switchTo().window(subWindowHandler); // switch to popup window
                bPopUpWindowAppeared = true;
            }

            // Now you are in the popup window, perform necessary actions here
            //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
            if (bPopUpWindowAppeared) {
                //return 3;
                locator.setiRetVal(3);
                return locator;
            } else {
                //return 1;
                locator.setiRetVal(1);
                return locator;
            }

        } catch (Exception e) {
            //return -1;
            locator.setiRetVal(-1);
            return locator;

        }
    }

    private void PerformWebElementDoubleClick(WebElement element, WebDriver driver) {
        System.out.println("PerformWebElementDoubleClick");
        int width = 0;
        int height = 0;
        Actions act = new Actions(driver);

        try {
            try {

                width = element.getSize().getWidth();
                height = element.getSize().getHeight();

                if (width <= 0) {
                    width = 1;
                }
                if (height <= 0) {
                    height = 1;
                }
                //something is wrong with controls
                //return -1;

            } catch (Exception ex) {
                System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
            }

            try {
                ((JavascriptExecutor) driver).executeScript(
                        "arguments[0].doubleClick();",
                        element);
            } catch (Exception ex) {
                try {
                    act.moveToElement(element).moveByOffset((width / 2) - 2, 0).doubleClick(element).build().perform();
                } catch (Exception ex1) {
                    try {
                        act.doubleClick(element).build().perform();
                    } catch (Exception ex2) {
                        // in worst case
                        //if this element is/has href
                        //thn getPageElements href property and navigate to that url.
                        String str1 = element.getAttribute("href");
                        if (str1 != null && !str1.isEmpty()) {
                            driver.manage().deleteAllCookies();
                            driver.navigate().to(str1);
                        }
                    }
                }
            }

        } catch (Exception ex) {
            act.doubleClick(element).build().perform();
        }
    }

    private Locator ExecuteDoubleClick(PageObject pageObject, WebDriver driver) {
        System.out.println("ExecuteDoubleClick");
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction + "(bIsIFrameControl = " + bIsIFrameControl + " and frameID = " + iFrameId);

        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("doubleClick");
        locator.setCreatedByFunction("ExecuteDoubleClick");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            clickAction = clickAction.replace("\\", "");

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            //try to find if there are multiple elements with same ID
            List<WebElement> listOfElements = driver.findElements(By.id(clickAction));
            List<WebElement> listOfFilteredElements = new ArrayList<>();
            for (WebElement we : listOfElements) {
                //ideally in this case only one should be visibel or applicable
                //hence currently checking for visible property
                //commenting this if condition as it allow only visible elements
                //if (we.isDisplayed() && we.isEnabled()) {
                if (we.isEnabled()) {
                    listOfFilteredElements.add(we);
                }
            }
            if (listOfFilteredElements.size() == 1) {
                objElement = listOfFilteredElements.get(0);
            } else if (listOfFilteredElements.size() > 1) {
                //then what  -lets decide later
                //currently return first one only
                objElement = listOfFilteredElements.get(0);
            } else {
                //ask user
                //something is wrong
            }
//            By elementLocation = By.id(clickAction);

//            objElement = driver.findElement(elementLocation);
            if (objElement.isEnabled()) {
                String strElementype = objElement.getAttribute("type");
                //returns element if condition will be true means it returns element
                //if element appears on the page and clickable
                try {
                    objElement = wait.until(ExpectedConditions.elementToBeClickable(objElement));
                    locator.setType(Types.LocatorType.id.name());
                    locator.setValue(clickAction);
                } catch (Exception ex) {
                    //.reset element
                    By elementLocation = By.id(clickAction);
                    objElement = driver.findElement(elementLocation);
                    locator.setType(Types.LocatorType.id.name());
                    locator.setValue(clickAction);
                }

                //sometime we getPageElements controls which are invisisble so remove those in previous control-optimization steps as well.
                //need to review
                if (objElement != null && performWebAction) {
                    PerformWebElementDoubleClick(objElement, driver);
                }
                Thread.sleep(actionDelay);

                //do not add clickable controls , as those can be repeated.
                if (bIsIFrameControl) {
                    //driver.switchTo().defaultContent();
                }

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    //return 2;
                    locator.setiRetVal(2);
                    return locator;
                } else {

                    // CheckIfPopup windows is launched
                    boolean bPopUpWindowAppeared = false;
                    String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                    String subWindowHandler = null;

                    Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                    Iterator<String> iterator = handles.iterator();
                    while (iterator.hasNext()) {
                        subWindowHandler = iterator.next();
                    }

                    if (subWindowHandler != null) {
                        driver.switchTo().window(subWindowHandler); // switch to popup window
                        bPopUpWindowAppeared = true;
                    }

                    // Now you are in the popup window, perform necessary actions here
                    //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                    if (bPopUpWindowAppeared) {
                        //return 3;
                        locator.setiRetVal(3);
                        return locator;
                    } else {
                        //return 1;
                        locator.setiRetVal(1);
                        return locator;
                    }
                }

            }
            //return 0;
            locator.setiRetVal(0);
            return locator;

        } catch (Exception e) {
            //return -1;
            locator.setiRetVal(-1);
            return locator;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }

    }

    private Locator ExecuteRightClick(PageObject pageObject, WebDriver driver) {
        System.out.println("ExecuteRightClick");
        String ObjectId = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + ObjectId + "(bIsIFrameControl = " + bIsIFrameControl + " and frameID = " + iFrameId);

        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("rightClick");
        locator.setCreatedByFunction("ExecuteRightClick");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            // clickAction = clickAction.replace("\\", "");

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);


            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            //try to find if there are multiple elements with same ID
            List<WebElement> listOfElements = driver.findElements(By.id(ObjectId));
            List<WebElement> listOfFilteredElements = new ArrayList<>();
            for (WebElement we : listOfElements) {
                //ideally in this case only one should be visibel or applicable
                //hence currently checking for visible property
                if (we.isDisplayed() && we.isEnabled()) {
                    listOfFilteredElements.add(we);
                }
            }
            if (listOfFilteredElements.size() == 1) {
                objElement = listOfFilteredElements.get(0);
            } else if (listOfFilteredElements.size() > 1) {
                //then what  -lets decide later
                //currently return first one only
                objElement = listOfFilteredElements.get(0);
            } else {
                //ask user
                //something is wrong
            }
//            By elementLocation = By.id(clickAction);

//            objElement = driver.findElement(elementLocation);
            if (objElement.isEnabled()) {

                String strElementype = objElement.getAttribute("type");
                //returns element if condition will be true means it returns element
                //if element appears on the page and clickable
                try {
                    objElement = wait.until(ExpectedConditions.elementToBeClickable(objElement));
                } catch (Exception ex) {
                    //.reset element
                    By elementLocation = By.id(ObjectId);
                    objElement = driver.findElement(elementLocation);
                }

                //sometime we getPageElements controls which are invisisble so remove those in previous control-optimization steps as well.
                //need to review
                if (objElement != null && performWebAction) {
                    Actions action = new Actions(driver);
                    action.contextClick(objElement).build().perform();

                    locator.setType(Types.LocatorType.id.name());
                    locator.setValue(ObjectId);
                    locator.setActionMethod(Types.ActionMethod.defaultt.name());
                }
                Thread.sleep(actionDelay);

                //do not add clickable controls , as those can be repeated.
                if (bIsIFrameControl) {
                    //driver.switchTo().defaultContent();
                }

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    locator.setiRetVal(2);
                    return locator;
                    //return 2;
                } else {
                    //context menu screen appeared. programatically unable to detect popup/context menu screen so direclty returning 3
                    locator.setiRetVal(3);
                    return locator;
                    //return 3;
                }

            }
            locator.setiRetVal(0);
            return locator;
            //return 0;

        } catch (Exception e) {
            locator.setiRetVal(-1);
            return locator;
            //return -1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }

    }

    private Locator ExecuteClickWithXpath(PageObject pageObject, WebDriver driver) {
        System.out.println("ExecuteClickWithXpath");
        String strXPath = pageObject.xPath;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        WebElement objElement = null;
        String visibleText = "";
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteClickWithXpath");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            By elementLocation = By.xpath(strXPath);

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

//            try {
//                List<WebElement> iframeElements = driver.findElements(By.tagName("iframe"));
//                if(iframeElements.size()>0)
//                {
//                    for(int i=0; i<=iframeElements.size(); i++){
//                        try{
//                            //driver.switchTo().frame(iframeElements.get(i));
//
//                            objElement = driver.findElement(By.xpath(strXPath));
//                            if(objElement!=null)
//                                locator.setType(Types.LocatorType.xpath.name());
//                            locator.setValue(strXPath);
//                            break;
//                        } catch (Exception ex) {
//
//                        }
//                        // System.out.println(total);
//                        //driver.switchTo().defaultContent();}
//                }
//                if(objElement==null)
//                    objElement = driver.findElement(By.xpath(strXPath));
//                locator.setType(Types.LocatorType.xpath.name());
//                locator.setValue(strXPath);
//
//                ////driver.switchTo().frame("pop-frame05049304025235446");
//                //objWebElement = driver.findElement(By.xpath());
//            }
//            catch (Exception ex) {
//                ex.printStackTrace();
//            }
            try {
                if (bIsIFrameControl) {
                    //System.out.println("Frame is present and iframeID="+iFrameId);
//                    if (iFrameId.equalsIgnoreCase("gsft_main")){
//                        //driver.switchTo().frame(iFrameId);
//                        List<WebElement> iframeElemens = driver.findElements(By.tagName("iframe"));
//                        for (int i = 0; i <iframeElemens.size() ; i++) {
//                            //System.out.println(iframeElemens.get(i).getAttribute("id"));
//                            if(iframeElemens.get(i).getAttribute("id").equalsIgnoreCase("approvalLoginFrame")){
//                                //driver.switchTo().frame(driver.findElement(By.xpath("//*[@id='approvalLoginFrame']")));
//                                break;
//                            }
//                        }
//                    }
//                    else{
                    //driver.switchTo().defaultContent();
                    //driver.switchTo().frame(iFrameId);
//                    }
                }
                objElement = driver.findElement(By.xpath(strXPath));
                if(objElement!=null)
                    locator.setType(Types.LocatorType.xpath.name());
                locator.setValue(strXPath);

                if(objElement==null)
                    objElement = driver.findElement(By.xpath(strXPath));
                locator.setType(Types.LocatorType.xpath.name());
                locator.setValue(strXPath);

            } catch (Exception ex) {
                ex.printStackTrace();
            }

            if (objElement == null) {
                //either this is wrong xpath or god can only save selenium
                //return -1;
                locator.setiRetVal(-1);
                return locator;
            }

            if(performWebAction){
                if (objElement.isEnabled()) {

                    try {
                        objElement = wait.until(ExpectedConditions.elementToBeClickable(objElement));
                    } catch (Exception ex) {
                        //.reset element
                        objElement = driver.findElement(elementLocation);
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue(strXPath);
                    }

                    if (objElement != null) {
                        try {
                            objElement.click();
                        } catch (Exception e) {
                            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true); arguments[0].click();",objElement);
                            locator.setActionMethod(Types.ActionMethod.javascriptexecutor.name());
                        }
                        //   visibleText = PerformWebElementClick(objElement);
                    }
                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }
                    String NextURL;
                    String NextTitle;
                    if(ExpectedConditions.alertIsPresent()!=null)
                    {
                        //return 1;
                        locator.setiRetVal(1);
                        return locator;
                    }
                    else
                    {
                        NextURL = driver.getCurrentUrl();
                        NextTitle = driver.getTitle();
                    }

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        //return 2;
                        locator.setiRetVal(2);
                        return locator;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            //return 3;
                            locator.setiRetVal(3);
                            return locator;
                        } else {
                            //return 1;
                            locator.setiRetVal(1);
                            return locator;
                        }
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }

            //return 0;
            locator.setiRetVal(0);
            return locator;

        } catch (Exception e) {
            e.printStackTrace();
            //return -1;
            locator.setiRetVal(-1);
            return locator;

        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }
    }

    private String PerformWebElementClick(WebElement element, WebDriver driver) {
        System.out.println("PerformWebElementClick");
        System.out.println("PerformWebElementClick--->"+element);
        System.out.println("Size--->");
        String visisbleText = "";
        int width = 0;
        int height = 0;
        if (element == null) {
            System.out.println("Null element in Method : " + Thread.currentThread().getStackTrace()[1].getMethodName());
            return "";
        }
        try {
            try {
                visisbleText = SeleniumPageScanner.getVisisbleTextOfWebElement(element);
                width = element.getSize().getWidth();
                height = element.getSize().getHeight();

                if (width <= 0) {
                    width = 1;
                }
                if (height <= 0) {
                    height = 1;
                }
                //something is wrong with controls
                //return -1;

            } catch (Exception ex) {
                System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
            }

            try {
                System.out.println(element);
                ((JavascriptExecutor) driver).executeScript(
                        "arguments[0].click();",
                        element);

            } catch (Exception ex) {
                try {
                    Actions act = new Actions(driver);
                    act.moveToElement(element).moveByOffset((width / 2) - 2, 0).click().perform();
                } catch (Exception ex1) {
                    try {
                        element.click();
                    } catch (Exception ex2) {
                        /*System.out.println("Third Try is failed, moved to catch & trying to click with href");
                        // in worst case
                        //if this element is/has href
                        //thn getPageElements href property and navigate to that url.
                        String str1 = element.getAttribute("href");
                        if (str1 != null && !str1.isEmpty()) {
                            driver.manage().deleteAllCookies();
                            driver.navigate().to(str1);
                        }*/
                        try {
                            // in worst case
                            // if this element is/has href
                            // then get href property and navigate to that URL.
                            String str1 = element.getAttribute("href");
                            if (str1 != null && !str1.isEmpty()) {
                                driver.manage().deleteAllCookies();
                                driver.navigate().to(str1);
                            }
                        } catch (Exception ex3) {
                            // If the element is not clickable, keep scrolling down until it is visible and then click
                            while (!element.isDisplayed()) {
                                ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 200);");
                                Thread.sleep(2000);
                            }
                            element.click();
                        }
                    }
                }
            }

        } catch (Exception ex) {
            element.click();
        }
        return visisbleText;
    }

    private Locator ExecuteClick(Step step, String clickAction, boolean bIsIFrameControl, String iFrameId,
                                boolean bIsChildWindowControl, String childWindowTitle, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction + "(bIsIFrameControl = " + bIsIFrameControl + " and frameID = " + iFrameId+")");
        System.out.println("fieldValue= "+step.getFieldValue()+" testData= "+step.getTestData() + " action= "+step.getAction());
        System.out.println("ExecuteClick");
        WebElement objElement = null;
        String visibleText = "";
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteClick");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            clickAction = clickAction.replace("\\", "");

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            //try to find if there are multiple elements with same ID
            List<WebElement> listOfElements = driver.findElements(By.id(clickAction));
            System.out.println("List of elements found with id: " + clickAction + " is: " + listOfElements.size());

            List<WebElement> listOfFilteredElements = new ArrayList<WebElement>();
            for (WebElement we : listOfElements) {
                //ideally in this case only one should be visible or applicable
                //hence currently checking for visible property
                if (we.isDisplayed() && we.isEnabled()) {
                    listOfFilteredElements.add(we);
                }
            }

            if (listOfFilteredElements.size() == 1) {
                objElement = listOfFilteredElements.get(0);
            }else if (listOfFilteredElements.size() > 1) {
                //if more than one element found with same id then lets decide later
                //currently return first one only
                System.out.println("More than one element found with id: " + clickAction + ". Returning the first one.");
                objElement = listOfFilteredElements.get(0);
            } else {
                //then what  - lets decide later
                //currently return first one only
                objElement = listOfFilteredElements.get(0);
            }
//            By elementLocation = By.id(clickAction);

//            objElement = driver.findElement(elementLocation);
            if (objElement.isEnabled()) {

                String strElementype = objElement.getAttribute("type");
                //returns element if condition will be true means it returns element
                //if element appears on the page and clickable
                if(strElementype != null && strElementype != ""){
                    if(strElementype.equalsIgnoreCase("radio") || strElementype.equalsIgnoreCase("checkbox") )
                    {
                        Constants.uxStepMap.put(uxStepMapCounter++,clickAction);
                    }
                }

                try {
                    objElement = wait.until(ExpectedConditions.elementToBeClickable(objElement));
                } catch (Exception ex) {
                    //.reset element
                    By elementLocation = By.id(clickAction);
                    objElement = driver.findElement(elementLocation);
                }

                //sometime we getPageElements controls which are invisisble so remove those in previous control-optimization steps as well.
                //need to review
                if (objElement != null) {
                    locator.setType(Types.LocatorType.id.name());
                    locator.setValue(clickAction);
                    locator.setActionMethod(Types.ActionMethod.defaultt.name());
                } else {
                    //need to review
                    //Add a logic to handle the user xpath flow
                    throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                }
                //perform web action in the browser
                if(performWebAction) PerformWebElementClick(objElement, driver);

                Thread.sleep(actionDelay);
                //do not add clickable controls , as those can be repeated.
                if (bIsIFrameControl) {
                    //driver.switchTo().defaultContent();
                }

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    locator.setiRetVal(2);
                    return locator;
                    //return 2;
                } else {

                    // CheckIfPopup windows is launched
                    boolean bPopUpWindowAppeared = false;
                    String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                    String subWindowHandler = null;

                    Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                    Iterator<String> iterator = handles.iterator();
                    while (iterator.hasNext()) {
                        subWindowHandler = iterator.next();
                    }

                    if (subWindowHandler != null) {
                        //driver.switchTo().window(subWindowHandler); // switch to popup window commented by 844640
                        //bPopUpWindowAppeared = true; //commented by 844640
                    }


                    locator.setiRetVal(1);
                    return locator;

                }
            }
            locator.setiRetVal(0);
            return locator;
            //return 0;
        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        } catch (Exception e) {
            try {
                //Add a logic to handle the user xpath flow
            } catch (Exception ex2) {
                ex2.printStackTrace();
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }
            locator.setiRetVal(1);
            return locator;
            //return 1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }

    }

    private Locator ExecuteClickWithTestData(Step step,  WebDriver driver) throws LocatorNotFoundException {
        System.out.println("Executing click : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + "testdata" + step.getTestData()+"and fieldValue= "+step.getFieldValue());
        System.out.println("ExecuteClickWithTestData");
        WebElement objElement = null;
        String visibleText = "";
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteClick");
        String indexedXPath;
        try {
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            String testData = step.getTestData();
            String fieldValue = step.getFieldValue();


            if (testData != null && !testData.isEmpty() && fieldValue != null && !fieldValue.isEmpty()) {
                List<WebElement> textSection = driver.findElements(By.xpath("//*[text()='" + testData + "']"));

                if (textSection.size() == 1) {
                    System.out.println("Found exactly one element with text='" + testData + "'. Proceeding to search for fieldValue='" + fieldValue + "'.");
                    WebElement currentElement = textSection.get(0);
                    boolean elementClicked = false;

                    while (currentElement != null && !elementClicked) {
                        List<WebElement> matchingElements = currentElement.findElements(
                                By.xpath(".//*[contains(normalize-space(text()), '" + fieldValue + "')]")
                        );
                        for (WebElement match : matchingElements) {
                            String matchText = match.getText().trim();
                            System.out.println("🔎 Found element with text: " + matchText);

                            if (matchText.equals(fieldValue) && match.isEnabled() && match.isDisplayed()) {
                                try {
                                    System.out.println("Clicking matching element: " + matchText);
                                    objElement = match;
                                    objElement.click();
                                    System.out.println("Element clicked successfully.");

                                    indexedXPath = "(//*[text()='"+testData+"']//following::*[normalize-space(text())='"+fieldValue+"'])[1]";
                                    System.out.println("Generated XPath for clicked element: " + indexedXPath);
                                    locator.setValue(indexedXPath);
                                    elementClicked = true;
                                    break;
                                } catch (Exception e) {
                                    System.out.println("Unable to click element: " + e.getMessage());
                                }
                            } else {
                                System.out.println("Text doesn't exactly match fieldValue.");
                            }
                        }

                        if (!elementClicked) {
                            try {
                                currentElement = currentElement.findElement(By.xpath(".."));
                            } catch (Exception e) {
                                System.out.println("Reached the root element. No more parent elements to check.");
                                currentElement = null;
                            }
                        }
                    }

                    if (!elementClicked) {
                        System.out.println("No matching element with fieldValue='" + fieldValue + "' found.");
                    }

                } else {
                    System.out.println("Expected 1 element with text='" + testData + "', but found: " + textSection.size());
                }

            } else {
                System.out.println("No testData or fieldValue provided. Using first element with id='" + step.getFieldValue() + "'.");
                objElement = driver.findElement(By.linkText(step.getFieldValue()));
            }


            if (objElement.isEnabled()) {
                String strElementype = objElement.getAttribute("type");
                if (objElement != null) {
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setActionMethod(Types.ActionMethod.defaultt.name());
                } else {
                    throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                }
                //perform web action in the browser
                //if(performWebAction) PerformWebElementClick(objElement, driver);

                Thread.sleep(actionDelay);

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    locator.setiRetVal(2);
                    return locator;
                    //return 2;
                } else {
                    // CheckIfPopup windows is launched
                    boolean bPopUpWindowAppeared = false;
                    String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                    String subWindowHandler = null;

                    Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                    Iterator<String> iterator = handles.iterator();
                    while (iterator.hasNext()) {
                        subWindowHandler = iterator.next();
                    }

                    if (subWindowHandler != null) {
                        //driver.switchTo().window(subWindowHandler); // switch to popup window commented by 844640
                        //bPopUpWindowAppeared = true; //commented by 844640
                    }


                    locator.setiRetVal(1);
                    return locator;

                }
            }
            locator.setiRetVal(0);
            return locator;
            //return 0;
        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        } catch (Exception e) {
            try {
                //Add a logic to handle the user xpath flow
            } catch (Exception ex2) {
                ex2.printStackTrace();
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }
            locator.setiRetVal(1);
            return locator;
            //return 1;
        } finally {
            //this will getPageElements executed two times but its ok
        }

    }


    private Locator SendWordKeysWithXpath(Step step, PageObject pageObject, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("SendWordKeysWithXpath");
        String wordKeys = step.getTestData();
        String strXPath = pageObject.xPath;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + strXPath);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("sendKeys");
        locator.setCreatedByFunction("SendWordKeysWithXpath");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {

            By elementLocation = By.xpath(strXPath);

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {

            }

            objElement = driver.findElement(elementLocation);
            locator.setType(Types.LocatorType.xpath.name());
            locator.setValue(strXPath);
            locator.setData(wordKeys);
            if (objElement == null) {
                //return -1;
                locator.setiRetVal(-1);
                return locator;
            }
            if(performWebAction){
                if (objElement.isEnabled()) {

                    //first clear edit control - specifically if its text box
                    if (objElement.getTagName().equalsIgnoreCase("input")) {
                        //objElement.sendKeys("");
                    }

                    //=============================
                    if (objElement.getTagName().equalsIgnoreCase("select")
                            || objElement.getTagName().equalsIgnoreCase("option")
                            || objElement.getTagName().equalsIgnoreCase("radio")) {
                        System.out.println("scanning combo-box options");
                        locator.setAction(objElement.getTagName().toLowerCase());
                        //select given data using element by element search
                        Select select = new Select(objElement);
                        if (select.isMultiple()) {
                            //Add a logic to handle the user xpath flow
                            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                        }

                        List<WebElement> allOptions = select.getOptions();
                        System.out.println("Found #options : " + allOptions.size());

                        int iCnt = 0;
                        for (iCnt = 0; iCnt < allOptions.size(); iCnt++) {
                            String CurrentOption = allOptions.get(iCnt).getText();

                            if (CurrentOption.contains(wordKeys)) {

                                allOptions.get(iCnt).click();
                                Thread.sleep(1000);
                                break;

                            }
                        }
                        if (iCnt == allOptions.size()) {
                            //means we could not find valid option to select
                            //so its upto God to select it
                            char[] array = wordKeys.toCharArray();
                            for (char ch : array) {
                                objElement.sendKeys(Character.toString(ch));
                            }

                        }
                    } //==================
                    else {

                        objElement.sendKeys(wordKeys);
                    }
                    //store control id
                    mapAlreadyExecutedObjectOnGivenPAge.put(strXPath, wordKeys);
                    //store test-data used
                    listTestDataUsedTillNow.add(wordKeys);

                    System.out.println("*******    Sent-WordKeys() to : " + strXPath + "   = " + wordKeys);

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        //return 2;
                        locator.setiRetVal(2);
                        return locator;
                    } else {
                        try {
                            if (objElement.getTagName().equalsIgnoreCase("select")
                                    || objElement.getTagName().equalsIgnoreCase("option")) {
                                //we may getPageElements some new controls loaded on screen which were not there prev.
                                //return 3;
                                locator.setiRetVal(3);
                                return locator;
                            }
                        } catch (Exception e) {
                            //page stale element reference so it means its changed.

                            //check and verify this is to be returned as 3 or 1
                            //return 3;
                            locator.setiRetVal(3);
                            return locator;
                        }
                        //return 1;
                        locator.setiRetVal(1);
                        return locator;
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }

            //return 0;
            locator.setiRetVal(0);
            return locator;

        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        } catch (Exception e) {
            //return -1;
            locator.setiRetVal(-1);
            return locator;
        } finally {
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }
    }

    private Locator ExecuteWait(Step step, PageObject pageObject, WebDriver driver) {
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        String visibleTxt = pageObject.VisisbleText;
        String ControlType = step.getFieldValue();
        String testData = step.getTestData();
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        WebElement objElement = null;
        Locator locator = new Locator();
        Wait wait = new Wait();
        wait.setType("wait");
        wait.setTimeout(testData);
        locator.setAction("wait");
        locator.setCreatedByFunction("ExecuteWait");
        locator.setWait(wait);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);
        try {
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            clickAction = clickAction.replace("\\", "");

            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] elementAtrrs = pattern.split(clickAction);
            String elementType = "";
            String elementClass = "";
            String elementName = "";
            String elementDisplayText = "";
            String elementOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                elementType = elementAtrrs[1];
                elementClass = elementAtrrs[2];
                elementName = elementAtrrs[3];
                elementDisplayText = elementAtrrs[4];
                elementOnClick = elementAtrrs[5];
            } catch (Exception ex) {

            }

            if (elementClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                elementClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }
            List<WebElement> listOfElements = driver.findElements(By.linkText(visibleTxt));
            if (listOfElements.isEmpty()){
                listOfElements = driver.findElements(By.id(clickAction));
                List<WebElement> listOfFilteredElements = new ArrayList<WebElement>();
                for (WebElement we : listOfElements) {
                    //ideally in this case only one should be visibel or applicable
                    //hence currently checking for visible property
                    if (we.isDisplayed() && we.isEnabled()) {
                        listOfFilteredElements.add(we);
                    }
                }
                if (listOfFilteredElements.size() == 1) {
                    objElement = listOfFilteredElements.get(0);
                    locator.setType(Types.LocatorType.id.name());
                    locator.setValue(clickAction);
                }
            } else{
                objElement=listOfElements.get(0);
                locator.setType(Types.LocatorType.linkText.name());
                locator.setValue(visibleTxt);
            }

            if(objElement==null)
            {
                //try to find by 'name'
                List<WebElement> objElements = null;
                try {
                    if (objElements==null) {
                        objElements = driver.findElements(By.name(elementName));
                        locator.setType(Types.LocatorType.name.name());
                        locator.setValue(elementName);
                    }
                } catch (Exception ex) {
                }
                try {
                    if (objElements.isEmpty()) {

                        if (bUseCSSSelector) {
                            //by CSSselector
                            objElements = driver.findElements(By.cssSelector(elementClass));
                            locator.setType(Types.LocatorType.cssSelector.name());
                            locator.setValue(elementClass);
                        } else {
                            //by class name
                            objElements = driver.findElements(By.className(elementClass));
                            locator.setType(Types.LocatorType.className.name());
                            locator.setValue(elementClass);
                        }
                    }
                } catch (Exception ex) {
                    //to debug - remove later
                    // ex.printStackTrace();
                }
                try {
                    if (objElements.isEmpty()) {
                        //by xpath name
//                   if(elementDisplayText.isEmpty())
//                       objElements = driver.findElements(By.xpath("//input[contains(.,'" + visibleTxt + "')]"));
//                   else
                        objElements = driver.findElements(By.xpath("//input[contains(.,'" + elementDisplayText + "')]"));
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue("//input[contains(.,'" + elementDisplayText + "')]");
                    }
                } catch (Exception ex) {
                }

                if (objElements.isEmpty()) {
                    locator.setiRetVal(-1);
                    return locator;
                }

                if (objElements.size() == 1) {
                    objElement = objElements.get(0);
                } else if (objElements.size() > 1) {
                    objElement = objElements.get(0); //temp code
                    //
                    for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                        //ask use which one to select
                        //t odo
                    }
                }
            }

            locator.setiRetVal(1);
            return locator;

        } catch (Exception e) {
            locator.setiRetVal(-1);
            return locator;

        }
    }

    private Locator ExecuteWaitWithOptions(Step step,
                                          PageObject pageObject, WebDriver driver) {
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        String visibleTxt = pageObject.VisisbleText;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        WebElement objElement = null;
        Locator locator = new Locator();
        Wait wait = new Wait();
        wait.setType(getConditionForWait(step.getAction().name()));
        wait.setTimeout(step.getTestData());
        locator.setAction(step.getAction().name());
        locator.setCreatedByFunction("ExecuteWaitWithOptions");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setWait(wait);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);
        try {
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            clickAction = clickAction.replace("\\", "");

            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] elementAtrrs = pattern.split(clickAction);
            String elementType = "";
            String elementClass = "";
            String elementName = "";
            String elementDisplayText = "";
            String elementOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                elementType = elementAtrrs[1];
                elementClass = elementAtrrs[2];
                elementName = elementAtrrs[3];
                elementDisplayText = elementAtrrs[4];
                elementOnClick = elementAtrrs[5];
            } catch (Exception ex) {

            }

            if (elementClass.contains(" ")) {
                //replace all spaces in classname with . and then use cssselector
                elementClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }
            //execute with xpath
            if (!StringUtils.isEmpty(pageObject.xPath)) {
                objElement = driver.findElements(By.xpath(pageObject.xPath)).get(0);
                locator.setType(Types.LocatorType.xpath.name());
                locator.setValue(pageObject.xPath);
            }

            if(objElement == null){
                List<WebElement> listOfElements = driver.findElements(By.linkText(visibleTxt));
                if (listOfElements.isEmpty()){
                    listOfElements = driver.findElements(By.id(clickAction));
                    List<WebElement> listOfFilteredElements = new ArrayList<WebElement>();
                    for (WebElement we : listOfElements) {
                        //ideally in this case only one should be visibel or applicable
                        //hence currently checking for visible property
                        if (we.isDisplayed() && we.isEnabled()) {
                            listOfFilteredElements.add(we);
                        }
                    }
                    if (listOfFilteredElements.size() == 1) {
                        objElement = listOfFilteredElements.get(0);
                        locator.setType(Types.LocatorType.id.name());
                        locator.setValue(clickAction);
                    }
                } else{
                    objElement=listOfElements.get(0);
                    locator.setType(Types.LocatorType.linkText.name());
                    locator.setValue(visibleTxt);
                }
            }

            //find button locators
            if(objElement == null){
                try {
                    //by xpath name
                    List<WebElement> objElements = driver.findElements(By.xpath("//button[contains(.,'" + visibleTxt + "')]"));
                    objElement = objElements.get(0);
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//button[contains(.,'" + visibleTxt + "')]");
                } catch (Exception ex) {
                }
            }

            if(objElement==null)
            {
                //try to find by 'name'
                List<WebElement> objElements = null;
                try {
                    if (objElements==null) {
                        objElements = driver.findElements(By.name(elementName));
                        locator.setType(Types.LocatorType.name.name());
                        locator.setValue(elementName);
                    }
                } catch (Exception ex) {
                }
                try {
                    if (objElements.isEmpty()) {

                        if (bUseCSSSelector) {
                            //by CSSselector
                            objElements = driver.findElements(By.cssSelector(elementClass));
                            locator.setType(Types.LocatorType.cssSelector.name());
                            locator.setValue(elementClass);
                        } else {
                            //by class name
                            objElements = driver.findElements(By.className(elementClass));
                            locator.setType(Types.LocatorType.className.name());
                            locator.setValue(elementClass);
                        }
                    }
                } catch (Exception ex) {
                    //to debug - remove later
                    // ex.printStackTrace();
                }
                try {
                    if (objElements.isEmpty()) {
                        //by xpath name
//                   if(elementDisplayText.isEmpty())
//                       objElements = driver.findElements(By.xpath("//input[contains(.,'" + visibleTxt + "')]"));
//                   else
                        objElements = driver.findElements(By.xpath("//input[contains(.,'" + elementDisplayText + "')]"));
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue("//input[contains(.,'" + elementDisplayText + "')]");
                    }
                } catch (Exception ex) {
                }

                if (objElements.isEmpty()) {
                    locator.setiRetVal(-1);
                    return locator;
                }

                if (objElements.size() == 1) {
                    objElement = objElements.get(0);
                } else if (objElements.size() > 1) {
                    objElement = objElements.get(0); //temp code
                    //
                    for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                        //ask use which one to select
                        //t odo
                    }
                }
            }

            locator.setiRetVal(1);
            return locator;

        } catch (Exception e) {
            locator.setiRetVal(-1);
            return locator;

        }
    }

    private Locator ExecuteConditions(Step step, PageObject pageObject, WebDriver driver) {
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        String visibleTxt = pageObject.VisisbleText;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("If");
        locator.setCreatedByFunction("ExecuteConditions");
        locator.setData(step.getTestData());
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);
        try {
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            clickAction = clickAction.replace("\\", "");

            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] elementAtrrs = pattern.split(clickAction);
            String elementType = "";
            String elementClass = "";
            String elementName = "";
            String elementDisplayText = "";
            String elementOnClick = "";
            Boolean bUseCSSSelector = false;

            try {
                elementType = elementAtrrs[1];
                elementClass = elementAtrrs[2];
                elementName = elementAtrrs[3];
                elementDisplayText = elementAtrrs[4];
                elementOnClick = elementAtrrs[5];
            } catch (Exception ex) {

            }

            if (elementClass.contains(" ")) {
                elementClass = elementClass.replaceAll(" ", ".");
                bUseCSSSelector = true;
            }
            List<WebElement> listOfElements = driver.findElements(By.linkText(visibleTxt));
            if (listOfElements.isEmpty()) {
                listOfElements = driver.findElements(By.id(clickAction));
                List<WebElement> listOfFilteredElements = new ArrayList<>();
                for (WebElement we : listOfElements) {
                    //ideally in this case only one should be visibel or applicable
                    //hence currently checking for visible property
                    if (we.isDisplayed() && we.isEnabled()) {
                        listOfFilteredElements.add(we);
                    }
                }
                if (listOfFilteredElements.size() == 1) {
                    objElement = listOfFilteredElements.get(0);
                    locator.setType(Types.LocatorType.id.name());
                    locator.setValue(clickAction);
                }
            } else {
                objElement = listOfElements.get(0);
                locator.setType(Types.LocatorType.linkText.name());
                locator.setValue(visibleTxt);
            }
            if (objElement == null) {
                //try to find by 'name'
                List<WebElement> objElements = null;
                try {
                    if (objElements == null) {
                        objElements = driver.findElements(By.name(elementName));
                        locator.setType(Types.LocatorType.name.name());
                        locator.setValue(elementName);
                    }
                } catch (Exception ex) {
                }
                try {
                    if (objElements.isEmpty()) {

                        if (bUseCSSSelector) {
                            //by CSSselector
                            objElements = driver.findElements(By.cssSelector(elementClass));
                            locator.setType(Types.LocatorType.cssSelector.name());
                            locator.setValue(elementClass);
                        } else {
                            //by class name
                            objElements = driver.findElements(By.className(elementClass));
                            locator.setType(Types.LocatorType.className.name());
                            locator.setValue(elementClass);
                        }
                    }
                } catch (Exception ex) {
                    //to debug - remove later
                    // ex.printStackTrace();
                }
                try {
                    if (objElements.isEmpty()) {
                        //by xpath name
//                   if(elementDisplayText.isEmpty())
//                       objElements = driver.findElements(By.xpath("//input[contains(.,'" + visibleTxt + "')]"));
//                   else
                        objElements = driver.findElements(By.xpath("//input[contains(.,'" + elementDisplayText + "')]"));
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue("//input[contains(.,'" + elementDisplayText + "')]");
                    }
                } catch (Exception ex) {
                }

                if (objElements.isEmpty()) {
                    //return -1;
                    locator.setiRetVal(-1);
                    return locator;
                }

                if (objElements.size() == 1) {
                    objElement = objElements.get(0);
                } else if (objElements.size() > 1) {
                    objElement = objElements.get(0); // Temporary code, needs better handling
                }
            }

            //action is to be performed
            try {
                if(ifConditionCheck(objElement, locator.getData())){
                    locator.setiRetVal(1);
                } else {
                    locator.setiRetVal(-1);
                }
                return locator;
            } catch (Exception ex) {
                locator.setiRetVal(-1);
                return locator;
            }

        } catch (Exception e) {
            locator.setiRetVal(-1);
            return locator;
        }
    }

    private String getConditionForWait(String waitFor) {
        switch (waitFor) {
            case "WaitForElementToBeClickable":
                return "elementToBeClickable";
            case "WaitForElementToBeVisible":
                return "visibilityOfElementLocated";
            case "WaitForElementToBeInvisible":
                return "invisibilityOfTheElementLocated";
            case "WaitForElementToBePresent":
                return "presenceOfElementLocated";
            case "WaitForAlertPresent":
                return "alertIsPresent";
            default:
                return "";
        }
    }

    private boolean ifConditionCheck(WebElement webElement, String testData) {
        String actualData = webElement.getText();
        boolean isCondition = false;

        switch (testData.toLowerCase()) {
            case "isdisplayed":
                isCondition = webElement.isDisplayed();
                break;
            case "isenabled":
                isCondition = webElement.isEnabled();
                break;
            case "isselected":
                isCondition = webElement.isSelected();
                break;
            default:
                isCondition = testData.equalsIgnoreCase(actualData);
                break;
        }

        if (isCondition) {
            performWebAction = true;
        }else{
            performWebAction = false;
        }

        return isCondition;
    }

    private Locator SendWordKeyInputWithoutID(Step step, PageObject pageObject,
                                             String objAllAtt, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("SendWordKeyInputWithoutID");
        String wordKeys = step.getTestData();
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        WebElement objPO = pageObject.objectElement;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("sendKeys");
        locator.setCreatedByFunction("SendWordKeyInputWithoutID");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            //Map<String, PageObject> lmapPageObjects = new HashMap<String, PageObject>();
            List<WebElement> allWebElementList = new ArrayList<WebElement>();
            objElement = null;
            clickAction = clickAction.replace("\\", "");

            List<WebElement> objElements = null;

            if (objPO == null) {

                List<WebElement> inputs = driver.findElements(By.tagName("input"));

                for (WebElement input : inputs) {

                    if (input.isDisplayed()) {

                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        Object objAllAttributeTemp = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", input);
                        String strAllAttributeTmp = objAllAttributeTemp.toString();
                        strAllAttributeTmp = strAllAttributeTmp.replaceAll("\\{", "");
                        strAllAttributeTmp = strAllAttributeTmp.replaceAll("\\}", "");
                        System.out.println("Object All in SendWordNotID Attributes:-" + strAllAttributeTmp);
                        //input element can be anything
                        //text
                        //checkbox
                        //radio
                        //what else
                        //so getPageElements class and check
                        String inputType = input.getAttribute("type");
                        String visibletext = input.getText();

                        if (visibletext.isEmpty() || visibletext.length() <= 0) {
                            visibletext = input.getAttribute("value");
                        }
                        if (input.getAttribute("id").isEmpty() || input.getAttribute("id").equals("")) {
                            //create button id with type, class and onclick
                            //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                            String inputID = "spinputid" + "_$_";

                            try {
                                inputID += input.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            try {
                                inputID += input.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            try {
                                inputID += input.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                inputID += "null_$_";
                            }
                            // Need to check the
                            if (inputID.equalsIgnoreCase(clickAction)) {
                                allWebElementList.add(input);
                                locator = getXpathUsingAttributesForElement(input, locator, driver);
                                break;
                            }
                        } else {
                            // Ideally it should not come here as ID is present.
                        }

                    }
                }

                objElements = new ArrayList<WebElement>();
                for (WebElement elementSelected : allWebElementList) {

                    {
                        JavascriptExecutor executor = (JavascriptExecutor) driver;
                        Object objAllAttribute = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", elementSelected);
                        String strAllAttribute = objAllAttribute.toString();
                        strAllAttribute = strAllAttribute.replaceAll("\\{", "");
                        strAllAttribute = strAllAttribute.replaceAll("\\}", "");

                        List<String> allAttList = new ArrayList<String>();
                        String[] arrOfStr = strAllAttribute.split(",");
                        for (String a : arrOfStr) {
                            allAttList.add(a);
                        }

                        List<String> targetEleAttList = new ArrayList<String>();
                        String[] arrTargetEleAtt = objAllAtt.split(",");
                        for (String b : arrTargetEleAtt) {
                            targetEleAttList.add(b);
                        }

                        // Need to convert in list and then compare . Not Direct compare.
                        if (targetEleAttList.equals(allAttList)) {
                            objElements.add(elementSelected);
                        }
                    }
                }

                if (objElements.size() == 1) {
                    objElement = objElements.get(0);
                } else {
                    //need to removelater

                    if (objElements.size() > 1) {
                        objElement = objElements.get(0);
                    }
                    for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {
//ask use which one to select
                        //t odo
                    }
                }

            } else {
                objElement = objPO;  // We are assigning the WebElement in case of Fresh Run
            }

            // build xpath and set in locator for script generation
            locator = getXpathUsingAttributesForElement(objElement, locator, driver);
            locator.setData(wordKeys);

//-------------------------------
            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            if(performWebAction){
                if (objElement.isEnabled()) {
                    WebElement element1 = objElement; // Your element
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    Object aa = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", element1);
                    System.out.println("ALL Attributes of an Element :" + aa.toString());
                    //first clear edit control - specifically if its text box
                    if (objElement.getTagName().equalsIgnoreCase("input") || objElement.getTagName().equalsIgnoreCase("textarea")) {
                        objElement.sendKeys("");
                    }
                    WebElement element2 = objElement; // Your element
                    JavascriptExecutor executor1 = (JavascriptExecutor) driver;
                    Object aa1 = executor1.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", element2);
                    System.out.println("ALL Attributes of an Element :" + aa1.toString());
                    //=============================
                    if (objElement.getTagName().equalsIgnoreCase("select")
                            || objElement.getTagName().equalsIgnoreCase("option")
                            || objElement.getTagName().equalsIgnoreCase("radio")) {
                        System.out.println("scanning combo-box options");
                        //select given data using element by element search
                        Select select = new Select(objElement);
                        if (select.isMultiple()) {

                            //Add a logic to handle the user xpath flow
                            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                        }

                        List<WebElement> allOptions = select.getOptions();
                        System.out.println("Found #options : " + allOptions.size());

                        int iCnt = 0;
                        for (iCnt = 0; iCnt < allOptions.size(); iCnt++) {
                            String CurrentOption = allOptions.get(iCnt).getText();

                            if (CurrentOption.contains(wordKeys)) {

                                allOptions.get(iCnt).click();
                                Thread.sleep(1000);
                                break;

                            }
                        }
                        if (iCnt == allOptions.size()) {
                            //means we could not find valid option to select
                            //so its upto God to select it
                            char[] array = wordKeys.toCharArray();
                            for (char ch : array) {
                                objElement.sendKeys(Character.toString(ch));
                            }

                        }
                    } //==================
                    else {
                        clearInput(driver, objElement);
                        /*char[] array = wordKeys.toCharArray();
                        for (char ch : array) {
                            objElement.sendKeys(Character.toString(ch));
                        }*/
                        objElement.sendKeys(wordKeys);
                    }
                    //store control id
                    mapAlreadyExecutedObjectOnGivenPAge.put(clickAction, wordKeys);
                    //store test-data used
                    listTestDataUsedTillNow.add(wordKeys);

                    System.out.println("*******    Sent-WordKeys() to : " + clickAction + "   = " + wordKeys);

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        //return 2;
                        locator.setiRetVal(2);
                        return locator;
                    } else {
                        try {
                            if (objElement.getTagName().equalsIgnoreCase("select") || objElement.getTagName().equalsIgnoreCase("option")) {
                                //we may getPageElements some new controls loaded on screen which were not there prev.
                                //return 3;
                                locator.setiRetVal(3);
                                return locator;
                            }
                        } catch (Exception e) {
                            //page stale element reference so it means its changed.

                            //check and verify this is to be returned as 3 or 1
                            //return 3;
                            locator.setiRetVal(3);
                            return locator;
                        }
                        //return 1;
                        locator.setiRetVal(1);
                        return locator;
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }

            //return 0;
            locator.setiRetVal(0);
            return locator;

        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        }catch (Exception e) {
            //return -1;
            locator.setiRetVal(-1);
            return locator;

        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }
    }

    private Locator ExecuteDropdownClickWithID(Step step, PageObject pageObject, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("ExecuteDropdownClickWithID");
        String wordKeys = step.getTestData();
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("select");
        locator.setData(wordKeys);
        locator.setCreatedByFunction("ExecuteDropdownClickWithID");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            objElement = driver.findElement(By.id(clickAction));

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();
            if (width <= 0 && height <= 0) {
                //something is wrong with controls
                locator.setiRetVal(-1);
                return locator;
            }

            if(performWebAction){
                if (objElement.isEnabled()) {
                    //select dropdown
                    Select dropdown = new Select(objElement);
                    if (dropdown.isMultiple()) {
                    //Add a logic to handle the user xpath flow
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                    } else {
                        locator.setType(Types.LocatorType.id.name());
                        locator.setValue(clickAction);
                    }
                    locator.setActionMethod(Types.ActionMethod.defaultt.name());
                    dropdown.selectByVisibleText(wordKeys);
                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                        } else {
                            locator.setiRetVal(1);
                            return locator;
                        }
                    }
                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }
            locator.setiRetVal(0);
            return locator;
        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        }catch (Exception ex) {
            ex.printStackTrace();
            try {
                //Add a logic to handle the user xpath flow
            } catch (Exception ex2) {
                locator.setiRetVal(-1);
                return locator;
            }
            locator.setiRetVal(1);
            return locator;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }
    }

    private Locator ExecuteDropdownClickWithoutID(Step step, PageObject pageObject, WebDriver driver) {
        System.out.println("ExecuteDropdownClickWithoutID");
        String wordKeys = step.getTestData();
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("select");
        locator.setData(wordKeys);
        locator.setCreatedByFunction("ExecuteDropdownClickWithoutID");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            //we have button - most probably htmlbutton which pain in axxxxx.
            //so getPageElements its type, class, name, displaytext,
            Pattern pattern = Pattern.compile(Pattern.quote("_$_"));

            String[] ddAtrrs = pattern.split(clickAction);
            String ddType = "";
            String ddClass = "";
            String ddName = "";
            String ddDisplayText = "";
            String ddOnClick = "";
            try {
                ddType = ddAtrrs[1];
                ddClass = ddAtrrs[2];
                ddName = ddAtrrs[3];
                ddDisplayText = ddAtrrs[4];
                ddOnClick = ddAtrrs[5];
            } catch (Exception ex) {
                System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
            }

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            //try to find by 'name'
            List<WebElement> objElements = null;
            try {
                objElements = driver.findElements(By.name(ddName));
                locator.setType(Types.LocatorType.name.name());
                locator.setValue(ddName);
                if (objElements.isEmpty()) {
                    //by class name
                    objElements = driver.findElements(By.className(ddClass));
                    locator.setType(Types.LocatorType.className.name());
                    locator.setValue(ddClass);
                }

                if (objElements.isEmpty()) {
                    //by xpath name
                    String label = ddDisplayText;
                    objElements = driver.findElements(By.xpath("//select[contains(.,'" + label + "')]"));
                    locator.setType(Types.LocatorType.xpath.name());
                    locator.setValue("//select[contains(.,'" + label + "')]");
                }

            } catch (Exception ex) {
                try {
                    //by class name
                    objElements = driver.findElements(By.className(ddClass));
                    locator.setType(Types.LocatorType.className.name());
                    locator.setValue(ddClass);
                    if (objElements.isEmpty()) {
                        //by xpath name
                        String label = ddDisplayText;
                        objElements = driver.findElements(By.xpath("//select[contains(.,'" + label + "')]"));
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue("//select[contains(.,'" + label + "')]");
                    }
                } catch (Exception ex1) {

                    //by xpath
                    try {
                        String label = ddDisplayText;
                        objElements = driver.findElements(By.xpath("//select[contains(.,'" + label + "')]"));
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue("//select[contains(.,'" + label + "')]");
                    } catch (Exception ex2) {

                    }
                }
            }

            objElement = null;

            if (objElements.size() == 1) {
                objElement = objElements.get(0);
            } else {
                for (int iCnt = 0; iCnt < objElements.size(); iCnt++) {

                    //ask use which one to select
                    //t odo
                }
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);


            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            if (width <= 0 && height <= 0) {
                //something is wrong with controls
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }

            if(performWebAction){
                if (objElement.isEnabled()) {

                    //objElement.click();
                    String strElementype = objElement.getAttribute("type");

                    //select dropdown
                    Select dropdown = new Select(objElement);

                    if (dropdown.isMultiple()) {

                        //Add a logic to handle the user xpath flow
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                    }
                    dropdown.selectByVisibleText(wordKeys);
                    locator.setActionMethod(Types.ActionMethod.defaultt.name());
                    //act.moveToElement(dropdown).moveByOffset((width / 2) - 2, 0).click().perform();
                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                        //return 2;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                            //return 3;
                        } else {
                            locator.setiRetVal(1);
                            return locator;
                            //return 1;
                        }
                    }

                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }
            locator.setiRetVal(0);
            return locator;
            //return 0;

        } catch (Exception e) {

            try {
            //Add a logic to handle the user xpath flow
            } catch (Exception ex2) {
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }
            locator.setiRetVal(1);
            return locator;
            //return 1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }

        }

    }

    private Locator ExecuteCheckBoxClickWithoutID(Step step, PageObject pageObject, WebDriver driver) {
        System.out.println("ExecuteCheckBoxClickWithoutID");
        String wordKeys = step.getTestData();
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        WebElement objPO = pageObject.objectElement;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("click");
        locator.setCreatedByFunction("ExecuteCheckBoxClickWithoutID");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

                      objElement = null;

            //if still null then assign stored object.
            if (objElement == null) {
                objElement = objPO;
                try {
                    locator.setValue(objElement.getAttribute("id"));
                    locator.setType(Types.LocatorType.id.name());
                } catch (Exception ex1) {
                    try {
                        String value = objElement.getAttribute("value");
                        locator.setValue("//input[@type='checkbox' and @value='" + value + "']");
                        locator.setType(Types.LocatorType.xpath.name());
                    } catch(Exception ex2) {
                        try {
                            locator.setValue(objElement.getAttribute("name"));
                            locator.setType(Types.LocatorType.name.name());
                        } catch(Exception ex) {
                            // add try/catch in case there are any more combinations added
                        }
                    }
                }
            }

            //By elementLocation = By.id(clickAction);
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            //WebElement objElement = driver.findElement(elementLocation);
            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();

            if (width <= 0 && height <= 0) {
                //something is wrong with controls
                locator.setiRetVal(-1);
                return locator;
                //return -1;
            }

            if(performWebAction){
                Actions act = new Actions(driver);
                if (objElement.isEnabled()) {

                    //objElement.click();
                    String strElementype = objElement.getAttribute("type");

                    try {
                        ((JavascriptExecutor) driver).executeScript( "arguments[0].click();",objElement);
                        locator.setActionMethod(Types.ActionMethod.javascriptexecutor.name());
                    } catch (Exception e) {
                        try {
                            act.moveToElement(objElement).moveByOffset((width / 2) - 2, 0).click().perform();
                            locator.setActionMethod(Types.ActionMethod.actions.name());
                        } catch (Exception ex) {
                            objElement.click();
                            locator.setActionMethod(Types.ActionMethod.defaultt.name());
                        }
                    }

                    Thread.sleep(actionDelay);

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                        //return 2;
                    } else {

                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                            //return 3;
                        } else {
                            locator.setiRetVal(1);
                            return locator;
                            //return 1;
                        }
                    }
                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }
            locator.setiRetVal(0);
            return locator;
            //return 0;
        } catch (Exception e) {
            locator.setiRetVal(-1);
            return locator;
            //return -1;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }
    }

    private Locator SendWordKeys(String wordKeys, String clickAction, boolean bIsIFrameControl, String iFrameId, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("sendKeys");
        locator.setCreatedByFunction("SendWordKeys");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);

        try {

            //By elementLocation = By.xpath(clickAction);
            clickAction = clickAction.replace("\\", "");

            By elementLocation = By.id(clickAction);

            // Select date = new Select(driver.findElement(By.linkText("the date want to select")));

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
                //driver.switchTo().frame(iFrameId);
            }
            objElement = driver.findElement(elementLocation);
            if (objElement != null) {
                locator.setType(Types.LocatorType.id.name());
                locator.setValue(clickAction);
                locator.setData(wordKeys);
                int iWaitCount = 0;
                boolean bEditable = true;

                if(!objElement.isEnabled()) {
                    /**Dated: 15-Dec-2022
                     * Not able to get what this while loop does,
                     * so added above if condition to skip this while loop*/
                    while (!(CheckIfGivenbjectIsEditable(clickAction, bIsIFrameControl, iFrameId, objElement, wordKeys, driver))) {
                        iWaitCount++;
                        if (iWaitCount >= WaitCounter) {
                            //need to handle this case when due to some app-validation or any other reason
                            //this control is not getting editable.
                            bEditable = false;
                            break;
                        }
                        Thread.sleep(1000);

                    }
                }
                if (!bEditable) {
                    //return -1;
                    locator.setiRetVal(-1);
                    return locator;
                }
            }
            //since it reached here, it has to be enabled.
            //no need to check
//            if (objElement.isEnabled())
            //this is required since checkeditable is switching frames.
            //need to review that function.
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
                //driver.switchTo().frame(iFrameId);
            }
            {

                //first clear edit control - specifically if its text box
                if (objElement.getTagName().equalsIgnoreCase("input") || objElement.getTagName().equalsIgnoreCase("textarea")) {
                    try {
                        objElement.sendKeys("");
                    } catch (Exception localex1) {
                        //object may not be interactable
                        localex1.printStackTrace();
                    }
                }

                //=============================
                if(performWebAction){
                    if (objElement.getTagName().equalsIgnoreCase("select")
                            || objElement.getTagName().equalsIgnoreCase("option")
                            || objElement.getTagName().equalsIgnoreCase("radio")) {
                        System.out.println("scanning combo-box options");
                        //select given data using element by element search
                        Select select = new Select(objElement);
                        if (select.isMultiple()) {

                        //Add a logic to handle the user xpath flow
                            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                        }

                        List<WebElement> allOptions = select.getOptions();
                        System.out.println("Found #options : " + allOptions.size());

                        int iCnt = 0;
                        boolean bSelected = false;

                        //first bring focus to select element
                        JavascriptExecutor jse = (JavascriptExecutor) driver;
                        try {
                            try {
                                new Actions(driver).moveToElement(objElement).click().perform();
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                            try {
                                objElement.sendKeys("");
                            } catch (Exception ex) {
                            }
                            try {
                                jse.executeScript("element.focus();");
                            } catch (Exception ex) {
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }

                        try {
                            select.selectByVisibleText(wordKeys);
                            if (objElement.getText().equalsIgnoreCase(wordKeys)) {
                                bSelected = true;
                            }

                        } catch (Exception ex) {
                            //
                        }
                        if (!bSelected) {
                            try {
                                select.selectByValue(wordKeys);
                                if (objElement.getText().equalsIgnoreCase(wordKeys)) {
                                    bSelected = true;
                                }

                            } catch (Exception ex) {
                                //
                            }
                        }

                        //find index of item to be selected : index start with 0
                        int iIndex = 0;
                        if (!bSelected) {
                            try {
                                List<WebElement> x = objElement.findElements(By.tagName("option"));
                                for (WebElement OptionElement : x) {
                                    String yString = OptionElement.getAttribute("innerHTML");
                                    if (yString.equalsIgnoreCase(wordKeys)) {
                                        break;
                                    }
                                    iIndex++;
                                }
                            } catch (Exception ex) {
                                //
                            }
                            try {
                                select.selectByIndex(iIndex);
                                bSelected = true;
                            } catch (Exception ex) {
                                //
                            }
                        }

                        //this is to avoid - "element not interactable" error
                        int optionsSize = allOptions.size();
                        if (!bSelected) {
                            for (iCnt = 0; iCnt < optionsSize; iCnt++) {
                                try {
                                    String CurrentOption = allOptions.get(iCnt).getText();

                                    if (CurrentOption.contains(wordKeys)) {

                                        allOptions.get(iCnt).click();
                                        Thread.sleep(1000);
                                        bSelected = true;
                                        break;

                                    }
                                } catch (Exception ex) {
                                    //catch to handle "element not interactable" error
                                }
                            }
                        }
                        //somtimes getText may be emplty hence couldnot find above match hence checking asbelow
                        if (!bSelected) {
                            try {
                                List<WebElement> x = objElement.findElements(By.tagName("option"));
                                for (WebElement OptionElement : x) {
                                    String yString = OptionElement.getAttribute("innerHTML");
                                    if (yString.contains(wordKeys)) {

                                        try {
                                            OptionElement.click();
                                        } catch (Exception ex) {
                                        }
                                        Thread.sleep(1000);
                                        bSelected = true;
                                        break;

                                    }
                                }
                            } catch (Exception ex) {
                                //
                            }
                        }
                        if (!bSelected) {
                            if (iCnt >= optionsSize) {
                                //means we could not find valid option to select
                                //so its upto God to select it
                                char[] array = wordKeys.toCharArray();
                                try {
                                    for (char ch : array) {
                                        objElement.sendKeys(Character.toString(ch));
                                    }
                                    bSelected = true;
                                } catch (Exception ex) {
                                    //try sending directly
                                    System.out.println("not able to send data character to combo...trying direct-Send");
                                    objElement.sendKeys(wordKeys);
                                    bSelected = true;
                                }

                            }
                        }
                    } //==================
                    else {
                        char[] array = wordKeys.toCharArray();
                        for (char ch : array) {
                            try {
                                objElement.sendKeys(Character.toString(ch));

                            } catch (Exception localex1) {
                                System.out.println("not able to send data character : " + Character.toString(ch));
                                try {
                                    objElement.sendKeys(wordKeys);
                                } catch (Exception localex2) {
                                    System.out.println("Stiil Not able to send whole data existing with -1 : " + wordKeys);
                                    locator.setiRetVal(-1);
                                    return locator;
                                    //return -1;
                                }       //object may not be interactable hence tried sending whole word
                            }
                        }
                    }
                    //store control id
                    mapAlreadyExecutedObjectOnGivenPAge.put(clickAction, wordKeys);
                    //store test-data used
                    listTestDataUsedTillNow.add(wordKeys);
                }

                Thread.sleep(actionDelay);

                if (bIsIFrameControl) {
                    //driver.switchTo().defaultContent();
                }

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    locator.setiRetVal(2);
                    return locator;
                    //return 2;
                } else {
                    try {
                        if (objElement.getTagName().equalsIgnoreCase("select") || objElement.getTagName().equalsIgnoreCase("option")) {
                            //we may getPageElements some new controls loaded on screen which were not there prev.
                            //return 3;
                            locator.setiRetVal(3);
                            return locator;
                        }
                    } catch (Exception e) {
                        //page stale element reference so it means its changed.

                        //check and verify this is to be returned as 3 or 1
                        //return 3;
                        locator.setiRetVal(3);
                        return locator;
                    }
                    //return 1;
                    locator.setiRetVal(1);
                    return locator;
                }

            }
//            return 0;

        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        } catch (Exception e) {
            e.printStackTrace();
//            try {
//                JOptionPane.showMessageDialog(null, null, "Click on valid control to Proceed", 0);
//                Thread.sleep(5000);
//            } catch (InterruptedException ex) {
//                //do nothing
//            }
            //return -1;
            locator.setiRetVal(-1);
            return locator;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }
    }

    private Locator SendWordKeys(Step step, PageObject pageObject, WebDriver driver) {
        System.out.println("SendWordKeys");
        String wordKeys = step.getTestData();
        String clickAction = pageObject.ObjectId;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        System.out.println("Executing : " + Thread.currentThread()
                .getStackTrace()[1].getMethodName() + " with : " + clickAction);
        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("sendKeys");
        locator.setCreatedByFunction("SendWordKeys");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            clickAction = clickAction.replace("\\", "");
            By elementLocation = By.id(clickAction);

            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
                //driver.switchTo().frame(iFrameId);
            }

            //get URL before performing action
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            objElement = driver.findElement(elementLocation);
            if (objElement != null) {
                locator.setType(Types.LocatorType.id.name());
                locator.setValue(clickAction);
                locator.setData(wordKeys);
                int iWaitCount = 0;
                boolean bEditable = true;

                if(!objElement.isEnabled()) {
                    /**Dated: 15-Dec-2022
                     * Not able to get what this while loop does,
                     * so added above if condition to skip this while loop*/
                    while (!(CheckIfGivenbjectIsEditable(clickAction, bIsIFrameControl, iFrameId, objElement, wordKeys, driver))) {
                        iWaitCount++;
                        if (iWaitCount >= WaitCounter) {
                            //need to handle this case when due to some app-validation or any other reason
                            //this control is not getting editable.
                            bEditable = false;
                            break;
                        }
                        Thread.sleep(1000);

                    }
                }
                if (!bEditable) {
                    //return -1;
                    locator.setiRetVal(-1);
                    return locator;
                }
            }
            //since it reached here, it has to be enabled.
            //no need to check
//            if (objElement.isEnabled())
            //this is required since checkeditable is switching frames.
            //need to review that function.
            if (bIsIFrameControl) {
                //System.out.println("Frame is present and iframeID="+iFrameId);
                if (iFrameId.equalsIgnoreCase("gfst_main")){
                    //driver.switchTo().frame(iFrameId);
                    List<WebElement> iframeElemens = driver.findElements(By.tagName("iframe"));
                    for (int i = 0; i <iframeElemens.size() ; i++) {
                        //System.out.println(iframeElemens.get(i).getAttribute("id"));
                        if(iframeElemens.get(i).getAttribute("id").equalsIgnoreCase("approvalLoginFrame")){
                            //driver.switchTo().frame(driver.findElement(By.xpath("//*[@id='approvalLoginFrame']")));
                        }
                    }
                }else{
                    //driver.switchTo().defaultContent();
                    //driver.switchTo().frame(iFrameId);
                }
            }
            {

                //first clear edit control - specifically if its text box
                if (objElement.getTagName().equalsIgnoreCase("input") || objElement.getTagName().equalsIgnoreCase("textarea")) {
                    try {
                        objElement.sendKeys("");
                    } catch (Exception localex1) {
                        //object may not be interactable
                        localex1.printStackTrace();
                    }
                }

                //=============================
                if(performWebAction){
                    if (objElement.getTagName().equalsIgnoreCase("select")
                            || objElement.getTagName().equalsIgnoreCase("option")
                            || objElement.getTagName().equalsIgnoreCase("radio")) {
                        System.out.println("scanning combo-box options");
                        locator.setAction(objElement.getTagName().toLowerCase());
                        //select given data using element by element search
                        Select select = new Select(objElement);
                        if (select.isMultiple()) {


                        }

                        List<WebElement> allOptions = select.getOptions();
                        System.out.println("Found #options : " + allOptions.size());

                        int iCnt = 0;
                        boolean bSelected = false;

                        //first bring focus to select element
                        JavascriptExecutor jse = (JavascriptExecutor) driver;
                        try {
                            try {
                                new Actions(driver).moveToElement(objElement).click().perform();
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                            try {
                                objElement.sendKeys("");
                            } catch (Exception ex) {
                            }
                            try {
                                jse.executeScript("element.focus();");
                            } catch (Exception ex) {
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }

                        try {
                            select.selectByVisibleText(wordKeys);
                            if (objElement.getText().equalsIgnoreCase(wordKeys)) {
                                bSelected = true;
                            }

                        } catch (Exception ex) {
                            //
                        }
                        if (!bSelected) {
                            try {
                                select.selectByValue(wordKeys);
                                if (objElement.getText().equalsIgnoreCase(wordKeys)) {
                                    bSelected = true;
                                }

                            } catch (Exception ex) {
                                //
                            }
                        }

                        //find index of item to be selected : index start with 0
                        int iIndex = 0;
                        if (!bSelected) {
                            try {
                                List<WebElement> x = objElement.findElements(By.tagName("option"));
                                for (WebElement OptionElement : x) {
                                    String yString = OptionElement.getAttribute("innerHTML");
                                    if (yString.equalsIgnoreCase(wordKeys)) {
                                        break;
                                    }
                                    iIndex++;
                                }
                            } catch (Exception ex) {
                                //
                            }
                            try {
                                select.selectByIndex(iIndex);
                                bSelected = true;
                            } catch (Exception ex) {
                                //
                            }
                        }

                        //this is to avoid - "element not interactable" error
                        int optionsSize = allOptions.size();
                        if (!bSelected) {
                            for (iCnt = 0; iCnt < optionsSize; iCnt++) {
                                try {
                                    String CurrentOption = allOptions.get(iCnt).getText();

                                    if (CurrentOption.contains(wordKeys)) {

                                        allOptions.get(iCnt).click();
                                        Thread.sleep(1000);
                                        bSelected = true;
                                        break;

                                    }
                                } catch (Exception ex) {
                                    //catch to handle "element not interactable" error
                                }
                            }
                        }
                        //somtimes getText may be emplty hence couldnot find above match hence checking asbelow
                        if (!bSelected) {
                            try {
                                List<WebElement> x = objElement.findElements(By.tagName("option"));
                                for (WebElement OptionElement : x) {
                                    String yString = OptionElement.getAttribute("innerHTML");
                                    if (yString.contains(wordKeys)) {

                                        try {
                                            OptionElement.click();
                                        } catch (Exception ex) {
                                        }
                                        Thread.sleep(1000);
                                        bSelected = true;
                                        break;

                                    }
                                }
                            } catch (Exception ex) {
                                //
                            }
                        }
                        if (!bSelected) {
                            if (iCnt >= optionsSize) {
                                //means we could not find valid option to select
                                //so its upto God to select it
                                char[] array = wordKeys.toCharArray();
                                try {
                                    for (char ch : array) {
                                        objElement.sendKeys(Character.toString(ch));
                                    }
                                    bSelected = true;
                                } catch (Exception ex) {
                                    //try sending directly
                                    System.out.println("not able to send data character to combo...trying direct-Send");
                                    objElement.sendKeys(wordKeys);
                                    bSelected = true;
                                }

                            }
                        }
                    } //==================
                    else {
                        char[] array = wordKeys.toCharArray();
                        for (char ch : array) {
                            try {
                                objElement.sendKeys(Character.toString(ch));

                            } catch (Exception localex1) {
                                System.out.println("not able to send data character : " + Character.toString(ch));
                                try {
                                    objElement.sendKeys(wordKeys);
                                } catch (Exception localex2) {
                                    System.out.println("Stiil Not able to send whole data existing with -1 : " + wordKeys);
                                    locator.setiRetVal(-1);
                                    return locator;
                                    //return -1;
                                }       //object may not be interactable hence tried sending whole word
                            }
                        }
                    }
                    //store control id
                    mapAlreadyExecutedObjectOnGivenPAge.put(clickAction, wordKeys);
                    //store test-data used
                    listTestDataUsedTillNow.add(wordKeys);
                }

                Thread.sleep(actionDelay);

                String NextURL = driver.getCurrentUrl();
                String NextTitle = driver.getTitle();

                if (bIsIFrameControl) {
                    //driver.switchTo().defaultContent();
                }

                if (!(currentURL.equalsIgnoreCase(NextURL))
                        || !(currentTitle.equalsIgnoreCase(NextTitle))) {

                    //it means page is changed
                    locator.setiRetVal(2);
                    return locator;
                    //return 2;
                } else {
                    try {
                        if (objElement.getTagName().equalsIgnoreCase("select") || objElement.getTagName().equalsIgnoreCase("option")) {
                            //we may getPageElements some new controls loaded on screen which were not there prev.
                            //return 3;
                            locator.setiRetVal(3);
                            return locator;
                        }
                    } catch (Exception e) {
                        //page stale element reference so it means its changed.

                        //check and verify this is to be returned as 3 or 1
                        //return 3;
                        locator.setiRetVal(3);
                        return locator;
                    }
                    //return 1;
                    locator.setiRetVal(1);
                    return locator;
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            locator.setiRetVal(-1);
            return locator;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }

        }
    }

    private Locator ExecuteAssertVerifyWithXpath(Step step, PageObject pageObject, WebDriver driver) {
        String action = step.getAction().name();
        String strXPath = pageObject.xPath;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String data = step.getTestData();
        String iFrameId = pageObject.iFrameId;
        String visibleTxt = pageObject.VisisbleText;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction(action);
        locator.setCreatedByFunction("ExecuteAssertVerifyWithXpath");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);
        Verify verify = new Verify();
        verify.setExpectedValue(data);
        try {
            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);
            locator.setData(data);

            try {
                objElement = driver.findElement(By.xpath(strXPath));
                locator.setType(Types.LocatorType.xpath.name());
                locator.setValue(strXPath);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            if (objElement == null) {
                locator.setiRetVal(0);
                return locator;
            }
            Set existanceVerbs = new HashSet<String>(Arrays.asList("exists", "present", "visible","exist"));
            Set equalVerbs = new HashSet<String>(Arrays.asList("equals"));
            String actualValue = objElement.getAttribute("value");
            verify.setActualValue(actualValue);
            if(action.equalsIgnoreCase("assertequals")){
                verify.setAssertCondition("assertEquals");
                Assert.assertEquals(actualValue,data,"The values are not equal");
            }
            else if(action.equalsIgnoreCase("assertnotequals")){
                verify.setAssertCondition("assertNotEquals");
                Assert.assertNotEquals(actualValue,data,"The values are equal");

            }
            else if(action.equalsIgnoreCase("asserttrue")) {
                verify.setAssertCondition("assertTrue");
                if (data.equalsIgnoreCase("isEnabled")) {
                    Assert.assertTrue(objElement.isEnabled());
                }
                else if (data.equalsIgnoreCase("isDisplayed")) {
                    Assert.assertTrue(objElement.isDisplayed());
                }
                else if (data.equalsIgnoreCase("isSelected")) {
                    Assert.assertTrue(objElement.isSelected());
                }
            }
            else if (action.equalsIgnoreCase("assertfalse")){
                verify.setAssertCondition("assertFalse");
                if (data.equalsIgnoreCase("isEnabled")) {
                    Assert.assertFalse(objElement.isEnabled());

                }
                else if (data.equalsIgnoreCase("isDisplayed")) {
                    Assert.assertFalse(objElement.isDisplayed());
                }
                else if (data.equalsIgnoreCase("isSelected")) {
                    Assert.assertFalse(objElement.isSelected());
                }

            }
            locator.setVerify(verify);
            locator.setiRetVal(1);
            return locator;

        } catch (Exception e){
            e.printStackTrace();
            locator.setiRetVal(-1);
            return locator;
        }
        catch (AssertionError ex) {
            ex.printStackTrace();
            locator.setiRetVal(0);
            return locator;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }
    }

    private Locator ExecuteSelectWithXpath(Step step, PageObject pageObject, WebDriver driver) throws LocatorNotFoundException {
        System.out.println("ExecuteSelectWithXpath");
        String wordKeys = step.getTestData();
        String xpath = pageObject.xPath;
        boolean bIsIFrameControl = pageObject.bIsIFrameControl;
        String iFrameId = pageObject.iFrameId;
        boolean bIsChildWindowControl = pageObject.bIsChildWindowControl;
        String childWindowTitle = pageObject.childWindowTitle;

        WebElement objElement = null;
        Locator locator = new Locator();
        locator.setAction("select");
        locator.setData(wordKeys);
        locator.setCreatedByFunction("ExecuteSelectWithXpath");
        locator.setElementInsideIframe(bIsIFrameControl);
        locator.setIframeIdOrName(iFrameId);
        locator.setElementInsideChildWindow(bIsChildWindowControl);
        locator.setChildWindowTitle(childWindowTitle);

        try {
            objElement = driver.findElement(By.xpath(xpath));

            //get URL before click
            String currentURL = driver.getCurrentUrl();
            String currentTitle = driver.getTitle();
            locator.setPageUrl(currentURL);
            locator.setPageTitle(currentTitle);

            if (bIsIFrameControl) {
                //driver.switchTo().frame(iFrameId);
            }

            int width = objElement.getSize().getWidth();
            int height = objElement.getSize().getHeight();
            if (width <= 0 && height <= 0) {
                //something is wrong with controls
                locator.setiRetVal(-1);
                return locator;
            }

            if(performWebAction){
                if (objElement.isEnabled()) {
                    //select dropdown
                    Select dropdown = new Select(objElement);
                    if (dropdown.isMultiple()) {
                        //Add a logic to handle the user xpath flow
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                    } else {
                        locator.setType(Types.LocatorType.xpath.name());
                        locator.setValue(xpath);
                    }
                    locator.setActionMethod(Types.ActionMethod.defaultt.name());
                    dropdown.selectByVisibleText(wordKeys);
                    Thread.sleep(actionDelay);

                    String NextURL = driver.getCurrentUrl();
                    String NextTitle = driver.getTitle();

                    if (bIsIFrameControl) {
                        //driver.switchTo().defaultContent();
                    }
                    if (!(currentURL.equalsIgnoreCase(NextURL))
                            || !(currentTitle.equalsIgnoreCase(NextTitle))) {
                        //it means page is changed
                        locator.setiRetVal(2);
                        return locator;
                    } else {
                        // CheckIfPopup windows is launched
                        boolean bPopUpWindowAppeared = false;
                        String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
                        String subWindowHandler = null;

                        Set<String> handles = driver.getWindowHandles(); // getPageElements all window handles
                        Iterator<String> iterator = handles.iterator();
                        while (iterator.hasNext()) {
                            subWindowHandler = iterator.next();
                        }

                        if (subWindowHandler != null) {
                            driver.switchTo().window(subWindowHandler); // switch to popup window
                            bPopUpWindowAppeared = true;
                        }

                        // Now you are in the popup window, perform necessary actions here
                        //driver.switchTo().window(parentWindowHandler);  // switch back to parent window
                        if (bPopUpWindowAppeared) {
                            locator.setiRetVal(3);
                            return locator;
                        } else {
                            locator.setiRetVal(1);
                            return locator;
                        }
                    }
                }
            }else {
                locator.setiRetVal(1);
                return locator;
            }
            locator.setiRetVal(0);
            return locator;
        } catch(LocatorNotFoundException lne){
            throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
        } catch (Exception ex) {
            ex.printStackTrace();
            try {
            //Add a logic to handle the user xpath flow
            } catch (Exception ex2) {
                locator.setiRetVal(-1);
                return locator;
            }
            locator.setiRetVal(1);
            return locator;
        } finally {
            //this will getPageElements executed two times but its ok
            if (bIsIFrameControl) {
                //driver.switchTo().defaultContent();
            }
        }
    }

    protected ResponseDTO startAndFindTheLocator(Step step, WebDriver driver, Map<String, PageObject> relevantObject) {

        ResponseDTO responseDTO = new ResponseDTO();
        try {
            //here we have list of all control(pageObjecT) details on current page and
            //all teststep description with data.
            //Here we need to find exact pageObject which is accurately representing action of given testStep and its action(click or enter)
            wait = new WebDriverWait(driver, Duration.ofSeconds(20));

            Map<String, PageObject> mapPageObjects = new HashMap<String, PageObject>();
            Map<String, PageObject> mapPageObjectsOrg = new HashMap<>();

            Set<PageObject> possibleActionableControls = new HashSet<PageObject>();
            PageObject objPOSelected = null;
            String storedObjAttributes = "";
            boolean pageChangedFlag = false;
            boolean popupLaunchedFlag = false;

            String action = null;
            String actor = null;

            if (step.getAction().name().toLowerCase().contains("launch")) {
                action = "launch";
                actor = "browser";
            } else if (step.getAction().name().toLowerCase().contains("navigate")) {
                action = "Navigate";
                actor = "url";
            } else if (step.getAction().name().equalsIgnoreCase("Enter")) {
                action = "Sendkeys";
                actor = "Menu/Label/Button";
            } else {
                action = step.getAction().name();
                actor = "Menu/Label/Button";
            }


            Locator locator = null;
            String mainWindow = "";

            if ((step.getAction().name().toLowerCase().contains("launch")
                    || (step.getAction().name().toLowerCase().contains("open")))
                    ) {
                locator = new Locator();
                locator.setAction(step.getAction().name());
                locator.setCreatedByFunction("LaunchBrowser");

                step.setLocator(locator);
                step = Utils.getScreenshot(driver, step);

                responseDTO.setExecutedStep(step);

                return responseDTO;

            }

            if (step.getAction().name().toLowerCase().contains("exit")){
                locator = new Locator();
                locator.setAction(step.getAction().name());
                locator.setCreatedByFunction("ExitBrowser");

                step.setLocator(locator);
                step = Utils.getScreenshot(driver, step);

                responseDTO.setExecutedStep(step);

                try {
                    driver.quit();
                } catch(Exception e){

                }

                return responseDTO;

            }


            if ((step.getAction().name().toLowerCase().contains("goto")
                    || (step.getAction().name().toLowerCase().contains("load"))
                    || (step.getAction().name().toLowerCase().contains("navigate")))
                    ) {
                driver.get(step.getTestData());
                locator = new Locator();
                locator.setAction(step.getAction().name());
                locator.setCreatedByFunction("LaunchBrowser");
                locator.setPageUrl(driver.getCurrentUrl());
                locator.setPageTitle(driver.getTitle());

                step.setLocator(locator);
                step = Utils.getScreenshot(driver, step);

                responseDTO.setExecutedStep(step);

                return responseDTO;
            }
            //handling implicitly/hard wait
            if (step.getAction().equals(Step.stepAction.WAIT)) {
                locator = new Locator();
                Wait wait = new Wait();
                wait.setType("wait");
                wait.setTimeout(step.getTestData());
                locator.setAction("wait");
                locator.setCreatedByFunction("ExecuteWait");
                locator.setWait(wait);

                step.setLocator(locator);
                step = Utils.getScreenshot(driver, step);

                responseDTO.setExecutedStep(step);

                return responseDTO;

            }

            if (step.getAction().equals(Step.stepAction.SWITCHTOIFRAME)) {
                locator = switchToIframe(step, driver);

                step.setLocator(locator);
                step = Utils.getScreenshot(driver, step);

                responseDTO.setExecutedStep(step);

                return responseDTO;

            }

            //performance improvement check
            mainWindow = getWindowHandle(driver);

            System.out.println("Normal scanning....");

            //make a copy of original pageobjects
            mapPageObjects.clear();
            mapPageObjects.putAll(mapPageObjectsOrg);

            //if(testCaseCounter < mapScriptObjectActions.size()){
            mapPageObjects = relevantObject;
            if (mapPageObjects.size() == 0) {
                System.out.println("Page driver Initialization failed, Couldn't load /find controls, Objects.Size-: " + mapPageObjects.size());
                System.out.println("Page driver Initialization failed, Couldn't load /find controls, Objects.Size-: " + mapPageObjects.size());


                //do a http call to change test script status as -1(failed)(api/smartprobe/updatestatus)
                System.out.println("Received invaild xpath from user so terminating the execution");

            }
            //}

            //remove later // just for testing
            String PossibleObjectIdentifier = step.getFieldValue();

            //important step
            possibleActionableControls.clear();

            if (step.getFieldValue().contains("id{") && !step.getTestData().toUpperCase().equals("verify")) {
                String xPath = step.getFieldValue().substring(step.getFieldValue().indexOf("id{") + 3, step.getFieldValue().length() - 1);
                objPOSelected = getWebElementFromXpath(driver, xPath, mainWindow);
                if (objPOSelected != null) {
                    objPOSelected.xPath = xPath;
                    objPOSelected.RawPageObject = true;

                }

            }
            if (Constants.KeyBoardActionVerbs.contains(step.getAction().name().toLowerCase()) || Constants.NoPageScanReqVerbs.contains(step.getFieldValue().replaceAll("\\s", "").toLowerCase()) || step.getAction().name().toLowerCase().equals("clickalert")) {

                int iRetVal = 999;
                String functionName = "";
                if (Constants.KeyBoardAppActionVerbs.contains(step.getTestData().toUpperCase())) {
                    locator = ExecuteWithKeyboardPressKey(step, objPOSelected, driver);
                    iRetVal = locator.getiRetVal();
                    functionName = "ExecuteWithKeyboardPressKey";
                } else if (step.getAction().name().toLowerCase().equals("clickalert")) {
                    iRetVal = ExecuteClickAlertBox(step.getTestData(), driver);
                    functionName = "ExecuteWithKeyboardPressKey";
                } else {
                    iRetVal = ExecuteVerifyCheckWithoutPageObjects(step.getFieldValue(), step.getTestData(), pageChangedFlag, popupLaunchedFlag, driver);
                    functionName = "ExecuteVerifyCheckWithoutPageObjects";
                }

                //int iRetVal = seleProcess.ExecuteWithKeyboardPressKey(ObjectActions.Action, ObjectActions.TestData, objPOSelected.objectElement);
                switch (iRetVal) {

                    case -1:
                        //something wrong with control.
                        //shall we try clicking on another possible controls.
                        break;

                    case 1:


                        //how to pass below two
//                            mapScriptObjectActions.get(TestStepSeqID).Action,
//                            objBufferPageObject.VisisbleText,
                        possibleActionableControls.clear();
                        pageChangedFlag = false;
                        popupLaunchedFlag = false;
                        break;

                    case 2:
                        //page changed
                        //we may need to find all control again for executing next actions

                        //update PO control name
                        //this function is slightly different than others

                        //reload all Controls again
                        //if(testCaseCounter<mapScriptObjectActions.size())
                        //mapPageObjectsOrg = seleProcess.FindRelvantControlOnPage(ObjectActions, false);
                        possibleActionableControls.clear();
                        pageChangedFlag = true;
                        break;
                    case 3:
                        //popup launched
                        //we may need to find all control again for executing next actions

                        //update PO control name
                        //this function is slightly different than others

                        //reload all Controls again
                        //if(testCaseCounter<mapScriptObjectActions.size())
                        //mapPageObjectsOrg = seleProcess.FindRelvantControlOnPage(ObjectActions, false);
                        possibleActionableControls.clear();
                        popupLaunchedFlag = true;
                        break;
                }
                if (iRetVal >= 1) {
                    //send screenshot
                    //Add a logic to handle the user xpath flow
                    throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                }


            }
            CommonGUIFunctions objCommonGUI = new CommonGUIFunctions();
            if (!step.getFieldValue().contains("id{")) {
                objPOSelected = null;
                // 0 = no match
                // 1 = level > 0
                // 2 = level > 1
                // 3 = level > 2
                //and likewise. consider that control with highest matchlevel to perform action.
                //store mapPAgeObject to buffer
                //somewhere it is getting cleared - review this.
                //filter mapPageObjects for test case where data needs to be entered.
                //hence remove non-editable elements from mapPageObjects
                if (!(step.getTestData().isEmpty())) {
                    Map<String, PageObject> tempMapPO = new HashMap<>();
                    tempMapPO.putAll(mapPageObjects);
                    for (Map.Entry<String, PageObject> entryPO : tempMapPO.entrySet()) {
                        String PoID = entryPO.getKey();
                        PageObject PO = entryPO.getValue();
                        if (setDontscanfordataentry.contains(PO.ObjectType)) {
                            mapPageObjects.remove(PoID);
                        }
                    }
                    tempMapPO.clear();
                }

                Map<String, PageObject> mapBufferedPageObejcts = new HashMap<String, PageObject>();
                mapBufferedPageObejcts.putAll(mapPageObjects);


                //level 0 search with AOStar
                possibleActionableControls = aoStar.AOstarLevelZero(
                        mapPageObjectsSearchByLinkText,
                        PossibleObjectIdentifier, driver);
                boolean zeroLevel = true; //ARP Changes
                System.out.println(">>>>> Identified controls from Lvl0(linktext): " + possibleActionableControls.size());

                if (possibleActionableControls.size() == 1 && !step.getAction().name().equalsIgnoreCase("verify")
                        && !step.getAction().name().equalsIgnoreCase("mousehover") &&
                        !StringUtils.contains(step.getAction().name(), "Wait")) {
                    PageObject objBufferPageObject = possibleActionableControls.iterator().next();
                    storedObjAttributes = FindAllAttributes(objBufferPageObject, driver);
                    locator = ExecuteWithDirectLinkFind(step.getAction().name(), step.getTestData(), objBufferPageObject, driver, step);
                    int iRetVal = locator.getiRetVal();
                    switch (iRetVal) {

                        case -1:
                            //something wrong with control.
                            //shall we try clicking on another possible controls.
                            break;
                        case 0:

                            break;

                        case 1:

                            //how to pass below two
//                            mapScriptObjectActions.get(TestStepSeqID).Action,
//                            objBufferPageObject.VisisbleText,
                            possibleActionableControls.clear();
                            pageChangedFlag = false;
                            popupLaunchedFlag = false;
                            break;

                        case 2:
                            //page changed
                            //we may need to find all control again for executing next actions

                            //update PO control name
                            //this function is slightly different than others

                            //reload all Controls again
                            //if(testCaseCounter<mapScriptObjectActions.size())
                            //mapPageObjectsOrg = seleProcess.FindRelvantControlOnPage(ObjectActions, false);
                            possibleActionableControls.clear();
                            pageChangedFlag = true;
                            break;
                        case 3:
                            //popup launched
                            //we may need to find all control again for executing next actions

                            //update PO control name
                            //this function is slightly different than others

                            //reload all Controls again
                            //if(testCaseCounter<mapScriptObjectActions.size())
                            //mapPageObjectsOrg = seleProcess.FindRelvantControlOnPage(ObjectActions, false);
                            possibleActionableControls.clear();
                            popupLaunchedFlag = true;
                            break;
                    }
                    if(locator.getValue() != null){
                        step.setLocator(locator);
                        step = Utils.getScreenshot(driver, step);
                        responseDTO.setExecutedStep(step);
                        return responseDTO;
                    }
                    /*if (iRetVal >= 1) {
                        //send screenshot
                        //Add a logic to handle the user xpath flow
                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                    }*/

                }

                //if zero/more than 1 href/link found, then leave it try to search by only display
                // name across ALL actionable objects
                possibleActionableControls = aoStar.AOstarLevelZero(
                        mapPageObjects,
                        PossibleObjectIdentifier, driver);
                zeroLevel = true; //ARP Changes
                System.out.println(">>>>> Identified Controls from Lvl0: " + possibleActionableControls.size());

                //level 1 search with AOStar
                if (possibleActionableControls.size() < 1) {
                    possibleActionableControls = aoStar.AOstarLevelOne(
                            mapPageObjects,
                            PossibleObjectIdentifier, step.getTestData());
                    zeroLevel = false;
                    System.out.println(">>>>> Identified controls from Lvl1: " + possibleActionableControls.size());
                }

                if (possibleActionableControls.size() < 1) {

                    //level 2 search with AOStar
                    //if not found then only  search in wordnet
                    possibleActionableControls = aoStar.AOstarLevelTwo(
                            mapPageObjects,
                            PossibleObjectIdentifier);
                    System.out.println(">>>>> Identified controls from Lvl2: " + possibleActionableControls.size());
                }

                if (possibleActionableControls.size() < 1) {
                    Map<String, PageObject> mapInvisiblePageObjects = new HashMap<>();

                    possibleActionableControls = aoStar.AOstarLevelThree(
                            mapPageObjects,
                            PossibleObjectIdentifier,
                            step.getTestData(),
                            mapInvisiblePageObjects);
                    System.out.println(">>>>> Identified controls from Lvl3: " + possibleActionableControls.size());
                }

                String mostAccurateControlObjectId = "";

                //we will try to find if any of these control is editable text box
                //so if given step is of type "enter data" we can pinpoint it instead of asking user to select
                //so first get only text/edit boxes for "enter data" type of test steps
                //and then find match levels
                //but this can be the case for select actions as well where we have test data. so need to skip those controls
                Set<PageObject> possibleActionableControlsFiltered = new HashSet<PageObject>();
                possibleActionableControlsFiltered.addAll(possibleActionableControls);
                if ((!step.getTestData().isEmpty()) && (step.getTestData().length() > 0)) {
                    if (possibleActionableControlsFiltered.size() > 1) {

                        for (PageObject objPO : possibleActionableControlsFiltered) {
                            // if(objPO.objectElement.getTagName().equalsIgnoreCase("input") || objPO.objectElement.getTagName().equalsIgnoreCase("textarea") || objPO.objectElement.getTagName().equalsIgnoreCase("select")||objPO.objectElement.getTagName().equalsIgnoreCase("radio") || objPO.objectElement.getTagName().equalsIgnoreCase("checkbox"))
                            // {
                            boolean bIsEditBox = CheckIfGivenbjectIsEditable(objPO.ObjectId, objPO.bIsIFrameControl,
                                    objPO.iFrameId, objPO.objectElement, step.getTestData(), driver);
                            //other controls are also editable like combo box or checkbox
                            if (bIsEditBox) {
                                //check if
                            }
                            if (!bIsEditBox) {
                                possibleActionableControls.remove(objPO);
                            }
                            //   }
                            //  else
                            //   possibleActionableControls.remove(objPO);

                        }
                    }
                    System.out.println("Filtered controls from editable check: " + possibleActionableControls.size());
                }
                if (zeroLevel == false) { //ARP
                    try {
                        //select objects with highest MatchLEvels
                        //we need object with same matchlevels which is highest
                        possibleActionableControlsFiltered.clear();
                        possibleActionableControlsFiltered = new HashSet<PageObject>();
                        if (possibleActionableControls.size() > 1) {
                            int MaxMatchLevelFound = 0;

                            for (PageObject objPO : possibleActionableControls) {
                                int ObjectMatchLevelFound = aoStar.getControlObjectToMatchLevel().get(objPO.ObjectId);
                                if (ObjectMatchLevelFound >= MaxMatchLevelFound) {
                                    MaxMatchLevelFound = ObjectMatchLevelFound;
                                }
                                //dont add if matchlevel is below than others.
                            }

                            possibleActionableControlsFiltered = new HashSet<PageObject>();
                            for (PageObject objPO : possibleActionableControls) {

                                int ObjectMatchLevelFound = aoStar.getControlObjectToMatchLevel().get(objPO.ObjectId);

                                //add if matchlevel found
                                if (ObjectMatchLevelFound == MaxMatchLevelFound) {
                                    possibleActionableControlsFiltered.add(objPO);
                                }

                                //add if user provided objecttype matches with this control type
                                if (objPO.ObjectType.toLowerCase().equalsIgnoreCase(actor)) {
                                    possibleActionableControlsFiltered.add(objPO);
                                }
                                //dont add if matchlevel is below than others.
                            }

                            possibleActionableControls.clear();
                            possibleActionableControls.addAll(possibleActionableControlsFiltered);
                            possibleActionableControlsFiltered = new HashSet<PageObject>();

                        }

                        //now get no-match level so that if any control has any no match string we can ignore it.
                        //so finally get and keep controls with minimum or ZERO no-match level.
                        if (possibleActionableControls.size() > 1) {

                            int minNoMatchLevelFound = -1;
                            for (PageObject objPO : possibleActionableControls) {

                                int ObjectNoMatchLevelFound = 99999;
                                if (aoStar.getControlObjectToNoMatchLevel().containsKey(objPO.ObjectId)) {
                                    ObjectNoMatchLevelFound = aoStar.getControlObjectToNoMatchLevel().get(objPO.ObjectId);
                                }

                                if (ObjectNoMatchLevelFound <= minNoMatchLevelFound) {
                                    minNoMatchLevelFound = ObjectNoMatchLevelFound;
                                }
                                //dont add if matchlevel is below than others.
                            }

                            for (PageObject objPO : possibleActionableControls) {

                                int ObjectNoMatchLevelFound = 99999;
                                if (aoStar.getControlObjectToNoMatchLevel().containsKey(objPO.ObjectId)) {
                                    ObjectNoMatchLevelFound = aoStar.getControlObjectToNoMatchLevel().get(objPO.ObjectId);
                                }

                                if (ObjectNoMatchLevelFound == minNoMatchLevelFound) {
                                    possibleActionableControlsFiltered.add(objPO);
                                }
                                //dont add if matchlevel is below than others.
                            }
                        }

                        if (possibleActionableControlsFiltered.size() > 0) {
                            possibleActionableControls.clear();
                            possibleActionableControls.addAll(possibleActionableControlsFiltered);

                        }
                        aoStar.setControlObjectToNoMatchLevel(new HashMap<String, Integer>());
                        aoStar.setControlObjectToMatchLevel(new HashMap<String, Integer>());

                        Set<PageObject> setSecondTryObjects = new HashSet<PageObject>();
                        setSecondTryObjects.addAll(possibleActionableControls);

                        possibleActionableControlsFiltered.clear();
                    } catch (Exception ex0) {
                        ex0.printStackTrace();
                    }
                    System.out.println(">>>>> Filtered controls from match lvl: " + possibleActionableControls.size());
                }//ARP

                possibleActionableControlsFiltered.clear();
                //filter the control based on display text as much as possible
                if (possibleActionableControls.size() > 1) {
                    for (PageObject objPO : possibleActionableControls) {
                        boolean bResult = false;
                        try {
//                            bResult = getSynonyms(PossibleObjectIdentifier, objPO.objectElement.getText());
                            if (objPO.ObjectType.equalsIgnoreCase("image")) {

                                //first scan image with 'alt' text
                                //if not found then by iamge-path
                                bResult = NLPSupport.getSynonyms(PossibleObjectIdentifier, objPO.VisisbleText);
                                if (!bResult) {
                                    String imagePath = objPO.ObjectId.toLowerCase();
                                    if (imagePath.contains("http://")) {
                                        imagePath = imagePath.replaceAll("http://", "");
                                    }
                                    if (imagePath.contains("https://")) {
                                        imagePath = imagePath.replaceAll("https://", "");
                                    }
                                    if (imagePath.contains("/")) {
                                        imagePath = imagePath.replaceAll("/", " ");
                                    }
                                    if (imagePath.contains(".")) {
                                        imagePath = imagePath.replaceAll("-", " ");
                                    }
                                    if (imagePath.contains("_")) {
                                        imagePath = imagePath.replaceAll("_", " ");
                                    }
                                    bResult = NLPSupport.getSynonyms(PossibleObjectIdentifier, imagePath);
                                }
                            } else {
                                bResult = NLPSupport.getSynonyms(PossibleObjectIdentifier, objPO.VisisbleText);
                            }

                        } catch (Exception ex) {
                            System.out.println(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName() + ex.getMessage());
                        }
                        if (bResult) {
                            possibleActionableControlsFiltered.add(objPO);
                            bResult = false;
                        }

                    }
                    System.out.println(">>>>> Filtered controls from display text: " + possibleActionableControls.size());
                }

                //replace if above filtered match found.
                if (possibleActionableControlsFiltered.size() >= 1) {
                    possibleActionableControls.clear();
                    possibleActionableControls.addAll(possibleActionableControlsFiltered);

                }

                //remove those elements for which action already taken
                possibleActionableControlsFiltered.clear();

                if (possibleActionableControls.size() > 1) {
                    for (PageObject objPO : possibleActionableControls) {
                        /** getMapAlreadyExecutedObjectOnGivenPAge is updating in SeleniumProcess class
                         * but this was refering to this local instance, which is of no use
                         * so getting the value from seleProcess and checked */
                        boolean bResult = mapAlreadyExecutedObjectOnGivenPAge.containsKey(objPO.ObjectId);
                        //if action already taken , it may be control which needs to repeatadly accessed.
                        //or if its CSS then control-ID may repeat.
                        //so don't omit such controls which are repeatadly accessed.
                        //just search for control for which there is one test step with some Test-Data is attached.
                        //so basically search of text boxes with some 'test-data' aleready entered.
                        if (bResult) {
                            //check if this same test-data which smartprobe has entered.
                            String testData = mapAlreadyExecutedObjectOnGivenPAge.get(objPO.ObjectId);
                            // ARP IMP listTestDataUsedTillNow is never added any data however some part of Code is
                            // in SeleniumProcess Class Need to consolidate.

                            //this can be a input-control which is used as button e.g. DT case. hence check for it
                            if (objPO.ObjectType.equalsIgnoreCase("input")
                                    && (testData.isEmpty() || testData.length() <= 0)) {
                                bResult = true;
                            } else {
                                if (listTestDataUsedTillNow.contains(testData)) {
                                    //do nothing
                                    //found that this data is entered by Smartprobe
                                    //don't consider this control
                                    bResult = true;
                                } else {

                                    //add this control
                                    //this may be repeatingly pressed control or others
                                    bResult = false;
                                }
                            }
                        }

                        if (!bResult) {
                            possibleActionableControlsFiltered.add(objPO);
                            bResult = false;
                        }
                    }
                    System.out.println(">>>>> Filtered controls from action already perform check: " + possibleActionableControls.size());
                }

                //replace if above filtered match found.
                if (possibleActionableControlsFiltered.size() >= 1) {
                    possibleActionableControls.clear();
                    possibleActionableControls.addAll(possibleActionableControlsFiltered);

                }

                //if still we have multiple actionable controls search on most accurate match
                //based on display text
                if (possibleActionableControls.size() > 1) {
                    possibleActionableControls = aoStar.AOstarLevelFour(possibleActionableControls, step);
                    System.out.println(">>>>> Filtered controls from lvl4: " + possibleActionableControls.size());
                }

                //if still we have multiple actionable controls search on most accurate match
                //based on test data of teststep and display text
                //this is most suitable when we have dropdown of customer format(where html:select is not used) or checkbox
                if (possibleActionableControls.size() > 1) {
                    possibleActionableControls = aoStar.AOstarLevelFive(possibleActionableControls, step);
                    System.out.println(">>>>> Filtered controls from lvl5: " + possibleActionableControls.size());
                }

                if (possibleActionableControls.size() > 1) {
                    //At this stage we will more than 1 control possibly with matching objects
                    //or
                    //with different objects with same page-functionlity like span-incuded in
                    possibleActionableControls = aoStar.AOstarLevelSix(possibleActionableControls, step);
                    System.out.println(">>>>> Filtered controls from lvl6: " + possibleActionableControls.size());
                }

                if (possibleActionableControls.size() > 1) {
                    //At this stage we will more than 1 control possibly with matching objects names
                    //but both are clickable to perform same actions
                    //here auto-select based on preference level
                    possibleActionableControls = aoStar.AOstarLevelSeven(possibleActionableControls, step);
                    System.out.println(">>>>> Filtered controls from lvl7: " + possibleActionableControls.size());
                }

                objPOSelected = null;
                if (possibleActionableControls.size() == 1) {
                    //we have the control ID object

                    objPOSelected = possibleActionableControls.iterator().next();
                }

                //=========================================================
                //Algorithms complete

                //if we dont get any controls then show all controls to user to select
                if (possibleActionableControls.isEmpty()) {
                    System.out.println("possible actionable controls is empty");

                } //if we get multiple objects
                /***
                 * Need to check with Sharanya
                 */
                    /*else if (possibleActionableControls.size() > 1) {
                        //get control ID from user
                        objPOSelected = objCommonGUI.getUserSelectedControlIDLevelOne(executionID,
                                possibleActionableControls,
                                mRunMode,
                                TestStepHashToControlID,
                                mapScriptObjectActions.get(TestStepSeqID).HashKey,
                                mapScriptObjectActions.get(TestStepSeqID).Action + " "
                                        + mapScriptObjectActions.get(TestStepSeqID).Object_Actor + " "
                                        + mapScriptObjectActions.get(TestStepSeqID).TestData,
                                mapPageObjects);
                        userSlectedSteps++;
                        // if user didn't select option from dropdown rather sent xpath from popup
                        if (!StringUtils.isEmpty(objPOSelected.xPath)) {
                            String xPath = objPOSelected.xPath;
                            if(xPath.equals("cancelled")){
                                getScreenPrint(TestStepSeqID);
                                String strFilePath = seleProcess.SetupFolder();
                                strFilePath = strFilePath + File.separator + "TestStep_" + TestStepSeqID + Constants.SCREENPRINT_FILE_EXTN;
                                spServerObj.sendScreenshots(executionID,TestStepSeqID,listOfTestStep.get(stepCounter-1),"failed",strFilePath);

                                // do http call to change live status as "failed"
                                JSONObject liveStatusObj = new JSONObject();
                                List<String> stringList = new ArrayList<>();
                                liveStatusObj.put("executionId",executionID);
                                liveStatusObj.put("status","failed");
                                liveStatusObj.put("elementList",stringList);
                                restClient.doHttpPost(PROPERTIES.getHost()+Constants.APP_REST_UPDATE_LIVE_STATUS, liveStatusObj.toString());
                                return false;
                            }
                            objPOSelected = seleProcess.getWebElementFromXpath(xPath, mainWindow);
                            //got invaild xpath from user so terminating the execution
                            if(objPOSelected == null){
                                getScreenPrint(TestStepSeqID);
                                String strFilePath = seleProcess.SetupFolder();
                                strFilePath = strFilePath + File.separator + "TestStep_" + TestStepSeqID + Constants.SCREENPRINT_FILE_EXTN;
                                spServerObj.sendScreenshots(executionID,TestStepSeqID,listOfTestStep.get(stepCounter-1),"failed",strFilePath);

                                //do a http call to change test script status as -1(failed)(api/smartprobe/updatestatus)
                                System.out.println("Received invaild xpath from user so terminating the execution");
                                JSONObject overAllStatusObj = new JSONObject();
                                overAllStatusObj.put("executionId",executionID);
                                overAllStatusObj.put("status","-1");
                                restClient.doHttpPost(PROPERTIES.getHost()+Constants.APP_REST_UPDATE_OVERALL_STATUS, overAllStatusObj.toString());

                                // do http call to change live status as "failed"
                                JSONObject liveStatusObj = new JSONObject();
                                List<String> stringList = new ArrayList<>();
                                liveStatusObj.put("executionId",executionID);
                                liveStatusObj.put("status","failed");
                                liveStatusObj.put("elementList",stringList);
                                restClient.doHttpPost(PROPERTIES.getHost()+Constants.APP_REST_UPDATE_LIVE_STATUS, liveStatusObj.toString());
                                return false;
                            }
                        }
                    }*/
//               else if(userInteractionFlag==false)
//                {
//                     getScreenPrint(TestStepSeqID);
//                     String strFilePath = Constants.SCREENSHOT_FILE_PATH + File.separator + "TestStep_" + TestStepSeqID + Constants.SCREENPRINT_FILE_EXTN;
//                     spServerObj.sendScreenshots(executionID,file,listOfTestStep.get(stepCounter),"failed",strFilePath);
//                    return false;
//                }
                //still if this is null
                //this condition may occur if user press ESC or cancel
                if (objPOSelected == null) {
                    if (possibleActionableControls.size() > 1
                            && !objCommonGUI.UserSelectedControlIdetifier.isEmpty()) {

                        byte[] key = "".getBytes();
                        //beacuse hash is generated on original identifier and not the filtered one.
                        key = (objCommonGUI.UserSelectedControlIdetifier.replaceAll("", "()")).getBytes();
                        long iHash = JenkinsHash.hash64(key, 10000);
                        String strhashKey = Long.toString(iHash);
                        UserSelectedObject ControlObject = objCommonGUI.mapMultipleObjects.get(strhashKey);

                        for (PageObject objPO : possibleActionableControls) {
                            objPOSelected = objPO;
                            if (objPO.ObjectId.equalsIgnoreCase(ControlObject.objectId)) {
                                //found selected control.
                                break;
                            }
                        }
                    }
                }

                //after finalizing actual Page obejct
                //final check to is to validate (mainly for clickable object)
                //Display Name of Page-Object with given test step action name
                //i.e. if test step mentioned click on 'checkout'
                //then our selected PageObject(objPO) should have displayName(.getText()) as "checkout"
                //if not then give message accordingly.
                if (objPOSelected != null) {
                    if (objPOSelected.VisisbleText.toLowerCase().equalsIgnoreCase(step.getFieldValue().toLowerCase())) {
                        //all is ok
                        //do nothing
                    } else {
                        if (bOverridedisplaytext) {
                            //do nothing
                            //continue with same object
                        }
                        /**
                         * Handle this with GENAI logic
                         */
                            /*else if (objPOSelected.ObjectType.equalsIgnoreCase("a")
                                    || objPOSelected.ObjectType.equalsIgnoreCase("href")
                                    || objPOSelected.ObjectType.equalsIgnoreCase("div")
                                    || objPOSelected.ObjectType.equalsIgnoreCase("span")
                                    || objPOSelected.ObjectType.equalsIgnoreCase("button")
                                    || objPOSelected.ObjectType.equalsIgnoreCase("image")) {
                                //we may need to add few other control type conditions
                                //give message only in case of clickable object (not in case of textfeilds)
                                String strMessage = "Found Valid Page-Object but display name is not same as mentioned in Test-Step."
                                        + "\n"
                                        + "Control found : " + objPOSelected.ObjectId + "( " + step.getFieldValue() + " )"
                                        + "\n"
                                        + "Click OK Proceed else Cancel";

                                int action = spServerObj.getConfirmation(executionID, strMessage);
                                objPOSelected = null;
                                String userXpath;
                                //we need to ask xpath of control
                                if (iExeMode == 1) {
                                    switch (action) {
                                        case 0:
                                            String xPath = spServerObj.getWebElementXPathForTestStep(executionID, "Could not auto-execute this testStep.\nPlease enter Xpath to continue", Integer.parseInt(TestStepSeqID));
                                            if(xPath.equals("cancelled")){
                                                return false;
                                            }
                                            objPOSelected = seleProcess.getWebElementFromXpath(xPath, mainWindow);
                                            break;
                                        case 1://do nothing , continue next step
                                            break;
                                        case 2:
                                            TerminateExecution();
                                            break;
                                    }
                                } else if (action == JOptionPane.CANCEL_OPTION) {
                                    userXpath = JOptionPane.showInputDialog(null, "Could not auto-execute this testStep.\nPlease enter Xpath to continue");

                                    // Currently we are considering for Click we need to check what type of Step  - Data enter or Click etc
                                    if ((userXpath != null) && (!userXpath.isEmpty())) {
                                        seleProcess.ExecuteClick(userXpath, false, "", false, "");
                                    } else {
                                        return false;
                                    }
                                }

                            }*/ //it means this possible input field then check if there is any testdata
                        else {
                            if (objPOSelected.ObjectType.equalsIgnoreCase("input")
                                    && step.getTestData().isEmpty()) {
                                //it means 'input' type control found but it has no test data.
                                //now check what type of test-action is i.e.
                                //if action is 'Enter ..----... as ..test-data.. ' and test-data is blank then this is error-case
                                //if action is 'click on ..----..' then this is valid case.
                                String testAction = step.getAction().name().toLowerCase();
                                if (Constants.UserActionWithoutDataVerbs.contains(testAction)) {
                                    //do nothing
                                    //proceed
                                } else {
                                    objPOSelected = null;
                                }
                            } //check the test step - if click or enter data
                            //if enter data then remove non-input type objects
                            else if (objPOSelected.ObjectType.equalsIgnoreCase("input")
                                    && !step.getTestData().isEmpty()
                                    && !CheckIfGivenbjectIsEditable(objPOSelected.ObjectId,
                                    objPOSelected.bIsIFrameControl, objPOSelected.iFrameId,
                                    objPOSelected.objectElement, step.getTestData(), driver)) {
                                objPOSelected = null;
                            }
                        }
                    }
                }

            }
            if (objPOSelected != null) {
                try {
                    /**check if ChildWindowControl true
                     * and correspondingly switch to that child window*/
                    //mainWindow = seleProcess.getWindowHandle();
                    if (objPOSelected.bIsChildWindowControl == true &&
                            driver.getWindowHandles().size() > 1) {
                        for (String window : driver.getWindowHandles()) {
                            if (!mainWindow.equalsIgnoreCase(window)) {
                                switchToWindow(window, driver);
                                if (objPOSelected.childWindowTitle.
                                        equalsIgnoreCase(getCurrentPageTitle(driver))) {
                                    break;
                                }
                            }
                        }
                    }
                    //for (PageObject objPO : possibleActionableControls)
                    //found almost accurate control
                    //take action
                    String testAction = step.getAction().name().toLowerCase();
                    if (Constants.AppActionVerbs.contains(testAction.toLowerCase())) {
                        clickedControlID = "";
                        //now check if it's mouse click or entering some user data in input field
                        if (step.getTestData().isEmpty()) {
                            //testdata is empty means it's possible click event
                            //send click event
                            int iRetVal = 9999;
                            String bufferObjectID = "";
                            String functionName = "";
                            String storedObj = FindAllAttributes(objPOSelected, driver);
                            locator = new Locator();
                            if (step.getAction().name().toLowerCase().equalsIgnoreCase("verify")
                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("assertequals")
                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("assertnotequals")
                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("asserttrue")
                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("assertfalse")) {
                                locator = ExecuteAssertVerify(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteAssertVerify";
                            } else if (step.getAction().name().toLowerCase().equalsIgnoreCase("mousehover")) {
                                locator = ExecuteMouseHover(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteMouseHover";
                            } else if (step.getAction().name().toLowerCase().equalsIgnoreCase("rightclick")) {
                                locator = ExecuteRightClick(objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteRightClick";
                            } else if (step.getAction().name().equalsIgnoreCase("doubleclick")) {
                                locator = ExecuteDoubleClick(objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteDoubleClick";
                            } else if (objPOSelected.ObjectType.toLowerCase().equals("image")) {
                                //executeImageClick
                                locator = ExecuteImageClick(objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.imageHref;
                                functionName = "ExecuteImageClick";
                            } else if (objPOSelected.ObjectId.toLowerCase().startsWith("spinputid")) {
                                //this is special case where input control is used to click like button
                                //and not used  for entering data
                                //input with no ID, execute differently.
                                locator = ExecuteInputClickWithoutID(objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteInputClickWithoutID";
                            } else if (objPOSelected.ObjectId.toLowerCase().startsWith("spbuttonid")) {
                                //button with no ID, execute differently.
                                locator = ExecuteButtonClickWithoutID(objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteButtonClickWithoutID";
                            } else if (objPOSelected.ObjectId.toLowerCase().startsWith("sphrefid")) {
                                //dropdown with no ID, execute differently.
                                locator = ExecuteHrefClickWithoutID(objPOSelected,step,storedObj, true, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteHrefClickWithoutID";
                            } else if (objPOSelected.ObjectId.toLowerCase().startsWith("spchkbxid")) { // ARP Changes entire Else loop
                                //possible multiselect checkbox with no ID, execute differently.
                                locator = ExecuteCheckBoxClickWithoutIDEx(objPOSelected, storedObj, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteCheckBoxClickWithoutIDEx";

                                //this also needs to be done for select with ID atrribute present
                            } else if (objPOSelected.ObjectId.toLowerCase().startsWith("spspanid")) { // ARP Changes entire Else loop
                                //found span with no ID, execute differently.
                                locator = ExecuteSpanClickWithoutID(objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteSpanClickWithoutID";

                                //this also needs to be done for select with ID atrribute present
                            } else if (objPOSelected.ObjectId.toLowerCase().startsWith("spdivid")) { // ARP Changes entire Else loop
                                //found span with no ID, execute differently.
                                locator = ExecuteDivClickWithoutID(objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteDivClickWithoutID";

                                //this also needs to be done for select with ID atrribute present
                            } else if (objPOSelected.RawPageObject) {
                                //found object with user provided xPath
                                locator = ExecuteClickWithXpath(objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteClickWithXpath";
                            } else {
                                System.out.println("objPOSelected"+objPOSelected);
                                locator = ExecuteClick(step,objPOSelected.ObjectId,
                                        objPOSelected.bIsIFrameControl, objPOSelected.iFrameId,
                                        objPOSelected.bIsChildWindowControl, objPOSelected.childWindowTitle, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteClick";
                            }

                            switch (iRetVal) {

                                case -1:
                                    //something wrong with control(problem in relating page action into functions).
                                    String xPath = objPOSelected.xPath;
                                    //Ask for xpath from user
                                    objPOSelected = getWebElementFromXpath(driver, xPath, mainWindow);
                                    //got invaild xpath from user so terminating the execution
                                    if (objPOSelected == null) {
                                        //Add a logic to handle the user xpath flow
                                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                                    }
                                    userSlectedSteps++;

                                    if (objPOSelected != null) {
                                        if (Constants.AppActionVerbs.contains(step.getAction().name().toLowerCase()) && objPOSelected.RawPageObject) {
                                            //found object with user provided xPath
                                            if (StringUtils.isEmpty(step.getTestData())) {
                                                locator = ExecuteClickWithXpath(objPOSelected, driver);
                                                bufferObjectID = objPOSelected.ObjectId;
                                                functionName = "ExecuteClickWithXpath";
                                            } else {
                                                locator = SendWordKeysWithXpath(step, objPOSelected, driver);
                                                functionName = "SendWordKeysWithXpath";
                                            }
                                        }
                                    }


                                    possibleActionableControls.clear();
                                    break;
                                case 0:
                                    //update with user clicked data
                                    //update PO control name
                                    //mapPageObjectsOrg = seleProcess.FindRelvantControlOnPage(ObjectActions, true);
                                    possibleActionableControls.clear();

                                    break;

                                case 1:

                                    possibleActionableControls.clear();
                                    pageChangedFlag = false;
                                    popupLaunchedFlag = false;
                                    break;

                                case 2:
                                    //page changed
                                    //we may need to find all control again for executing next actions

                                    //reload all Controls again
                                    //mapPageObjectsOrg = seleProcess.FindRelvantControlOnPage(ObjectActions, false);
                                    possibleActionableControls.clear();
                                    pageChangedFlag = true;
                                    break;
                                case 3:
                                    //popup launched
                                    //we may need to find all control again for executing next actions

                                    //reload all Controls again
                                    //mapPageObjectsOrg = seleProcess.FindRelvantControlOnPage(ObjectActions, false);
                                    possibleActionableControls.clear();
                                    popupLaunchedFlag = true;
                                    break;

                            }

                        }
                        else {
                            //means testdata is not empty
                            //hence try to enter  testdata in given field.
                            System.out.println(">>>>> Executing action with test data: " + step.getTestData());
                            int iRetVal = 9999;
                            String bufferObjectID = "";
                            String functionName = "";
                            String storedObj = FindAllAttributes(objPOSelected, driver);

                            if (step.getAction().name().toLowerCase().equalsIgnoreCase("verify")
                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("assertequals")
                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("assertnotequals")
                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("asserttrue")
                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("assertfalse")) {
                                locator = ExecuteAssertVerify(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteAssertVerify";

                            } else if (step.getAction().name().toLowerCase().equalsIgnoreCase("wait")) {
                                // this is for wait statements
                                locator = ExecuteWait(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                functionName = "ExecuteWait";
                            } else if (step.getAction().name().equalsIgnoreCase("waitforelementtobeclickable")
                                    || step.getAction().name().equalsIgnoreCase("waitforelementtobevisible")
                                    || step.getAction().name().equalsIgnoreCase("waitforelementtobeinvisible")
                                    || step.getAction().name().equalsIgnoreCase("waitforelementtobepresent")
                                    || step.getAction().name().equalsIgnoreCase("waitforalertpresent")) {
                                // this is for wait statements
                                locator = ExecuteWaitWithOptions(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                functionName = "ExecuteWaitWithOptions";
                            } else if (step.getAction().name().equalsIgnoreCase("if")) {
                                //to handle conditions
                                locator = ExecuteConditions(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                functionName = "ExecuteConditions";

                            }else if(step.getAction().equals(Step.stepAction.CLICK)){
                                locator = ExecuteClickWithTestData(step,driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteClickWithTestdata";
                            }else if (objPOSelected.ObjectId.toLowerCase().startsWith("spinputid") || objPOSelected.ObjectId.isEmpty()) {
                                //input with no ID, execute differently.
                                locator = SendWordKeyInputWithoutID(step, objPOSelected, storedObj, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                //functionName = "SendWordKeysWithoutID";
                                functionName = "SendWordKeyInputWithoutID";
                            } else if (objPOSelected.ObjectType.equalsIgnoreCase("dropdown")
                                    && !(objPOSelected.ObjectId.toLowerCase().startsWith("spddid"))) {
                                //dropdown with ID
                                locator = ExecuteDropdownClickWithID(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteDropdownClickWithID";
                            } else if (objPOSelected.ObjectId.toLowerCase().startsWith("spddid")) {
                                //dropdown with no ID, execute differently.
                                locator = ExecuteDropdownClickWithoutID(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteDropdownClickWithoutID";
                            } else if (objPOSelected.ObjectId.toLowerCase().startsWith("spchkbxid")) {

                                //possible multiselect checkbox with no ID, execute differently.
                                locator = ExecuteCheckBoxClickWithoutID(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "ExecuteCheckBoxClickWithoutID";

                                //this also needs to be done for select with ID atrribute present
                            } //                                else if (objPOSelected.ObjectType.toLowerCase().equals("dropdown")&& !objPOSelected.ObjectId.toLowerCase().startsWith("spddid")&& !objPOSelected.ObjectId.toLowerCase().startsWith("spchkbxid")){
                            else if (step.getAction().name().equalsIgnoreCase("SelectFromLookup")) {
                                locator = selectFromLookup(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "SelectFromLookup";

                            } else if (step.getAction().name().equalsIgnoreCase("SwitchToIframe")) {
                                locator = switchToIframe(step, driver);
                                iRetVal = locator.getiRetVal();
                                functionName = "switchToIframe";
                            }
                            else if (objPOSelected.RawPageObject) {
                                //found object with user provided xPath
                                locator = SendWordKeysWithXpath(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "SendWordKeysWithXpath";
                            } else {
                                locator = SendWordKeys(step, objPOSelected, driver);
                                iRetVal = locator.getiRetVal();
                                bufferObjectID = objPOSelected.ObjectId;
                                functionName = "SendWordKeys";
                            }
                            switch (iRetVal) {

                                case 0:
                                    if (locator.getAction().equalsIgnoreCase("verify") ||
                                            locator.getAction().equalsIgnoreCase("assertequals") ||
                                            locator.getAction().equalsIgnoreCase("assertnotequals") ||
                                            locator.getAction().equalsIgnoreCase("asserttrue") ||
                                            locator.getAction().equalsIgnoreCase("assertfalse")
                                    ) {
                                        //Add a logic to handle the user xpath flow
                                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                                    }
                                    break;
                                case -1:
                                    //something wrong with control(problem in relating page action into functions).
                                    String xPath = objPOSelected.xPath;
                                    //Ask for xpath from user
                                    objPOSelected = getWebElementFromXpath(driver, xPath, mainWindow);
                                    //got invaild xpath from user so terminating the execution
                                    if (objPOSelected == null) {
                                        //Add a logic to handle the user xpath flow
                                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                                    }
                                    userSlectedSteps++;

                                    if (objPOSelected != null) {
                                        if (objPOSelected.RawPageObject) {
                                            //found object with user provided xPath
                                            if (StringUtils.isEmpty(step.getTestData())) {
                                                locator = ExecuteClickWithXpath(objPOSelected, driver);
                                                functionName = "ExecuteClickWithXpath";
                                            } else if (step.getAction().name().toLowerCase().equalsIgnoreCase("wait")) {
                                                locator.setType(Types.LocatorType.xpath.name());
                                                locator.setValue(xPath);
                                            } else if (step.getAction().name().toLowerCase().equalsIgnoreCase("verify")
                                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("assertequals")
                                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("assertnotequals")
                                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("asserttrue")
                                                    || step.getAction().name().toLowerCase().equalsIgnoreCase("assertfalse")) {
                                                locator = ExecuteAssertVerifyWithXpath(step, objPOSelected, driver);
                                                functionName = "ExecuteAssertVerifyWithXpath";
                                            } else if (step.getAction().name().toLowerCase().equalsIgnoreCase("select")) {
                                                locator = ExecuteSelectWithXpath(step, objPOSelected, driver);
                                                functionName = "ExecuteSelectWithXpath";
                                            } else {
                                                locator = SendWordKeysWithXpath(step, objPOSelected, driver);
                                                functionName = "SendWordKeysWithXpath";
                                            }
                                        }
                                    }

                                    /**What if user given xpath has any unexpected exception
                                     * and iRetVal is set to 0 or -1, terminate the execution*/
                                    /*if (locator.getiRetVal() == 0 || locator.getiRetVal() == -1) {
                                        //Add a logic to handle the user xpath flow
                                        throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                                    }*/


                                    possibleActionableControls.clear();
                                    //throw new Exception();
                                    break;

                                case 1:
                                    storedObj = "";
                                    storedObj = FindAllAttributes(objPOSelected, driver);
                                    //update PO control name

                                    possibleActionableControls.clear();
                                    pageChangedFlag = false;
                                    popupLaunchedFlag = false;
                                    break;
                                case 2:
                                    //page changed
                                    //we may need to find all control again for executing next actions
                                    storedObj = "";
                                    storedObj = FindAllAttributes(objPOSelected, driver);
                                    //update PO control name

                                    //reload all Controls again
                                    //mapPageObjectsOrg = seleProcess.FindRelvantControlOnPage(ObjectActions, false);
                                    possibleActionableControls.clear();
                                    pageChangedFlag = true;
                                    break;
                                case 3:
                                    //popup launched
                                    //we may need to find all control again for executing next actions

                                    //update PO control name

                                    //reload all Controls again as i can be option button
                                    //mapPageObjectsOrg = seleProcess.FindRelvantControlOnPage(ObjectActions, false);
                                    possibleActionableControls.clear();
                                    popupLaunchedFlag = true;
                                    break;
                            }

                        }
                    }

                } catch(LocatorNotFoundException lne){
                    throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                }catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else {
                System.out.println("No control found (8653-objPOSelected) for this test step-> " +"Action:"+step.getAction().name() +" Testdata: "+ step.getFieldValue());
                try {
                    if(step.getAction().equals(Step.stepAction.CLICK) && !step.getTestData().isEmpty()){
                        System.out.println("Seperate Else codt -Testdata is not empty and action is click");
                        locator = ExecuteClickWithTestData(step,driver);
                        int iRetVal = locator.getiRetVal();
                        String bufferObjectID = "";
                        String functionName = "ExecuteClickWithTestData";
                    }else if (step.getAction().name().equalsIgnoreCase(Step.stepAction.VERIFY.name()) ||
                            step.getAction().name().equalsIgnoreCase(Step.stepAction.ASSERTEQUALS.name()) ||
                            step.getAction().name().equalsIgnoreCase(Step.stepAction.ASSERTNOTEQUALS.name()) ||
                            step.getAction().name().equalsIgnoreCase(Step.stepAction.ASSERTTRUE.name()) ||
                            step.getAction().name().equalsIgnoreCase(Step.stepAction.ASSERTFALSE.name())
                    ) {
                        System.out.println("8699");
                        locator = ExecuteAssertVerify(step, objPOSelected, driver);
                    }
                    else{
                        System.out.println("Locator not found So checking whether there is shadow DOM present in the page");
                        locator = handleShadowDom(step, driver);
                    }
                } catch (Exception e) {
                    throw new LocatorNotFoundException(Constants.LOCATOR_NOT_FOUND);
                }
            }

            //after taking screenshot switch back to main window
            if (objPOSelected != null) {
                if (objPOSelected.bIsChildWindowControl) {
                    switchToWindow(mainWindow, driver);
                }
            }

            step.setLocator(locator);
            step = Utils.getScreenshot(driver, step);

            responseDTO.setExecutedStep(step);

        } catch (LocatorNotFoundException lne){
            responseDTO.setResponse(Constants.LOCATOR_NOT_FOUND);
            step = Utils.getScreenshot(driver, step);
            responseDTO.setExecutedStep(step);
            return responseDTO;
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return responseDTO;
    }

    private void clearInput(WebDriver driver, WebElement element) {
        try {
            // Check if field has visible value or content
            String tagName = element.getTagName();
            String value = "";

            if (tagName.equalsIgnoreCase("input") || tagName.equalsIgnoreCase("textarea")) {
                value = element.getAttribute("value");
            } else if (Boolean.parseBoolean(element.getAttribute("contenteditable"))) {
                value = element.getText();
            }

            // Attempt 1: Native clear()
            try {
                element.clear();
            } catch (Exception e) {
                // Skip to next method if clear fails
            }

            // Check if it's still not cleared
            if (!getCurrentValue(element).isEmpty()) {
                // Attempt 2: CTRL+A + DELETE
                try {
                    element.sendKeys(Keys.CONTROL + "a");
                    element.sendKeys(Keys.DELETE);
                } catch (Exception e) {
                    // Continue
                }
            }

            // Check again
            if (!getCurrentValue(element).isEmpty()) {
                // Attempt 3: JavaScript (for both input and contenteditable)
                JavascriptExecutor js = (JavascriptExecutor) driver;

                if (Boolean.parseBoolean(element.getAttribute("contenteditable"))) {
                    js.executeScript("arguments[0].innerHTML = '';", element);
                } else {
                    js.executeScript("arguments[0].value = '';", element);
                }
            }
        } catch (Exception e) {
            System.err.println("Error clearing input: " + e.getMessage());
        }
    }

    private String getCurrentValue(WebElement element) {
        String tagName = element.getTagName();
        if (tagName.equalsIgnoreCase("input") || tagName.equalsIgnoreCase("textarea")) {
            return element.getAttribute("value");
        } else if (Boolean.parseBoolean(element.getAttribute("contenteditable"))) {
            return element.getText();
        }
        return "";
    }
    private Locator handleShadowDom(Step step, WebDriver driver) throws Exception {
        System.out.println("Handling shadow DOM for step: "+step.getAction().name().toLowerCase()+"-"+ step.getFieldValue());
        String fieldValue = step.getFieldValue();
        String testData = step.getTestData();
        String action = step.getAction().name().toLowerCase();
        Locator loc = new Locator();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        List<SearchContext> contexts = new ArrayList<>();

// Store shadow host → shadow root mapping for logging
        Map<SearchContext, WebElement> shadowRootToHost = new HashMap<>();

// Step 1: Top-level shadow hosts
        List<WebElement> topShadowHosts = (List<WebElement>) js.executeScript(
                "return Array.from(document.querySelectorAll('*')).filter(el => el.shadowRoot != null);"
        );
        System.out.println("Top-level shadow hosts found: " + topShadowHosts.size());
        contexts.addAll(topShadowHosts);

        int i = 0;
        int shadowHostCounter = 0;
        while (i < contexts.size()) {
            SearchContext context = contexts.get(i++);
            shadowHostCounter++;

            WebElement currentHost = null;

            try {
                // Try to treat context as a shadow host
                WebElement host = (WebElement) context;
                currentHost = host;
                System.out.println("→ Entering Shadow Host #" + shadowHostCounter + ": <" + host.getTagName() + ">");

                try {
                    SearchContext shadowRoot = host.getShadowRoot();
                    System.out.println("  ✓ Accessed shadowRoot of <" + host.getTagName() + ">");
                    contexts.add(shadowRoot);
                    shadowRootToHost.put(shadowRoot, host); // map root to host

                    // Get nested shadow hosts
                    List<WebElement> nestedShadowHosts = (List<WebElement>) js.executeScript(
                            "return Array.from(arguments[0].querySelectorAll('*')).filter(el => el.shadowRoot != null);",
                            shadowRoot
                    );
                    System.out.println("  ↳ Nested shadow hosts found: " + nestedShadowHosts.size());
                    contexts.addAll(nestedShadowHosts);
                } catch (Exception e) {
                    System.out.println("  ✗ Failed to access shadowRoot: " + e.getMessage());
                }
            } catch (ClassCastException e) {
                currentHost = shadowRootToHost.get(context);
                System.out.println("→ Searching in shadowRoot context"
                        + (currentHost != null ? " of <" + currentHost.getTagName() + ">" : ""));
            }

            // Step 2: Try all locators
            List<By> locators = new ArrayList<>();
            locators.add(By.id(fieldValue));
            locators.add(By.name(fieldValue));
            locators.add(By.linkText(fieldValue));
            locators.add(By.partialLinkText(fieldValue));
            if (!fieldValue.contains(" ")) {
                locators.add(By.className(fieldValue));
            }
            locators.add(By.cssSelector(fieldValue));
            locators.add(By.xpath("//*[text()='" + fieldValue + "']"));
            for (By locator : locators) {
                List<WebElement> elements;
                try {
                    elements = context.findElements(locator);
                } catch (Exception e) {
                    continue;
                }
//                System.out.println("  🔍 Trying locator: " + locator);
                if (!elements.isEmpty()) {
                    WebElement element = elements.get(0);
                    System.out.println("✅ Element found using: " + locator);
                    if (currentHost != null) {
                        System.out.println("🔎 Element is inside shadowRoot of <" + currentHost.getTagName() + ">");
                    }
                    try {
                        if ("click".equalsIgnoreCase(action)) {
                            element.click();
                            System.out.println("✔️ Clicked the element");
                        } else if ("sendkeys".equalsIgnoreCase(action)) {
                            element.sendKeys(testData);
                            System.out.println("✔️ Sent keys: " + testData);
                        }
                    } catch (Exception e) {
                        System.out.println("⚠️  Action failed: " + e.getMessage());
                    }
                    return loc; // stop after finding the element
                }
            }
        }
        System.out.println("❌ Element not found for fieldValue: " + fieldValue);
        if (loc.getAction() == null) {
            loc.setiRetVal(-1);
        } else {
            loc.setiRetVal(0);
        }
        return loc;
    }

}
