package com.cognizant.scanner.model;

public class Step {

    public enum stepAction{
        CLICK, ENTER, LAUNCH, EXIT, WAIT,
        SWITCHTOIFRAME, SELECT, NAVIGATE, GOTO, LOAD, RETYPE, REENTER,
        CONFIRM, TYPE, CHOOSE, CHECK, UNCHECK, DOUBLECLICK ,RIGHTCLICK,
        VERIFY,MOUSEHOVER, WAITFORELEMENTTOBECLICKABLE,
        WAITFORELEMENTTOBEVISIBLE, WAITFORELEMENTTOBEINVISIBLE,
        WAITFORELEMENTTOBEPRESENT, WAITFORALERTPRESENT, SENDKEYS, IF,ASSERTEQUALS,
        ASSERTNOTEQUALS,ASSERTTRUE,ASSERTFALSE, SELECTFROMLOOKUP, PRESSKEY


    }

    private int no;

    private String description;

    private stepAction action;

    private String fieldValue;

    private String testData;

    private String jobID;

    private String screenShot;

    private Locator locator;

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public stepAction getAction() {
        return action;
    }

    public void setAction(stepAction action) {
        this.action = action;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

    public String getTestData() {
        return testData;
    }

    public void setTestData(String testData) {
        this.testData = testData;
    }

    public String getJobID() {
        return jobID;
    }

    public void setJobID(String jobID) {
        this.jobID = jobID;
    }

    public String getScreenShot() {
        return screenShot;
    }

    public void setScreenShot(String screenShot) {
        this.screenShot = screenShot;
    }

    public Locator getLocator() {
        return locator;
    }

    public void setLocator(Locator locator) {
        this.locator = locator;
    }
}
