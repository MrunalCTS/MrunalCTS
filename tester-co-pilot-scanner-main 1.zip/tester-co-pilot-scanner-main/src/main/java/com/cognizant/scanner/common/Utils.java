package com.cognizant.scanner.common;

import com.cognizant.scanner.model.*;
import com.cognizant.scanner.selenium.*;
import org.apache.commons.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.devtools.*;
import org.openqa.selenium.devtools.v134.page.*;
import org.openqa.selenium.support.ui.*;
import org.springframework.stereotype.*;

import javax.imageio.*;
import java.awt.image.*;
import java.io.*;
import java.time.*;
import java.util.*;

@Service
public class Utils {

    public static Step getScreenshot(WebDriver driver, Step step) {
        try {

            Utils.waitForPageLoad(driver);

            //JavascriptExecutor js = (JavascriptExecutor) driver;

            // Set zoom to 90%
            //js.executeScript("document.body.style.zoom='80%'");

            DevTools devTools = ((ChromeDriver)driver).getDevTools();
            devTools.createSession();

            // Enable the Page domain
            devTools.send(Page.enable());

            // Capture full-page screenshot as Base64
            String base64Screenshot = devTools.send(
                    Page.captureScreenshot(
                            Optional.of(Page.CaptureScreenshotFormat.PNG), // or JPEG
                            Optional.empty(),
                            Optional.empty(),
                            Optional.empty(),
                            Optional.of(true), // quality (for JPEG)
                            Optional.of(false)
                    )
            );

            step.setScreenShot(base64Screenshot);

            //js.executeScript("document.body.style.zoom='100%'");

            return step;

        } catch (Exception ex) {
            //log.info(getClass().getName() + "." + Thread.currentThread().getStackTrace()[1].getMethodName());
        }

        return step;
    }

    public static void waitForPageLoad(WebDriver driver) throws InterruptedException {
        Thread.sleep(5000);
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String readyState = jsExecutor.executeScript("return document.readyState").toString();

        if (readyState.equals("complete")) {
            System.out.println("Page fully loaded!");
        } else {
            Utils.waitForPageLoad(driver);
        }
    }

}
