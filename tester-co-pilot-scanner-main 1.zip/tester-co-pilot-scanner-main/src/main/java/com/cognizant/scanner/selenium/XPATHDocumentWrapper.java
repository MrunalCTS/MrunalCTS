package com.cognizant.scanner.selenium;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.Jsoup;
import org.jsoup.helper.W3CDom;
import org.openqa.selenium.WebDriver;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

class XPATHDocumentWrapper {

        Map<String, Node> xpathIDToNodeMap = new LinkedHashMap();
        Map<Node, String> nodeToXPATHIDMap = new LinkedHashMap();

        public XPATHDocumentWrapper(String webURL, WebDriver driver) {

            try {
                org.jsoup.nodes.Document jsoupDoc = null;
                try {
                    jsoupDoc = Jsoup.connect(webURL).get();
                } catch (Exception e) {
                    e.printStackTrace();
                }

//                org.w3c.dom.Document w3cDoc= DOMBuilder.jsoup2DOM(jsoupDoc);
                //String pageSource = driver.getPageSource();
                W3CDom w3cDom = new W3CDom();
                org.w3c.dom.Document w3cDoc = w3cDom.fromJsoup(jsoupDoc);
                NodeList nList = w3cDoc.getElementsByTagName("html");
                Node htmlNode = nList.item(0);
                iterateThroughChildren(htmlNode, "/html");
                
                //just print map
        System.out.println("printing XPATHs---------");
        for (Map.Entry<Node, String> entry : nodeToXPATHIDMap.entrySet()) {
            System.out.println(entry.getKey() + " ----> " + entry.getValue());
        }
        System.out.println("printing XPATHs complete---------");
                
            } catch (Exception ex) {
                Logger.getLogger(XPATHDriverWrapper.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        private void iterateThroughChildren(Node parentNode, String parentXPATH) {
            Map siblingCountMap = new LinkedHashMap();

            NodeList childNodes = parentNode.getChildNodes();
            for (int i = 0; i < childNodes.getLength(); i++) {
                Node childNode = childNodes.item(i);
                String childTag = childNode.getNodeName();
                String childXPATH = constructXPATH(parentXPATH, siblingCountMap, childTag);
                xpathIDToNodeMap.put(childXPATH, childNode);
                nodeToXPATHIDMap.put(childNode, childXPATH);
                iterateThroughChildren(childNode, childXPATH);
//			System.out.println("childXPATH:"+childXPATH);
            }
        }

        public Node findNodeFromXPATHID(String xpathID) {
            return xpathIDToNodeMap.get(xpathID);
        }

        public String findXPATHIDFromNode(Node node) {
            return nodeToXPATHIDMap.get(node);
        }

        private String constructXPATH(String parentXPATH,
                Map siblingCountMap, String childTag) {
            Integer count = (Integer) siblingCountMap.get(childTag);
            if (count == null) {
                count = 1;
            } else {
                count = count + 1;
            }
            siblingCountMap.put(childTag, count);
            String childXPATH = parentXPATH + "/" + childTag + "[" + count + "]";
            return childXPATH;
        }

    }
