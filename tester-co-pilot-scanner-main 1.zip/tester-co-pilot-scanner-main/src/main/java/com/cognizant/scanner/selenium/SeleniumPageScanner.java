package com.cognizant.scanner.selenium;

//import com.SmartProbeAgent.Publish.ServerSendData;
import com.cognizant.scanner.common.Constants;
import com.cognizant.scanner.common.Util;
import com.google.common.base.Strings;
import java.io.File;
import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.*;
import org.springframework.util.StringUtils;

//class to scan all relevant elements on given page
@Service
public class SeleniumPageScanner {

    //private ServerSendData serverlogSender = null;
    private Map<String, PageObject> mapInvisiblePageObjects = new HashMap<String, PageObject>();
    private Map<String, PageObject> mapPageDivs = new HashMap<String, PageObject>();
    Map<String, PageObject> mapPageObjectsSearchByLinkText = new HashMap<String, PageObject>();

    String filename = Util.getCurrentDir() + File.separator + Constants.ROBOT_PROPERTIES;
     Properties propMap = new Properties();

    /*public SeleniumPageScanner(ServerSendData _serverlogSender,
            WebDriver _driver) {
        serverlogSender = _serverlogSender;
        driver = _driver;
    }*/

    public SeleniumPageScanner() {
    }

    public Map<String, PageObject> getInvisiblePageObjects() {
        return mapInvisiblePageObjects;
    }

    public Map<String, PageObject> getPageDivs() {
        if (mapPageDivs != null) {
            return mapPageDivs;
        } else {
            return new HashMap<String, PageObject>();
        }
    }

    public Map<String, PageObject> getSearchedTextLinks() {
        if (mapPageObjectsSearchByLinkText != null) {
            return mapPageObjectsSearchByLinkText;
        } else {
            return new HashMap<String, PageObject>();
        }
    }

    public Map<String, PageObject> getAllAnchorElements(boolean bIsIframeControl, String iFrameID,
                                                        boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllAnchorElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

    public Map<String, PageObject> getAllInputElements(boolean bIsIframeControl, String iFrameID,
                                                       boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllInputElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

    public Map<String, PageObject> getAllImageElements(boolean bIsIframeControl, String iFrameID,
                                                       boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllImageElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

    public Map<String, PageObject> getAllButtonElements(boolean bIsIframeControl, String iFrameID,
                                                        boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllButtonElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

    public Map<String, PageObject> getAllSpanElements(boolean bIsIframeControl, String iFrameID,
                                                      boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllSpanElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

    public Map<String, PageObject> getAllDivElements(boolean bIsIframeControl, String iFrameID,
                                                     boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllDivElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

    public Map<String, PageObject> getAllIconElements(boolean bIsIframeControl, String iFrameID,
                                                      boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllIconElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

    public Map<String, PageObject> getAllLabelElements(boolean bIsIframeControl, String iFrameID,
                                                       boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllLabelElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

    public Map<String, PageObject> getAllSelectElements(boolean bIsIframeControl, String iFrameID,
                                                        boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllSelectElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

    public Map<String, PageObject> getAllRadiosElements(boolean bIsIframeControl, String iFrameID,
                                                        boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        return getAllRadiosElementsPImpl(bIsIframeControl, iFrameID, bIsWindowControl, windowTitle, driver);
    }

//    public Map<String, PageObject> getAllAnchorElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllAnchorElementsPImpl(bIsIframeControl, iFrameID);
//    }
//
//    public Map<String, PageObject> getAllInputElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllInputElementsPImpl(bIsIframeControl, iFrameID);
//    }
//
//    public Map<String, PageObject> getAllImageElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllImageElementsPImpl(bIsIframeControl, iFrameID);
//    }
//
//    public Map<String, PageObject> getAllButtonElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllButtonElementsPImpl(bIsIframeControl, iFrameID);
//    }
//
//    public Map<String, PageObject> getAllSpanElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllSpanElementsPImpl(bIsIframeControl, iFrameID);
//    }
//
//    public Map<String, PageObject> getAllDivElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllDivElementsPImpl(bIsIframeControl, iFrameID);
//    }
//
//    public Map<String, PageObject> getAllIconElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllIconElementsPImpl(bIsIframeControl, iFrameID);
//    }
//
//    public Map<String, PageObject> getAllLabelElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllLabelElementsPImpl(bIsIframeControl, iFrameID);
//    }
//
//    public Map<String, PageObject> getAllSelectElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllSelectElementsPImpl(bIsIframeControl, iFrameID);
//    }
//
//    public Map<String, PageObject> getAllRadiosElements(boolean bIsIframeControl, String iFrameID) {
//        return getAllRadiosElementsPImpl(bIsIframeControl, iFrameID);
//    }

    public static String getVisisbleTextOfWebElement(WebElement element) {
        return getVisisbleTextOfWebElementPImpl(element);
    }

    private Map<String, PageObject> getAllAnchorElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                              boolean bIsWindowControl, String windowTitle, WebDriver driver ) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        try {
            List<WebElement> allLinks = driver.findElements(By.tagName("a"));
            mapInvisiblePageObjects.clear();
            for (WebElement link : allLinks) {
                //System.out.printf("\r%s", iElemtnCounter++);
                //System.out.flush();
                //print the links texts and links

                if (!(link.getAttribute("id").isEmpty())) {
                    if (link.isDisplayed()) {
                        if (ExpectedConditions.elementToBeClickable(link) != null) {
                            //this is only href which are associated with actions or links
                            mapPageElements.put(link.getAttribute("id"), new PageObject(
                                    0, link.getAttribute("id"), "href",
                                    link.getText(), link, bIsIframeControl, iFrameID, "",
                                    bIsWindowControl, windowTitle));
                        }
                    } else {
                        //invisible objects
                        //mapInvisiblePageObjects.put(link.getAttribute("id"), new PageObject(0, link.getAttribute("id"), "href", link.getText(), link, bIsIframeControl, iFrameID, ""));
                        mapInvisiblePageObjects.put(link.getAttribute("id"),
                                new PageObject(0, link.getAttribute("id"), "href",
                                        link.getText(), link, bIsIframeControl,iFrameID, "",
                                        bIsWindowControl, windowTitle));
                    }

                } else if ((!link.getText().isEmpty())) {
                    //link ID is empty
                    //control ID is Empty but link-text is not empty
                    //so inorder to search based on By.linktext() we need to store those controls
                    String hrefID = "sphrefid" + "_$_";
                    try {
                        hrefID += link.getAttribute("href") + "_$_";
                    } catch (Exception ex) {
                        hrefID += "null_$_";
                    }
                    try {
                        hrefID += link.getAttribute("class") + "_$_";
                    } catch (Exception ex) {
                        hrefID += "null_$_";
                    }
                    try {
                        hrefID += link.getAttribute("rel") + "_$_";
                    } catch (Exception ex) {
                        hrefID += "null_$_";
                    }
                    try {
                        //                        Get the visible innertext of the element
                        hrefID += link.getText() + "_$_";
                    } catch (Exception ex) {
                        hrefID += "null_$_";
                    }
                    // ARP Added UUID to avoid Duplicate object Ids
                    try {
                        String uuid = UUID.randomUUID().toString().replace("-", "");
                        hrefID += uuid + "_$_";
                    } catch (Exception ex) {
                        hrefID += "uuidFail_$_";
                    }
                    mapPageElements.put(hrefID,
                            new PageObject(0, hrefID, "href",
                                    link.getText(), link, bIsIframeControl,
                                    iFrameID, "", bIsWindowControl, windowTitle));

                    mapPageObjectsSearchByLinkText.put(UUID.randomUUID().toString(),
                            new PageObject(0, hrefID, "href",
                                    link.getText(), link,
                                    bIsIframeControl, iFrameID, "",
                                    bIsWindowControl, windowTitle));
                }
                //add any other condition
                // else {
                //
                //     }
            }
            SendDisplayLogToClient("Actionable links found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllInputElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                             boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        String[] inputTypes = {"text", "email", "password", "number", "search", "tel", "url"};
        List<String> inputTypesList = Arrays.asList(inputTypes);
        String inputType = "";
        String visibletext = "";
        try {
            List<WebElement> inputs = driver.findElements(By.tagName("input"));
            inputs.addAll(driver.findElements(By.tagName("textarea")));
            for (WebElement input : inputs) {
                try{
                    input.click();
                }catch (Exception e){

                }
                //print the links texts and links
                if (input.isDisplayed()) {
                    //input element can be anything
                    //text
                    //checkbox
                    //radio
                    //what else
                    //so get class and check
//                    String[] inputTypes = {"text", "email", "password", "number", "search", "tel", "url"};
//                    List<String> inputTypesList = Arrays.asList(inputTypes);
//                    String inputType = input.getAttribute("type");
////                    String visibletext = input.getText();
//                    String visibletext = "";
                    /**adding this condition here,
                     * to avoid the text field(text,email, password, etc.. as above array) value in the page object
                     * identified this in the defect IA32 reported
                     * due to the test data/text field value, the conditions in level 1 & 5 gets satisfied, which is NOT expected
                     * spinputid_$_text_$__$_password_$__$_
                     * spinputid_$_text_$__$_password_$_Nthg@1234_$_ */
                    if(!(inputTypesList.contains(inputType))) {
                        visibletext = input.getText();
                        if(StringUtils.isEmpty(visibletext))
                            visibletext = input.getAttribute("value");
                        if(StringUtils.isEmpty(visibletext))
                            visibletext = input.getAttribute("title");
                    }
//                    WebElement element = input; // Your element
//                    JavascriptExecutor executor = (JavascriptExecutor) driver;
//                    Object aa = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", element);
//                    SendDisplayLogToClient(aa.toString());
//                    if (visibletext.isEmpty() || visibletext.length() <= 0) {
//                        visibletext = input.getAttribute("value");
//                    }
//                    if (visibletext.isEmpty() || visibletext.length() <= 0) {
//                        visibletext = input.getAttribute("title");
//                    }
                    if (input.getAttribute("id").isEmpty() || input.getAttribute("id").equals("")) {
                        //create input id with type, class and onclick
                        //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                        String inputID = "spinputid" + "_$_";
                        try {
                            inputID += input.getAttribute("type") + "_$_";
                        } catch (Exception ex) {
                            inputID += "null_$_";
                        }
                        try {
                            inputID += input.getAttribute("class") + "_$_";
                        } catch (Exception ex) {
                            inputID += "null_$_";
                        }
                        try {
                            inputID += input.getAttribute("name") + "_$_";
                        } catch (Exception ex) {
                            inputID += "null_$_";
                        }
                        try {
                            inputID += visibletext + "_$_";
                        } catch (Exception ex) {
                            inputID += "null_$_";
                        }
//                        try {
//                            buttonID += dd.getText() + "_$_";
//                        } catch (Exception ex) {
//                            buttonID += "null_$_";
//                        }
                        mapPageElements.put(inputID,
                                new PageObject(0, inputID,"input",
                                        visibletext, input, bIsIframeControl, iFrameID, "",
                                        bIsWindowControl, windowTitle));
                    } else {
                        mapPageElements.put(input.getAttribute("id")+"-input",
                                new PageObject(0, input.getAttribute("id"), "input",
                                        visibletext, input, bIsIframeControl, iFrameID, "",
                                        bIsWindowControl, windowTitle));
                    }

                } else {
                    mapInvisiblePageObjects.put(input.getAttribute("id"),
                            new PageObject(0, input.getAttribute("id"),
                                    "href", input.getText(), input,
                                    bIsIframeControl, iFrameID, "",
                                    bIsWindowControl, windowTitle));
                }
            }
            SendDisplayLogToClient("Actionable inputs found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllImageElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                             boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();

        try {
            List<WebElement> images = driver.findElements(By.tagName("img"));
            for (WebElement image : images) {

                if (image.isDisplayed() && (ExpectedConditions.elementToBeClickable(image) != null)) {
                    WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", image);

                    String imageHref = "";
                    try {
                        imageHref = parent.getAttribute("href");
                        //SendDisplayLogToClient(imageHref);
                    } catch (Exception e) {
                        imageHref = "";
                    }
                    mapPageElements.put(image.getAttribute("src"),
                            new PageObject(0, image.getAttribute("src"), "image",
                                    image.getAttribute("alt"), image, bIsIframeControl, iFrameID, imageHref,
                                    bIsWindowControl, windowTitle));

                }
                //todo - add support for image without href
            }
            SendDisplayLogToClient("Actionable images found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;

        }
    }

    private Map<String, PageObject> getAllButtonElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                              boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        try {
            List<WebElement> buttons = driver.findElements(By.tagName("button"));
            Properties p = new Properties();
            for (WebElement button : buttons) {
                //print the links texts and links
                if (button.isDisplayed() && (ExpectedConditions.elementToBeClickable(button) != null)) {
                    String visibleText = getVisisbleTextOfWebElementPImpl(button);
                    if (button.getAttribute("id").isEmpty() || button.getAttribute("id").equals("")) {
                        //create button id with type, class and onclick
                        //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                        String buttonID = "spbuttonid" + "_$_";
                        try {
                            buttonID += button.getAttribute("type") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }
                        try {
                            buttonID += button.getAttribute("class") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }
                        try {
                            buttonID += button.getAttribute("name") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }
                        try {
                            buttonID += visibleText + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }
                        try {
                            //because in case of user slelection of objects, we are remvoing brackets
                            buttonID += button.getAttribute("onclick").replace("()", "{}") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }
                        mapPageElements.put(buttonID, new PageObject(0, buttonID, "button",
                                visibleText, button, bIsIframeControl, iFrameID, "",
                                bIsWindowControl, windowTitle));
                    } else {
                        mapPageElements.put(button.getAttribute("id"),
                                new PageObject(0, button.getAttribute("id"), "button",
                                        visibleText, button, bIsIframeControl, iFrameID, "",
                                        bIsWindowControl, windowTitle));
                    }
                }
            }
            SendDisplayLogToClient("Actionable buttons found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            ex.printStackTrace();
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllSpanElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                            boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        try {
            List<WebElement> spans = driver.findElements(By.tagName("span"));
            for (WebElement span : spans) {
                //print the links texts and links
                if (span.isDisplayed() && (ExpectedConditions.elementToBeClickable(span) != null)) {
                    if (span.getAttribute("id").isEmpty() || span.getAttribute("id").equals("")) {
                        //create button id with type, class and onclick
                        //id will be of format 'spspanID_$_type_$_class_$_name_$_displaytext_$_onclick'
                        String spanID = "spspanid" + "_$_";
                        try {
                            spanID += span.getAttribute("type") + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }
                        try {
                            spanID += span.getAttribute("class") + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }
                        try {
                            spanID += span.getAttribute("name") + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }
                        try {
                            spanID += span.getText() + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }
                        try {
                            //because in case of user slelection of objects, we are remvoing brackets
                            spanID += span.getAttribute("onclick").replace("()", "{}") + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }
                        //  emap.put(spanID, aa.toString());
                        mapPageElements.put(spanID, new PageObject(0, spanID, "span",
                                span.getText(), span, bIsIframeControl, iFrameID, "",
                                bIsWindowControl, windowTitle));
                    } else {
                        WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", span);
                        String spanClass = "";
                        try {
                            spanClass = parent.getAttribute("class");
                        } catch (Exception e) {
                            spanClass = "";
                        }
                        mapPageElements.put(span.getAttribute("id"),
                                new PageObject(0, span.getAttribute("id"), "span",
                                        span.getAttribute("title"), span, bIsIframeControl,
                                        iFrameID, spanClass, bIsWindowControl, windowTitle));
                    }
                }
            }
            SendDisplayLogToClient("Actionable spans found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllDivElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                           boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        List<WebElement> divss;
        try {
            //there are some div which has no ID - that case needs to be handled
            //sometimes divs are also clickable so get all clickable divs on page
            int scanchildDivs = Integer.parseInt(propMap.getProperty("scanchildDivs", "0"));
            if (scanchildDivs == 0) {
                divss = driver.findElements(By.tagName("div"));
                for (WebElement div : divss) {
                    try {
                        if (div.isDisplayed()) {

                            if ((ExpectedConditions.elementToBeClickable(div) != null)
                                    && !(div.getAttribute("id").isEmpty())
                                    && !(div.getText().isEmpty()) //&& !(div.getAttribute("href").isEmpty())
                            ) {
                                mapPageElements.put(div.getAttribute("id"),
                                        new PageObject(0, div.getAttribute("id"),
                                                "div", div.getText(), div,
                                                bIsIframeControl, iFrameID, "",
                                                bIsWindowControl, windowTitle));
                            }
                        }
                        //todo- what to do with invisible divs
                    } catch (Exception e) {
                        //ignore
                    }
                }
                //need to check better way
                mapPageDivs = new HashMap<String, PageObject>();
                mapPageDivs.putAll(mapPageDivs);
            } else if (scanchildDivs == 1) {
                List<WebElement> divs = driver.findElements(By.tagName("div"));
                for (WebElement div : divs) {
                    //print the links texts and links
                    if (div.isDisplayed() && (ExpectedConditions.elementToBeClickable(div) != null)) {
                        if (div.getAttribute("id").isEmpty() || div.getAttribute("id").equals("")) {
                            //create button id with type, class and onclick
                            //id will be of format 'spdivID_$_type_$_class_$_name_$_displaytext_$_onclick'
                            String divID = "spdivid" + "_$_";
                            try {
                                divID += div.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }
                            try {
                                divID += div.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }
                            try {
                                divID += div.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }
                            try {
                                divID += div.getText() + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }
                            try {
                                //because in case of user slelection of objects, we are remvoing brackets
                                divID += div.getAttribute("onclick").replace("()", "{}") + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }
                            //  emap.put(divID, aa.toString());
                            mapPageElements.put(divID, new PageObject(0, divID, "div",
                                    div.getText(), div, bIsIframeControl, iFrameID, "",
                                    bIsWindowControl, windowTitle));
                        } else {
                            WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", div);
                            String divClass = "";
                            try {
                                divClass = parent.getAttribute("class");
                            } catch (Exception e) {
                                divClass = "";
                            }
                            mapPageElements.put(div.getAttribute("id"),
                                    new PageObject(0, div.getAttribute("id"), "div",
                                            div.getAttribute("title"), div,
                                            bIsIframeControl, iFrameID, divClass,
                                            bIsWindowControl, windowTitle));
                        }
                    }
                }
            }
            SendDisplayLogToClient("Actionable divs found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;

        }
    }

    private Map<String, PageObject> getAllIconElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                            boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        try {
            List<WebElement> icons = driver.findElements(By.tagName("i"));
            for (WebElement icon : icons) {
                if (icon.isDisplayed() && (ExpectedConditions.elementToBeClickable(icon) != null)) {
                    WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", icon);
                    String iconHref = "";
                    try {
                        iconHref = parent.getAttribute("href");
                    } catch (Exception e) {
                        iconHref = "";
                    }
                    mapPageElements.put(icon.getAttribute("id"),
                            new PageObject(0, icon.getAttribute("id"), "icon",
                                    icon.getAttribute("title"), icon,
                                    bIsIframeControl, iFrameID, iconHref,
                                    bIsWindowControl, windowTitle));
                }
                //todo - add support for icons without href
            }
            SendDisplayLogToClient("Actionable icons found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllLabelElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                             boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        try {
            List<WebElement> labels = driver.findElements(By.tagName("label"));
            for (WebElement label : labels) {
                if (label.isDisplayed() && (ExpectedConditions.elementToBeClickable(label) != null)) {
//                    WebElement element = label; // Your element
//                    JavascriptExecutor executor = (JavascriptExecutor) driver;
//                    Object aa = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", element);
                    String labelElement = "";
                    try {
                        labelElement = label.getAttribute("for");
                        if (Strings.isNullOrEmpty(labelElement) || labelElement.isEmpty()) {
                            //search if this label includes other control like input of type checkbox or else
                            String labelType = label.getAttribute("class");
                            //need to add other class types as well
                            if (!labelType.isEmpty()) {
                                //it means some input type may be included as part of this lable
                                //like checkbox or radio etc
                                //so it means this lable wont have any id or href
                                //that another embeeded control needs to be clicked.

                                //so get all child elements of this label
                                List<WebElement> childs = label.findElements(By.xpath(".//*"));
                                for (int iCnt = 0; iCnt < childs.size(); iCnt++) {
                                    WebElement childElement = childs.get(iCnt);
                                    String childTag = childElement.getTagName();
                                    if (childTag.equalsIgnoreCase("input")) {
                                        if (childElement.isDisplayed()) {
                                            //input element can be anything
                                            //text
                                            //checkbox
                                            //radio
                                            //what else
                                            //so get class and check
                                            String inputType = childElement.getAttribute("type");

                                            String visibletext = childElement.getText();
                                            if (visibletext.isEmpty() || visibletext.length() <= 0) {
                                                //here get value of parent element i.e. label
                                                visibletext = label.getText();
                                            }
                                            mapPageElements.put(childElement.getAttribute("id"),
                                                    new PageObject(0,
                                                            childElement.getAttribute("id"),
                                                            "input", visibletext, childElement,
                                                            bIsIframeControl, iFrameID, "",
                                                            bIsWindowControl, windowTitle));
                                        }
                                    }
                                }
                            }
                        } else {
                            //so get all child elements of this label
                            List<WebElement> childs = label.findElements(By.xpath(".//*"));
                            if (childs.size() > 0) {
                                for (int iCnt = 0; iCnt < childs.size(); iCnt++) {
                                    WebElement childElement = childs.get(iCnt);
                                    String childTag = childElement.getTagName();
                                    {
                                        if (childTag.equalsIgnoreCase("input") || childTag.equalsIgnoreCase("span")) { // ARP Added
                                            if (childElement.isDisplayed()) {
                                                //input element can be anything
                                                //text
                                                //checkbox
                                                //radio
                                                //what else
                                                //so get class and check

                                                String inputType = childElement.getAttribute("type");
                                                String visibletext = childElement.getText();
                                                if (visibletext.isEmpty() || visibletext.length() <= 0) {
                                                    visibletext = label.getText();
                                                }
                                                if (!childElement.getAttribute("id").isEmpty()) {
                                                    mapPageElements.put(childElement.getAttribute("id"),
                                                            new PageObject(0,
                                                                    childElement.getAttribute("id"),
                                                                    "input", visibletext, childElement,
                                                                    bIsIframeControl, iFrameID, "",
                                                                    bIsWindowControl, windowTitle));
                                                } else {
                                                    //get parent of tihs label which should be having ID
                                                    WebElement parentElementWithID = label.findElement(By.xpath("./.."));
                                                    String customID = "spchkbxid" + "_$_" + parentElementWithID.getAttribute("id") + "_$_" + visibletext;
                                                    //if this element does not have ID then god only can click on this checkbox/redio etc
                                                    mapPageElements.put(customID,
                                                            new PageObject(0, customID,
                                                                    "input", visibletext, childElement,
                                                                    bIsIframeControl, iFrameID, "",
                                                                    bIsWindowControl, windowTitle));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (Exception e) {
                        labelElement = "";
                        try {
                            String labelType = label.getAttribute("type");
                            //need to add other class types as well
                            if (labelType.equalsIgnoreCase("checkbox")) {
                                labelElement = label.getAttribute("id");
                            }
                        } catch (Exception ex2) {

                        }
                    }
                    mapPageElements.put(labelElement, new PageObject(0, labelElement,
                            "label", label.getText(), label,
                            bIsIframeControl, iFrameID, labelElement,
                            bIsWindowControl, windowTitle));
                }
            }
            SendDisplayLogToClient("Actionable labels found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllSelectElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                              boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        try {
            List<WebElement> dropdowns = driver.findElements(By.tagName("select"));
            for (WebElement dd : dropdowns) {
                {
                    if (dd.getAttribute("id").isEmpty() || dd.getAttribute("id").equals("")) {
                        //create button id with type, class and onclick
                        //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                        String buttonID = "spddid" + "_$_";
                        try {
                            buttonID += dd.getAttribute("type") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }
                        try {
                            buttonID += dd.getAttribute("class") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }
                        try {
                            buttonID += dd.getAttribute("name") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }
                        mapPageElements.put(buttonID, new PageObject(0, buttonID,
                                "dropdown", dd.getText(), dd,
                                bIsIframeControl, iFrameID, "",
                                bIsWindowControl, windowTitle));
                    } else {
                        mapPageElements.put(dd.getAttribute("id"),
                                new PageObject(0, dd.getAttribute("id"),
                                        "dropdown", dd.getText(), dd,
                                        bIsIframeControl, iFrameID, "",
                                        bIsWindowControl, windowTitle));
                    }
                }
            }
            SendDisplayLogToClient("Actionable selects/dropdowns found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllRadiosElementsPImpl(boolean bIsIframeControl, String iFrameID,
                                                              boolean bIsWindowControl, String windowTitle, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        try {
            List<WebElement> radiobuttons = driver.findElements(By.tagName("radio"));
            for (WebElement radiobutton : radiobuttons) {

                if (radiobutton.isDisplayed() && (ExpectedConditions.elementToBeClickable(radiobutton) != null)) {
                    mapPageElements.put(radiobutton.getAttribute("id"),
                            new PageObject(0, radiobutton.getAttribute("id"),
                                    "radio", radiobutton.getText(), radiobutton,
                                    bIsIframeControl, iFrameID, "",
                                    bIsWindowControl, windowTitle));
                }
            }
            SendDisplayLogToClient("Actionable radios found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllAnchorElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();

        try {
            List<WebElement> allLinks = driver.findElements(By.tagName("a"));
            mapInvisiblePageObjects.clear();
            for (WebElement link : allLinks) {
                //System.out.printf("\r%s", iElemtnCounter++);
                //System.out.flush();
                //print the links texts and links

                if (!(link.getAttribute("id").isEmpty())) {

                    if (link.isDisplayed()) {
                        if (ExpectedConditions.elementToBeClickable(link) != null) {
                            //this is only href which are associated with actions or links
                            mapPageElements.put(link.getAttribute("id"), new PageObject(0, link.getAttribute("id"), "href", link.getText(), link, bIsIframeControl, iFrameID, ""));
                        }
                    } else {
                        //invisible objects
                        //mapInvisiblePageObjects.put(link.getAttribute("id"), new PageObject(0, link.getAttribute("id"), "href", link.getText(), link, bIsIframeControl, iFrameID, ""));
                         mapInvisiblePageObjects.put(link.getAttribute("id"), new PageObject(0, link.getAttribute("id"), "href", link.getText(), link, bIsIframeControl, iFrameID, ""));
                    }

                } else if ((!link.getText().isEmpty())) {
                    //link ID is empty

                    //control ID is Empty but link-text is not empty
                    //so inorder to search based on By.linktext() we need to store those controls
                    String hrefID = "sphrefid" + "_$_";

                    try {
                        hrefID += link.getAttribute("href") + "_$_";
                    } catch (Exception ex) {
                        hrefID += "null_$_";
                    }

                    try {
                        hrefID += link.getAttribute("class") + "_$_";
                    } catch (Exception ex) {
                        hrefID += "null_$_";
                    }
                    try {
                        hrefID += link.getAttribute("rel") + "_$_";
                    } catch (Exception ex) {
                        hrefID += "null_$_";
                    }

                    try {
                        //                        Get the visible innertext of the element
                        hrefID += link.getText() + "_$_";
                    } catch (Exception ex) {
                        hrefID += "null_$_";
                    }
                    // ARP Added UUID to avoid Duplicate object Ids
                    try {
                        String uuid = UUID.randomUUID().toString().replace("-", "");
                        hrefID += uuid + "_$_";
                    } catch (Exception ex) {
                        hrefID += "uuidFail_$_";
                    }
                    mapPageElements.put(hrefID, new PageObject(0, hrefID, "href", link.getText(), link, bIsIframeControl, iFrameID, ""));

                    mapPageObjectsSearchByLinkText.put(UUID.randomUUID().toString(), new PageObject(0, hrefID, "href", link.getText(), link, bIsIframeControl, iFrameID, ""));

                }
                //add any other condition
              // else {
              //                                
               //     }
            }
            SendDisplayLogToClient("Actionable links found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllInputElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {

        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        String[] inputTypes = {"text", "email", "password", "number", "search", "tel", "url"};
        List<String> inputTypesList = Arrays.asList(inputTypes);
        String inputType = "";
        String visibletext = "";

        try {
            List<WebElement> inputs = driver.findElements(By.tagName("input"));
            inputs.addAll(driver.findElements(By.tagName("textarea")));
            for (WebElement input : inputs) {

                //print the links texts and links
                if (input.isDisplayed()) {

                    //input element can be anything
                    //text
                    //checkbox
                    //radio 
                    //what else
                    //so get class and check
//                    String[] inputTypes = {"text", "email", "password", "number", "search", "tel", "url"};
//                    List<String> inputTypesList = Arrays.asList(inputTypes);
//                    String inputType = input.getAttribute("type");
////                    String visibletext = input.getText();
//                    String visibletext = "";
                    /**adding this condition here,
                     * to avoid the text field(text,email, password, etc.. as above array) value in the page object
                     * identified this in the defect IA32 reported
                     * due to the test data/text field value, the conditions in level 1 & 5 gets satisfied, which is NOT expected
                     * spinputid_$_text_$__$_password_$__$_
                     * spinputid_$_text_$__$_password_$_Nthg@1234_$_ */
                    if(!(inputTypesList.contains(inputType))) {
                        visibletext = input.getText();
                        if(StringUtils.isEmpty(visibletext))
                            visibletext = input.getAttribute("value");
                        if(StringUtils.isEmpty(visibletext))
                            visibletext = input.getAttribute("title");
                    }
                   
//                    WebElement element = input; // Your element
//                    JavascriptExecutor executor = (JavascriptExecutor) driver;
//                    Object aa = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", element);
//                    SendDisplayLogToClient(aa.toString());
//                    if (visibletext.isEmpty() || visibletext.length() <= 0) {
//                        visibletext = input.getAttribute("value");
//                    }
//                    if (visibletext.isEmpty() || visibletext.length() <= 0) {
//                        visibletext = input.getAttribute("title");
//                    }

                    if (input.getAttribute("id").isEmpty() || input.getAttribute("id").equals("")) {
                        //create input id with type, class and onclick
                        //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                        String inputID = "spinputid" + "_$_";

                        try {
                            inputID += input.getAttribute("type") + "_$_";

                        } catch (Exception ex) {
                            inputID += "null_$_";
                        }

                        try {
                            inputID += input.getAttribute("class") + "_$_";
                        } catch (Exception ex) {
                            inputID += "null_$_";
                        }

                        try {
                            inputID += input.getAttribute("name") + "_$_";
                        } catch (Exception ex) {
                            inputID += "null_$_";
                        }
                        try {
                            inputID += visibletext + "_$_";
                        } catch (Exception ex) {
                            inputID += "null_$_";
                        }

//                        try {
//                            buttonID += dd.getText() + "_$_";
//                        } catch (Exception ex) {
//                            buttonID += "null_$_";
//                        }
                        mapPageElements.put(inputID, new PageObject(0, inputID, "input", visibletext, input, bIsIframeControl, iFrameID, ""));

                    } else {
                      mapPageElements.put(input.getAttribute("id"), new PageObject(0, input.getAttribute("id"), "input", visibletext, input, bIsIframeControl, iFrameID, ""));
                       
                    }
                    
                } else {
                    mapInvisiblePageObjects.put(input.getAttribute("id"), new PageObject(0, input.getAttribute("id"), "href", input.getText(), input, bIsIframeControl, iFrameID, ""));
                }
            }
            SendDisplayLogToClient("Actionable inputs found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllSelectElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();

        try {

            List<WebElement> dropdowns = driver.findElements(By.tagName("select"));
            for (WebElement dd : dropdowns) {
                {

                    if (dd.getAttribute("id").isEmpty() || dd.getAttribute("id").equals("")) {
                        //create button id with type, class and onclick
                        //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                        String buttonID = "spddid" + "_$_";

                        try {
                            buttonID += dd.getAttribute("type") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }

                        try {
                            buttonID += dd.getAttribute("class") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }

                        try {
                            buttonID += dd.getAttribute("name") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }

                        mapPageElements.put(buttonID, new PageObject(0, buttonID, "dropdown", dd.getText(), dd, bIsIframeControl, iFrameID, ""));
                    } else {

                        mapPageElements.put(dd.getAttribute("id"), new PageObject(0, dd.getAttribute("id"), "dropdown", dd.getText(), dd, bIsIframeControl, iFrameID, ""));
                    }
                }
            }
            SendDisplayLogToClient("Actionable selects/dropdowns found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;

        }
    }

    private Map<String, PageObject> getAllRadiosElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();

        try {

            List<WebElement> radiobuttons = driver.findElements(By.tagName("radio"));
            for (WebElement radiobutton : radiobuttons) {

                if (radiobutton.isDisplayed() && (ExpectedConditions.elementToBeClickable(radiobutton) != null)) {
                    mapPageElements.put(radiobutton.getAttribute("id"), new PageObject(0, radiobutton.getAttribute("id"), "radio", radiobutton.getText(), radiobutton, bIsIframeControl, iFrameID, ""));
                }
            }
            SendDisplayLogToClient("Actionable radios found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;

        }
    }

    private Map<String, PageObject> getAllButtonElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();

        try {

            List<WebElement> buttons = driver.findElements(By.tagName("button"));
            Properties p = new Properties();
            for (WebElement button : buttons) {

                //print the links texts and links
                if (button.isDisplayed() && (ExpectedConditions.elementToBeClickable(button) != null)) {

                    String visibleText = getVisisbleTextOfWebElementPImpl(button);

                    if (button.getAttribute("id").isEmpty() || button.getAttribute("id").equals("")) {
                        //create button id with type, class and onclick
                        //id will be of format 'spbuttonid_$_type_$_class_$_name_$_displaytext_$_onclick'
                        String buttonID = "spbuttonid" + "_$_";

                        try {
                            buttonID += button.getAttribute("type") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }

                        try {
                            buttonID += button.getAttribute("class") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }

                        try {
                            buttonID += button.getAttribute("name") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }

                        try {
                            buttonID += visibleText + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }
                        try {
                            //because in case of user slelection of objects, we are remvoing brackets
                            buttonID += button.getAttribute("onclick").replace("()", "{}") + "_$_";
                        } catch (Exception ex) {
                            buttonID += "null_$_";
                        }

                        mapPageElements.put(buttonID, new PageObject(0, buttonID, "button", visibleText, button, bIsIframeControl, iFrameID, ""));
                    } else {
                        mapPageElements.put(button.getAttribute("id"), new PageObject(0, button.getAttribute("id"), "button", visibleText, button, bIsIframeControl, iFrameID, ""));
                    }
                }
            }
            SendDisplayLogToClient("Actionable buttons found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            ex.printStackTrace();
            return mapPageElements;
        }
    }

    private Map<String, PageObject> getAllIconElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();

        try {
            List<WebElement> icons = driver.findElements(By.tagName("i"));
            for (WebElement icon : icons) {

                if (icon.isDisplayed() && (ExpectedConditions.elementToBeClickable(icon) != null)) {
                    WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", icon);

                    String iconHref = "";
                    try {
                        iconHref = parent.getAttribute("href");
                    } catch (Exception e) {
                        iconHref = "";
                    }
                    mapPageElements.put(icon.getAttribute("id"), new PageObject(0, icon.getAttribute("id"), "icon", icon.getAttribute("title"), icon, bIsIframeControl, iFrameID, iconHref));

                }
                //todo - add support for icons without href

            }
            SendDisplayLogToClient("Actionable icons found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;

        }
    }

    private Map<String, PageObject> getAllSpanElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();

        try {
            List<WebElement> spans = driver.findElements(By.tagName("span"));
            for (WebElement span : spans) {

                //print the links texts and links
                if (span.isDisplayed() && (ExpectedConditions.elementToBeClickable(span) != null)) {

                    if (span.getAttribute("id").isEmpty() || span.getAttribute("id").equals("")) {
                        //create button id with type, class and onclick
                        //id will be of format 'spspanID_$_type_$_class_$_name_$_displaytext_$_onclick'
                        String spanID = "spspanid" + "_$_";

                        try {
                            spanID += span.getAttribute("type") + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }

                        try {
                            spanID += span.getAttribute("class") + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }

                        try {
                            spanID += span.getAttribute("name") + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }

                        try {
                            spanID += span.getText() + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }
                        try {
                            //because in case of user slelection of objects, we are remvoing brackets
                            spanID += span.getAttribute("onclick").replace("()", "{}") + "_$_";
                        } catch (Exception ex) {
                            spanID += "null_$_";
                        }
                        //  emap.put(spanID, aa.toString());
                        mapPageElements.put(spanID, new PageObject(0, spanID, "span", span.getText(), span, bIsIframeControl, iFrameID, ""));
                    } else {
                        WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", span);

                        String spanClass = "";
                        try {
                            spanClass = parent.getAttribute("class");
                        } catch (Exception e) {
                            spanClass = "";
                        }
                        mapPageElements.put(span.getAttribute("id"), new PageObject(0, span.getAttribute("id"), "span", span.getAttribute("title"), span, bIsIframeControl, iFrameID, spanClass));
                    }

                }

            }
            SendDisplayLogToClient("Actionable spans found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;

        }
    }

    private Map<String, PageObject> getAllImageElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();

        try {
            List<WebElement> images = driver.findElements(By.tagName("img"));
            for (WebElement image : images) {

                if (image.isDisplayed() && (ExpectedConditions.elementToBeClickable(image) != null)) {
                    WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", image);

                    String imageHref = "";
                    try {
                        imageHref = parent.getAttribute("href");
                        //SendDisplayLogToClient(imageHref);
                    } catch (Exception e) {
                        imageHref = "";
                    }
                    mapPageElements.put(image.getAttribute("src"), new PageObject(0, image.getAttribute("src"), "image", image.getAttribute("alt"), image, bIsIframeControl, iFrameID, imageHref));

                }

                //todo - add support for image without href
            }
            SendDisplayLogToClient("Actionable images found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;

        }
    }

    private Map<String, PageObject> getAllLabelElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();

        try {
            List<WebElement> labels = driver.findElements(By.tagName("label"));
            for (WebElement label : labels) {

                if (label.isDisplayed() && (ExpectedConditions.elementToBeClickable(label) != null)) {

//                    WebElement element = label; // Your element
//                    JavascriptExecutor executor = (JavascriptExecutor) driver;
//                    Object aa = executor.executeScript("var items = {}; for (index = 0; index < arguments[0].attributes.length; ++index) { items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value }; return items;", element);
                    String labelElement = "";
                    try {
                        labelElement = label.getAttribute("for");

                        if (Strings.isNullOrEmpty(labelElement) || labelElement.isEmpty()) {
                            //search if this label includes other control like input of type checkbox or else
                            String labelType = label.getAttribute("class");
                            //need to add other class types as well
                            if (!labelType.isEmpty()) {
                                //it means some input type may be included as part of this lable
                                //like checkbox or radio etc
                                //so it means this lable wont have any id or href
                                //that another embeeded control needs to be clicked.

                                //so get all child elements of this label
                                List<WebElement> childs = label.findElements(By.xpath(".//*"));
                                for (int iCnt = 0; iCnt < childs.size(); iCnt++) {
                                    WebElement childElement = childs.get(iCnt);
                                    String childTag = childElement.getTagName();

                                    if (childTag.equalsIgnoreCase("input")) {
                                        if (childElement.isDisplayed()) {
                                            //input element can be anything
                                            //text
                                            //checkbox
                                            //radio 
                                            //what else
                                            //so get class and check
                                            String inputType = childElement.getAttribute("type");

                                            String visibletext = childElement.getText();
                                            if (visibletext.isEmpty() || visibletext.length() <= 0) {
                                                //here get value of parent element i.e. label
                                                visibletext = label.getText();
                                            }
                                            mapPageElements.put(childElement.getAttribute("id"), new PageObject(0, childElement.getAttribute("id"), "input", visibletext, childElement, bIsIframeControl, iFrameID, ""));

                                        }
                                    }
                                }
                            }

                        } else {
                            //so get all child elements of this label
                            List<WebElement> childs = label.findElements(By.xpath(".//*"));
                            if (childs.size() > 0) {
                                for (int iCnt = 0; iCnt < childs.size(); iCnt++) {
                                    WebElement childElement = childs.get(iCnt);
                                    String childTag = childElement.getTagName();
                                    {
                                        if (childTag.equalsIgnoreCase("input") || childTag.equalsIgnoreCase("span")) { // ARP Added 
                                            if (childElement.isDisplayed()) {
                                                //input element can be anything
                                                //text
                                                //checkbox
                                                //radio 
                                                //what else
                                                //so get class and check

                                                String inputType = childElement.getAttribute("type");
                                                String visibletext = childElement.getText();
                                                if (visibletext.isEmpty() || visibletext.length() <= 0) {
                                                    visibletext = label.getText();
                                                }
                                                if (!childElement.getAttribute("id").isEmpty()) {
                                                    mapPageElements.put(childElement.getAttribute("id"), new PageObject(0, childElement.getAttribute("id"), "input", visibletext, childElement, bIsIframeControl, iFrameID, ""));
                                                } else {
                                                    //get parent of tihs label which should be having ID
                                                    WebElement parentElementWithID = label.findElement(By.xpath("./.."));

                                                    String customID = "spchkbxid" + "_$_" + parentElementWithID.getAttribute("id") + "_$_" + visibletext;

                                                    //if this element does not have ID then god only can click on this checkbox/redio etc
                                                    mapPageElements.put(customID, new PageObject(0, customID, "input", visibletext, childElement, bIsIframeControl, iFrameID, ""));
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }

                    } catch (Exception e) {
                        labelElement = "";
                        try {
                            String labelType = label.getAttribute("type");
                            //need to add other class types as well
                            if (labelType.equalsIgnoreCase("checkbox")) {
                                labelElement = label.getAttribute("id");
                            }
                        } catch (Exception ex2) {

                        }
                    }
                    mapPageElements.put(labelElement, new PageObject(0, labelElement, "label", label.getText(), label, bIsIframeControl, iFrameID, labelElement));
                }
            }
            SendDisplayLogToClient("Actionable labels found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;

        }
    }

    private Map<String, PageObject> getAllDivElementsPImpl(boolean bIsIframeControl, String iFrameID, WebDriver driver) {
        Map<String, PageObject> mapPageElements = new HashMap<String, PageObject>();
        List<WebElement> divss;
        try {

            //there are some div which has no ID - that case needs to be handled
            //sometimes divs are also clickable so get all clickable divs on page
            int scanchildDivs = Integer.parseInt(propMap.getProperty("scanchildDivs", "0"));
            if (scanchildDivs == 0) {

                divss = driver.findElements(By.tagName("div"));
                for (WebElement div : divss) {

                    try {
                        if (div.isDisplayed()) {

                            if ((ExpectedConditions.elementToBeClickable(div) != null)
                                    && !(div.getAttribute("id").isEmpty())
                                    && !(div.getText().isEmpty()) //&& !(div.getAttribute("href").isEmpty())
                                    ) {
                                mapPageElements.put(div.getAttribute("id"), new PageObject(0, div.getAttribute("id"), "div", div.getText(), div, bIsIframeControl, iFrameID, ""));

                            }
                        }

                        //todo- what to do with invisible divs
                    } catch (Exception e) {
                        //ignore
                    }

                }
                //need to check better way
                mapPageDivs = new HashMap<String, PageObject>();
                mapPageDivs.putAll(mapPageDivs);

            } else if (scanchildDivs == 1) {

                List<WebElement> divs = driver.findElements(By.tagName("div"));
                for (WebElement div : divs) {

                    //print the links texts and links
                    if (div.isDisplayed() && (ExpectedConditions.elementToBeClickable(div) != null)) {

                        if (div.getAttribute("id").isEmpty() || div.getAttribute("id").equals("")) {
                            //create button id with type, class and onclick
                            //id will be of format 'spdivID_$_type_$_class_$_name_$_displaytext_$_onclick'
                            String divID = "spdivid" + "_$_";

                            try {
                                divID += div.getAttribute("type") + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }

                            try {
                                divID += div.getAttribute("class") + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }

                            try {
                                divID += div.getAttribute("name") + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }

                            try {
                                divID += div.getText() + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }
                            try {
                                //because in case of user slelection of objects, we are remvoing brackets
                                divID += div.getAttribute("onclick").replace("()", "{}") + "_$_";
                            } catch (Exception ex) {
                                divID += "null_$_";
                            }
                            //  emap.put(divID, aa.toString());
                            mapPageElements.put(divID, new PageObject(0, divID, "div", div.getText(), div, bIsIframeControl, iFrameID, ""));
                        } else {
                            WebElement parent = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].parentNode;", div);

                            String divClass = "";
                            try {
                                divClass = parent.getAttribute("class");
                            } catch (Exception e) {
                                divClass = "";
                            }
                            mapPageElements.put(div.getAttribute("id"), new PageObject(0, div.getAttribute("id"), "div", div.getAttribute("title"), div, bIsIframeControl, iFrameID, divClass));
                        }

                    }

                }
            }
            SendDisplayLogToClient("Actionable divs found on web page are: " + mapPageElements.size());
            return mapPageElements;
        } catch (Exception ex) {
            return mapPageElements;

        }
    }

    private void SendDisplayLogToClient(String strDisplay) {

        try {

//            serverlogSender.strToDisplay = strDisplay;
           // serverlogSender.inQueueExecutionLog.add(strDisplay);

        } catch (Exception ex) {

        }
    }

    private static String getVisisbleTextOfWebElementPImpl(WebElement element) {
        try {
            String visibleText = element.getText();
            if (visibleText != null
                    && !visibleText.isEmpty()) {

                return visibleText;
            } else {
                visibleText = element.getAttribute("value");
                if (visibleText != null
                        && !visibleText.isEmpty()) {
                    return visibleText;
                } else {

                    visibleText = element.getAttribute("aria-label");
                    if (visibleText != null
                            && !visibleText.isEmpty()) {
                        return visibleText;
                    } else {
                        String innerHTML = element.getAttribute("innerHTML");
                        //parse and getPageElements the visible text
                        return innerHTML;
                    }
                }

            }
        } catch (Exception ex) {
            return "";
        }

    }

}
