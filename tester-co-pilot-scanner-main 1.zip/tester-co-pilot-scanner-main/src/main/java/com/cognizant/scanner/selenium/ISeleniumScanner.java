package com.cognizant.scanner.selenium;

import org.openqa.selenium.*;

import java.util.Map;

public interface ISeleniumScanner {

//    Map<String, PageObject> getPageElements(boolean b,String s);
    Map<String, PageObject> getPageElements(boolean bIsIframeControl, String iFrameID,
                                            boolean bIsWindowControl, String windowTitle, WebDriver driver);

}
