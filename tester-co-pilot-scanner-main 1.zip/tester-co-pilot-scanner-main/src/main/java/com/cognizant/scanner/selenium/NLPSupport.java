
package com.cognizant.scanner.selenium;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.*;

import com.cognizant.scanner.common.Constants;
import lombok.extern.slf4j.Slf4j;
import net.didion.jwnl.data.IndexWord;
import net.didion.jwnl.data.IndexWordSet;
import net.didion.jwnl.data.POS;
import opennlp.tools.chunker.ChunkerME;
import opennlp.tools.chunker.ChunkerModel;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;

@Slf4j
public class NLPSupport {

    public NLPSupport() {
    }

    public static boolean getWordNetMatch(String DisplayText, String ActualControlName) {
        try {
            //find in wordnet
            IndexWordSet start = AOStar.dictionary.lookupAllIndexWords(DisplayText);

            //IndexWordSet end = AOStar.dictionary.lookupAllIndexWords(ActualControlName);

            IndexWord[] arrIndexWords = start.getIndexWordArray();
            for (int i = 0; i < arrIndexWords.length; i++) {
                IndexWord iWord = arrIndexWords[i];
                net.didion.jwnl.data.Synset[] synsets = iWord.getSenses();
                for (int j = 0; j < synsets.length; j++) {
                    //synsets[j].getVerbFrames()
                    String SynonymPhrase = synsets[j].getGloss().substring(0, synsets[j].getGloss().indexOf("\""));
                    //System.out.println(SynonymPhrase);
                    String[] buffer = SynonymPhrase.split("\\b \\b");
                    for (int iBufCnt = 0; iBufCnt < buffer.length; iBufCnt++) {
                        if (Constants.skipWords.contains(buffer[iBufCnt].toLowerCase())) {
                            continue;
                        }
                        if (RegExMatch(buffer[iBufCnt], ActualControlName)) {
                            return true;
                        } else if (getPlainMatch(buffer[iBufCnt], ActualControlName)) {
                            return true;
                        }
                    }
                }
            }
            //net.didion.jwnl.data.Synset currSynset = synsets[j];
            return false;
        } catch (Exception e) {
            System.out.println(Thread.currentThread().getStackTrace()[1].getMethodName()+ e.getMessage());
            return false;
        }
    }

    public static String getPoSType(String lemma) {

        try {

            //MorphologicalProcessor morphPro = dictionary.getMorphologicalProcessor();
            //new Examples().go();
            //Synset synset[] = word.getSenses();
            IndexWord word = AOStar.dictionary.lookupIndexWord(POS.VERB, lemma);
            if (word != null) {
                return word.getPOS().toString();
            }

            word = AOStar.dictionary.lookupIndexWord(POS.ADJECTIVE, lemma);
            if (word != null) {
                return word.getPOS().toString();
            }

            word = AOStar.dictionary.lookupIndexWord(POS.ADVERB, lemma);
            if (word != null) {
                return word.getPOS().toString();
            }

            word = AOStar.dictionary.lookupIndexWord(POS.NOUN, lemma);
            if (word != null) {
                return word.getPOS().toString();
            }

//            for (int i = 0; i < synset.length; i++) {
//                System.out.println(synset[i].toString());
//            }
        } catch (Exception e) {
            e.printStackTrace();

        }
        return "unknown";
    }

    public static void getverbs(LinkedHashMap<String, String> TestStepsData) {
        try {

            // Parts-Of-Speech Tagging
            // reading parts-of-speech model to a stream
            InputStream posModelIn = new FileInputStream("config/en-pos-maxent.zip");
            // loading the parts-of-speech model from stream
            POSModel posModel = new POSModel(posModelIn);
            // initializing the parts-of-speech tagger with model
            POSTaggerME posTagger = new POSTaggerME(posModel);

            // reading the chunker model
            InputStream ins = new FileInputStream("config/en-chunker.zip");
            // loading the chunker model
            ChunkerModel chunkerModel = new ChunkerModel(ins);
            // initializing chunker(maximum entropy) with chunker model
            ChunkerME chunker = new ChunkerME(chunkerModel);

            for (Map.Entry<String, String> entry : TestStepsData.entrySet()) {
                String TestStep = entry.getKey();
                String TestData = entry.getValue();

                //get only verbs which resembles to actions
                if (!TestStep.isEmpty()) {

                    // test sentence
                    String[] tokens = TestStep.substring(2).split(" ");

                    // Tagger tagging the tokens
                    String tags[] = posTagger.tag(tokens);

                    // chunking the given sentence : chunking requires sentence to be tokenized and pos tagged
                    String[] chunks = chunker.chunk(tokens, tags);
                }

                if (TestData.isEmpty()) {
                    //means its a non-data-entry action i.e. click,navigate-url etc etc
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean RegExMatch(String displayText, String actualControlName) {
        try {
            // Prepare regex text by replacing any blank spaces (double spaces) with a comma
            String regexText = displayText.replaceAll("\\b \\b", ",").toLowerCase();
            regexText = "(^" + regexText + ")";

            // Compile the regex pattern
            Pattern pattern = Pattern.compile(regexText);
            Matcher matcher = pattern.matcher(actualControlName.toLowerCase());

            // Attempt to find a match
            if (matcher.find()) {
                return true;
            } else {
                // Try reversed matching
                regexText = "(^" + actualControlName.toLowerCase() + ")";
                pattern = Pattern.compile(regexText);
                String[] displayTextArray = displayText.toLowerCase().split("\\b \\b");

                // Iterate through the split display texts to find a match
                for (String text : displayTextArray) {
                    matcher = pattern.matcher(text);
                    if (matcher.find()) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false; // Log the exception if needed
        }
    }

    public static boolean getPlainMatch(String DisplayText, String ActualControlName) {
        try {
            //plain text search
            DisplayText = DisplayText.trim().toLowerCase();
            ActualControlName = ActualControlName.trim().toLowerCase();
            DisplayText = DisplayText.replaceAll("\\b \\b", "");
            ActualControlName = ActualControlName.replaceAll("\\b \\b", "");
//            if(ActualControlName.equalsIgnoreCase("ctl00_cphBody_txtGuestEmail")){
//                int i=0;
//                i++;
//            }
            if (ActualControlName.contains(DisplayText)) {
                //System.out.println("Found possible control===========================" + DisplayText + "   ----> " + ActualControlName);
                return true;
            } else if (DisplayText.contains(ActualControlName)) {
                //System.out.println("Found possible control===========================" + DisplayText + "   ----> " + ActualControlName);
                return true;
            } else if (ActualControlName.indexOf(DisplayText) != -1) {
                //System.out.println("Found possible control===========================" + DisplayText + "   ----> " + ActualControlName);
                return true;
            } else if (DisplayText.indexOf(ActualControlName) != -1) {
                //System.out.println("Found possible control===========================" + DisplayText + "   ----> " + ActualControlName);
                return true;
            }

            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean getSynonyms(String DisplayText, String ActualControlName) {
        try {

            if (Constants.skipWords.contains(DisplayText.trim().toLowerCase())) {
                return false;
            }

            if (Constants.skipWords.contains(ActualControlName.trim().toLowerCase())) {
                return false;
            }

            boolean bMatchFound = RegExMatch(DisplayText, ActualControlName);

            if (!bMatchFound) {
                bMatchFound = getPlainMatch(DisplayText, ActualControlName);

            }
            return bMatchFound;

            // find all synonyms that <var>start</var> and <var>end</var> have in common
//                RelationshipList list = RelationshipFinder.getInstance().findRelationships(start.getSense(1), end.getSense(1), PointerType.SIMILAR_TO);
//                System.out.println("Synonym relationship between \"" + start.getLemma() + "\" and \"" + end.getLemma() + "\":");
//
//                for (Iterator itr = list.iterator(); itr.hasNext();) {
//                    ((Relationship) itr.next()).getNodeList().print();
//                }
//                System.out.println("Depth: " + ((Relationship) list.get(0)).getDepth());
//            }
        } catch (Exception e) {
            return false;
        }
    }
}
