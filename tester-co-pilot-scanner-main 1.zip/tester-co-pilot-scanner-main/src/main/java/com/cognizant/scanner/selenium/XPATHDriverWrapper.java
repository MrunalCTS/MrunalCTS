package com.cognizant.scanner.selenium;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.springframework.stereotype.*;

@Service
public class XPATHDriverWrapper {

    Map<String, WebElement> xpathIDToWebElementMap = new LinkedHashMap();
    Map<WebElement, String> webElementToXPATHIDMap = new LinkedHashMap();
    Map<String, String> remoteWebElementToXPATHIDMap = new LinkedHashMap();
    boolean bTraversexpaths = false;

    public XPATHDriverWrapper() {
        bTraversexpaths = true;

    }

    public void intParser(WebDriver driver){
        if (!bTraversexpaths) {
            //donot load parser since

        } else {
            System.out.println("Loading PageDom and scanning XPATHs---------");
            WebElement htmlElement = driver.findElement(By.xpath("/html"));
            iterateThroughChildren(htmlElement, "/html");

            //just print map
            System.out.println("Scanning XPATHs---------");
//        for (Map.Entry<String, String> entry : remoteWebElementToXPATHIDMap.entrySet()) {
//            System.out.println(entry.getKey() + " ----> " + entry.getValue());
//        }
            System.out.println("After scan- XPATHs size = " + remoteWebElementToXPATHIDMap.size());

            System.out.println("Scanning XPATHs complete---------");
        }
    }

    private String generateXPATH(WebElement childElement, String current) {
        try {
            String childTag = childElement.getTagName();
            if (childTag.equals("html")) {
                return "/html[1]" + current;
            }
            WebElement parentElement = childElement.findElement(By.xpath(".."));
            List<WebElement> childrenElements = parentElement.findElements(By.xpath("*"));
            int count = 0;
            for (int i = 0; i < childrenElements.size(); i++) {
                WebElement childrenElement = childrenElements.get(i);
                String childrenElementTag = childrenElement.getTagName();
                if (childTag.equals(childrenElementTag)) {
                    count++;
                }
                if (childElement.equals(childrenElement)) {
                    return generateXPATH(parentElement, "/" + childTag + "[" + count + "]" + current);
                }
            }
            return null;
        } catch (Exception ex) {
            return "";
        }
    }

    private void iterateThroughChildren(WebElement parentElement, String parentXPATH) {
        try {
            Map siblingCountMap = new LinkedHashMap();

            List<WebElement> childrenElements = parentElement.findElements(By.xpath(parentXPATH + "/*"));
            for (int i = 0; i < childrenElements.size(); i++) {
                RemoteWebElement remotewebelement = (RemoteWebElement) childrenElements.get(i);
                WebElement childElement = childrenElements.get(i);
                String childTag = childElement.getTagName();
                String childXPATH = constructXPATH(parentXPATH, siblingCountMap, childTag);
                xpathIDToWebElementMap.put(childXPATH, childElement);
                webElementToXPATHIDMap.put(childElement, childXPATH);
                remoteWebElementToXPATHIDMap.put(remotewebelement.getId(), childXPATH);
                iterateThroughChildren(childElement, childXPATH);
                //System.out.println("childXPATH:"+childXPATH);
            }
        } catch (Exception ex) {
            //do nothing
        }
    }

    public WebElement findWebElementFromXPATHID(String xpathID) {
        try {
            return xpathIDToWebElementMap.get(xpathID);
        } catch (Exception ex) {
            return null;
        }
    }

    public String findXPATHIDFromWebElement(WebElement webElement) {
        try {
            return remoteWebElementToXPATHIDMap.get(((RemoteWebElement) webElement).getId());
        } catch (Exception ex) {
            return "";
        }
    }

    private String constructXPATH(String parentXPATH, Map siblingCountMap, String childTag) {
        try {
            Integer count = (Integer) siblingCountMap.get(childTag);
            if (count == null) {
                count = 1;
            } else {
                count = count + 1;
            }
            siblingCountMap.put(childTag, count);
            String childXPATH = parentXPATH + "/" + childTag + "[" + count + "]";
            return childXPATH;
        } catch (Exception ex) {
            return "";
        }
    }

    public void updateElementsAndXpaths(WebDriver driver) {
        try {

            if (!bTraversexpaths) {
                //donot load parser since 

            } else {

                System.out.println("Updating PageDom and  XPATHs---------");
                WebElement htmlElement = driver.findElement(By.xpath("/html"));
                iterateThroughChildren(htmlElement, "/html");

                //just print map
                System.out.println("ReScanning XPATHs---------");
//        for (Map.Entry<String, String> entry : remoteWebElementToXPATHIDMap.entrySet()) {
//            System.out.println(entry.getKey() + " ----> " + entry.getValue());
//        }
                System.out.println("After Rescan- XPATHs size = " + remoteWebElementToXPATHIDMap.size());
                System.out.println("ReScanning XPATHs complete---------");
            }
        } catch (Exception ex) {

        }
    }

}
