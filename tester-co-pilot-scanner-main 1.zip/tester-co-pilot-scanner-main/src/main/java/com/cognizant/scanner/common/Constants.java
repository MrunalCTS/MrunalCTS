package com.cognizant.scanner.common;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Constants {
    private Constants() {
    }

    /* Archetypes */
    public static final String ARCHETYPE_GENERIC = "Generic";
    public static final String ARCHETYPE_SFDC = "SFDC";

    /*Robot properties names*/
    public static final String NAME = "robot.name";
    public static final String HOST = "robot.host";
    public static final String TOKEN = "robot.token";
    public static final String WORKING_DIR = "robot.working_dir";
    public static final String CHROME_DRIVER = "robot.chromedriver";

    public static final String HTTP_HTTPS = "^(http|https)://";
    public static final String WS = "ws://";

    public static final String WSS = "wss://";

    public static final String HTTPS = "https://";

    public static final String REGISTER_PATH = "/register";
    public static final String ROBOT_PROPERTIES = "robot.properties";
    public static final String ROBOT_PROP = "robot-prop";
    public static final String USER = "user";

    /*Robot Send Url*/
    public static final String APP_ROBOT_UPDATE = "/app/update-status";
    public static final String APP_ROBOT_SEND_SCRIPT = "/app/send-script";

    public static final String APP_REST_SEND_SCRIPT = "/api/smartprobe/savescript";
    public static final String APP_REST_SEND_SCREENSHOT = "/api/smartprobe/saveautomationdetail";
    public static final String APP_REST_UPDATE_LIVE_STATUS = "/api/smartprobe/updatelivestatus";
    public static final String APP_REST_UPDATE_OVERALL_STATUS = "/api/smartprobe/updatestatus";
    public static final String APP_REST_GET_XPATH = "/api/smartprobe/getxpath";
    public static final String APP_REST_DELETE_XPATH = "/api/smartprobe/deletexpath";
    public static final String APP_REST_GET_LOCATOR = "/api/smartprobe/pageObjects/getLocator";
    public static final String APP_REST_GET_ORCVARIABLE = "/api/smartprobe/orcVariable/getVariable";
    public static final String APP_REST_UPDATE_ORCVARIABLE = "/api/smartprobe/orcVariable/currentValue";

    /*Robot Subscription url*/
    public static final String USER_QUEUE_RUNNER = "/user/queue/runner";
    public static final String USER_QUEUE_XPATH = "/user/queue/xpath";

    /* File paths */
    public static final String AGENT_PATH = "config/agent.properties";
    public static final String wordNetPath = "config/file_properties.xml";
    public static final String verbPath = "config/posvrbs";
    public static final String TechVerbPath = "config/techverbs";
    public static final String SeleniumTemplate = "snippets/pandora.java";
    public static final String TESTNG_MVN_TEMPLATE = "snippets/testng-mvn.java";
    public static final String Snippet_Path = "snippets/";

    //public static final String SeleniumTestCode = "./Selenium_TCAuto.java";
    //public static final String SeleniumXPathTestCode = "./Selenium_XPath_TCAuto.java";
    //public static final String SeleniumTemplateXPath = "src/main/resources/config/pandoraXPaths.jar";
    public static final String FireFoxDriver = "src/main/resources/drivers/geckodriver.exe";
    public static final String ChromeDriverLinux = "src/main/resources/drivers/chromedriver";
    public static final String FireFoxDriverLinux = "src/main/resources/drivers/geckodriver";

    /* Impl constants */
    public static final String TEST_RESULT_DIR = "TestResultDir";
    public static final String SCREENSHOT_FILE_PATH = "./TestResultDir";
    public static final String SCREENPRINT_FILE_EXTN = ".png";
    public static final String LINE_SEPARATOR = System.getProperty("line.separator");
    public static final int PAGE_SCANNING_COUNT = 5;
    public static final String MICRO_LOGGER_FLG = "micrologflag";
    public static final String EDITABLE_WITH_TESTDATA = "editablewithtestdata";
    public static final String SCREEN_PRINT_FLG = "ScreentPrint";
    public static final int GET_XPATH_TIMEOUT = 60; //Ex: 12 means 2 mins
    public static final int MAX_CLASSNAME_LENGTH = 50;

    public static final Set<String> ignoreChars = new HashSet<String>(Arrays.asList(" " , "_", "-"));
    public static HashMap<Integer,String> uxStepMap=new HashMap<Integer,String>();//Creating HashMap
    public static final Set<String> skipWords = new HashSet<String>(Arrays.asList("on", "the", "a", "an", "as", "be", "also", "or", "tobe",
            "when", "how", "what", "where", "had", "has", "over", "have", "out", "in", "to", "for", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
            "which", "any", "else", "if", "by", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
            "", "", "", "", "", "", "", "", "", ""));
    public static final Set<String> verifySkipWords = new HashSet<String>(Arrays.asList("on", "the", "a", "an", "as", "be", "also", "or", "tobe",
            "when", "how", "what", "where", "had", "has", "over", "have", "out", "in", "to", "for", "is","which", "any", "else", "if", "by"));
    public static final Set<String> UserActionWithDataVerbs = new HashSet<String>(Arrays.asList("select", "enter", "type", "retype", "choose","clickalert"));
    public static final Set<String> AppActionVerbs = new HashSet<String>(Arrays.asList("select",
            "click", "enter", "navigate", "launch", "goto", "load", "retype", "reEnter",
            "confirm", "type", "choose", "check", "uncheck", "doubleclick" ,"rightclick",
            "verify","mousehover", "wait", "waitforelementtobeclickable",
            "waitforelementtobevisible", "waitforelementtobeinvisible",
            "waitforelementtobepresent", "waitforalertpresent", "sendkeys", "if","assertequals",
            "assertnotequals","asserttrue","assertfalse", "selectfromlookup"));
    public static final Set<String> KeyBoardActionVerbs = new HashSet<String>(Arrays.asList("presskey"));
    public static final Set<String> KeyBoardAppActionVerbs = new HashSet<String>(Arrays.asList("BACK_SPACE","BACKSPACE","TAB","ENTER","SHIFT","CONTROL","ALT","PAUSE","ESC","ESCAPE","SPACE","PAGE_UP","PAGE_DOWN","END","HOME","LEFT","UP","RIGHT","DOWN","INSERT","DELETE"));
    public static final Set<String> NoPageScanReqVerbs = new HashSet<String>(Arrays.asList("pagechange","pagechanged","url","popup","page","tooltip","tool-tip","Tooltip"));
    public static final Set<String> UserActionWithoutDataVerbs = new HashSet<String>(Arrays.asList("select", "click",  "navigate",
            "launch", "goto", "load", "choose", "check", "uncheck" ,"doubleclick"));

    public static final String LOCATOR_NOT_FOUND = "NOT ABLE TO FIND THE LOCATOR";

}
