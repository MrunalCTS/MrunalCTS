package com.cognizant.scanner.dto;


import com.cognizant.scanner.model.*;
import lombok.*;

@Data
@AllArgsConstructor
@Getter
@Setter
public class RequestDTO {

    private String event;

    private Step step;

    private String driverId;

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public Step getStep() {
        return step;
    }

    public void setStep(Step step) {
        this.step = step;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }
}
